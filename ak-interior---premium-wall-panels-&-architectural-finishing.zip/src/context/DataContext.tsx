import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { 
  collection, 
  doc, 
  onSnapshot, 
  setDoc, 
  updateDoc, 
  deleteDoc, 
  getDocs,
  writeBatch
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { 
  Category, 
  Product, 
  GalleryItem, 
  Testimonial, 
  Enquiry, 
  SiteContent, 
  Settings 
} from '../types';
import { 
  SEED_CATEGORIES, 
  SEED_PRODUCTS, 
  SEED_GALLERY, 
  SEED_TESTIMONIALS, 
  SEED_SITE_CONTENT, 
  SEED_SETTINGS 
} from '../data/seedData';
import { useAuth } from './AuthContext';

interface DataContextType {
  categories: Category[];
  products: Product[];
  gallery: GalleryItem[];
  testimonials: Testimonial[];
  enquiries: Enquiry[];
  siteContent: SiteContent;
  settings: Settings;
  loading: boolean;
  seedingInProgress: boolean;
  
  // Actions
  seedDatabase: () => Promise<void>;
  
  // Products
  addProduct: (product: Omit<Product, 'id'>) => Promise<string>;
  updateProduct: (id: string, product: Partial<Product>) => Promise<void>;
  deleteProduct: (id: string) => Promise<void>;
  bulkUpdatePrices: (categoryId: string, percentChange: number, flatChange: number) => Promise<number>;
  
  // Categories
  addCategory: (category: Omit<Category, 'id'>) => Promise<string>;
  updateCategory: (id: string, category: Partial<Category>) => Promise<void>;
  deleteCategory: (id: string) => Promise<void>;
  
  // Gallery
  addGalleryItem: (item: Omit<GalleryItem, 'id'>) => Promise<string>;
  updateGalleryItem: (id: string, item: Partial<GalleryItem>) => Promise<void>;
  deleteGalleryItem: (id: string) => Promise<void>;
  
  // Testimonials
  addTestimonial: (item: Omit<Testimonial, 'id'>) => Promise<string>;
  updateTestimonial: (id: string, item: Partial<Testimonial>) => Promise<void>;
  deleteTestimonial: (id: string) => Promise<void>;
  
  // Enquiries (Quote leads)
  submitEnquiry: (enquiry: Omit<Enquiry, 'id' | 'createdAt' | 'status'>) => Promise<string>;
  updateEnquiryStatus: (id: string, status: Enquiry['status']) => Promise<void>;
  deleteEnquiry: (id: string) => Promise<void>;
  
  // Content & Settings
  updateSiteContent: (content: Partial<SiteContent>) => Promise<void>;
  updateSettings: (settings: Partial<Settings>) => Promise<void>;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export const DataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { isAdmin } = useAuth();
  
  const [categories, setCategories] = useState<Category[]>(SEED_CATEGORIES);
  const [products, setProducts] = useState<Product[]>(SEED_PRODUCTS);
  const [gallery, setGallery] = useState<GalleryItem[]>(SEED_GALLERY);
  const [testimonials, setTestimonials] = useState<Testimonial[]>(SEED_TESTIMONIALS);
  const [enquiries, setEnquiries] = useState<Enquiry[]>([]);
  const [siteContent, setSiteContent] = useState<SiteContent>(SEED_SITE_CONTENT);
  const [settings, setSettings] = useState<Settings>(SEED_SETTINGS);
  
  const [loading, setLoading] = useState<boolean>(true);
  const [seedingInProgress, setSeedingInProgress] = useState<boolean>(false);

  // Firestore Listeners
  useEffect(() => {
    // 1. Categories
    const unsubCats = onSnapshot(collection(db, 'categories'), (snapshot) => {
      if (!snapshot.empty) {
        const loaded = snapshot.docs.map(d => ({ id: d.id, ...d.data() } as Category));
        loaded.sort((a, b) => (a.displayOrder || 0) - (b.displayOrder || 0));
        setCategories(loaded);
      }
    }, (error) => {
      console.warn('Categories snapshot notice:', error.message);
    });

    // 2. Products
    const unsubProds = onSnapshot(collection(db, 'products'), (snapshot) => {
      if (!snapshot.empty) {
        const loaded = snapshot.docs.map(d => ({ id: d.id, ...d.data() } as Product));
        loaded.sort((a, b) => (a.displayOrder || 0) - (b.displayOrder || 0));
        setProducts(loaded);
      }
    }, (error) => {
      console.warn('Products snapshot notice:', error.message);
    });

    // 3. Gallery
    const unsubGal = onSnapshot(collection(db, 'gallery'), (snapshot) => {
      if (!snapshot.empty) {
        const loaded = snapshot.docs.map(d => ({ id: d.id, ...d.data() } as GalleryItem));
        loaded.sort((a, b) => (a.displayOrder || 0) - (b.displayOrder || 0));
        setGallery(loaded);
      }
    }, (error) => {
      console.warn('Gallery snapshot notice:', error.message);
    });

    // 4. Testimonials
    const unsubTest = onSnapshot(collection(db, 'testimonials'), (snapshot) => {
      if (!snapshot.empty) {
        const loaded = snapshot.docs.map(d => ({ id: d.id, ...d.data() } as Testimonial));
        setTestimonials(loaded);
      }
    }, (error) => {
      console.warn('Testimonials snapshot notice:', error.message);
    });

    // 5. Site Content
    const unsubContent = onSnapshot(doc(db, 'site_content', 'main'), (snapshot) => {
      if (snapshot.exists()) {
        setSiteContent(snapshot.data() as SiteContent);
      }
    }, (error) => {
      console.warn('Site content snapshot notice:', error.message);
    });

    // 6. Settings
    const unsubSettings = onSnapshot(doc(db, 'settings', 'general'), (snapshot) => {
      if (snapshot.exists()) {
        setSettings(snapshot.data() as Settings);
      }
    }, (error) => {
      console.warn('Settings snapshot notice:', error.message);
    });

    setLoading(false);

    return () => {
      unsubCats();
      unsubProds();
      unsubGal();
      unsubTest();
      unsubContent();
      unsubSettings();
    };
  }, []);

  // Enquiries listener: only if Admin (to respect security rules)
  useEffect(() => {
    if (!isAdmin) {
      setEnquiries([]);
      return;
    }

    const unsubEnq = onSnapshot(collection(db, 'enquiries'), (snapshot) => {
      const loaded = snapshot.docs.map(d => ({ id: d.id, ...d.data() } as Enquiry));
      // Sort newest first
      loaded.sort((a, b) => (new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime()));
      setEnquiries(loaded);
    }, (error) => {
      console.warn('Enquiries listener:', error.message);
    });

    return () => unsubEnq();
  }, [isAdmin]);

  // Seed the database if empty or upon manual request
  const seedDatabase = useCallback(async () => {
    setSeedingInProgress(true);
    try {
      const batch = writeBatch(db);

      // Categories
      for (const cat of SEED_CATEGORIES) {
        const ref = doc(db, 'categories', cat.id);
        batch.set(ref, cat);
      }

      // Products
      for (const prod of SEED_PRODUCTS) {
        const ref = doc(db, 'products', prod.id);
        batch.set(ref, prod);
      }

      // Gallery
      for (const item of SEED_GALLERY) {
        const ref = doc(db, 'gallery', item.id);
        batch.set(ref, item);
      }

      // Testimonials
      for (const t of SEED_TESTIMONIALS) {
        const ref = doc(db, 'testimonials', t.id);
        batch.set(ref, t);
      }

      // Site Content
      batch.set(doc(db, 'site_content', 'main'), SEED_SITE_CONTENT);

      // Settings
      batch.set(doc(db, 'settings', 'general'), SEED_SETTINGS);

      await batch.commit();
      console.log('Database seeded successfully.');
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, 'seed');
    } finally {
      setSeedingInProgress(false);
    }
  }, []);

  // Auto-seed if database is empty and admin is signed in
  useEffect(() => {
    const checkAndSeed = async () => {
      if (!isAdmin) return;
      try {
        const snap = await getDocs(collection(db, 'products'));
        if (snap.empty) {
          console.log('Products collection is empty. Seeding initial data...');
          await seedDatabase();
        }
      } catch (e) {
        console.warn('Initial seed check:', e);
      }
    };
    checkAndSeed();
  }, [isAdmin, seedDatabase]);

  // Products CRUD
  const addProduct = async (product: Omit<Product, 'id'>): Promise<string> => {
    const newId = 'prod-' + Date.now();
    const docRef = doc(db, 'products', newId);
    try {
      await setDoc(docRef, { ...product, id: newId, updatedAt: new Date().toISOString() });
      return newId;
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `products/${newId}`);
    }
  };

  const updateProduct = async (id: string, product: Partial<Product>): Promise<void> => {
    const docRef = doc(db, 'products', id);
    try {
      await updateDoc(docRef, { ...product, updatedAt: new Date().toISOString() });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `products/${id}`);
    }
  };

  const deleteProduct = async (id: string): Promise<void> => {
    const docRef = doc(db, 'products', id);
    try {
      await deleteDoc(docRef);
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `products/${id}`);
    }
  };

  const bulkUpdatePrices = async (categoryId: string, percentChange: number, flatChange: number): Promise<number> => {
    let affectedCount = 0;
    try {
      const batch = writeBatch(db);
      const targetProducts = products.filter(p => !categoryId || categoryId === 'all' || p.categoryId === categoryId);

      for (const prod of targetProducts) {
        let newPrice = prod.price;
        if (percentChange !== 0) {
          newPrice = Math.round(newPrice * (1 + percentChange / 100));
        }
        if (flatChange !== 0) {
          newPrice = Math.max(1, newPrice + flatChange);
        }

        if (newPrice !== prod.price) {
          const docRef = doc(db, 'products', prod.id);
          batch.update(docRef, { price: newPrice, updatedAt: new Date().toISOString() });
          affectedCount++;
        }
      }

      if (affectedCount > 0) {
        await batch.commit();
      }
      return affectedCount;
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, 'products/bulk');
    }
  };

  // Categories CRUD
  const addCategory = async (category: Omit<Category, 'id'>): Promise<string> => {
    const newId = 'cat-' + Date.now();
    const docRef = doc(db, 'categories', newId);
    try {
      await setDoc(docRef, { ...category, id: newId });
      return newId;
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `categories/${newId}`);
    }
  };

  const updateCategory = async (id: string, category: Partial<Category>): Promise<void> => {
    const docRef = doc(db, 'categories', id);
    try {
      await updateDoc(docRef, category);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `categories/${id}`);
    }
  };

  const deleteCategory = async (id: string): Promise<void> => {
    const docRef = doc(db, 'categories', id);
    try {
      await deleteDoc(docRef);
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `categories/${id}`);
    }
  };

  // Gallery CRUD
  const addGalleryItem = async (item: Omit<GalleryItem, 'id'>): Promise<string> => {
    const newId = 'gal-' + Date.now();
    const docRef = doc(db, 'gallery', newId);
    try {
      await setDoc(docRef, { ...item, id: newId, updatedAt: new Date().toISOString() });
      return newId;
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `gallery/${newId}`);
    }
  };

  const updateGalleryItem = async (id: string, item: Partial<GalleryItem>): Promise<void> => {
    const docRef = doc(db, 'gallery', id);
    try {
      await updateDoc(docRef, { ...item, updatedAt: new Date().toISOString() });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `gallery/${id}`);
    }
  };

  const deleteGalleryItem = async (id: string): Promise<void> => {
    const docRef = doc(db, 'gallery', id);
    try {
      await deleteDoc(docRef);
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `gallery/${id}`);
    }
  };

  // Testimonials CRUD
  const addTestimonial = async (item: Omit<Testimonial, 'id'>): Promise<string> => {
    const newId = 'test-' + Date.now();
    const docRef = doc(db, 'testimonials', newId);
    try {
      await setDoc(docRef, { ...item, id: newId, createdAt: new Date().toISOString() });
      return newId;
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `testimonials/${newId}`);
    }
  };

  const updateTestimonial = async (id: string, item: Partial<Testimonial>): Promise<void> => {
    const docRef = doc(db, 'testimonials', id);
    try {
      await updateDoc(docRef, item);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `testimonials/${id}`);
    }
  };

  const deleteTestimonial = async (id: string): Promise<void> => {
    const docRef = doc(db, 'testimonials', id);
    try {
      await deleteDoc(docRef);
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `testimonials/${id}`);
    }
  };

  // Enquiries (Public quote lead submission)
  const submitEnquiry = async (enquiryData: Omit<Enquiry, 'id' | 'createdAt' | 'status'>): Promise<string> => {
    const newId = 'enq-' + Date.now();
    const docRef = doc(db, 'enquiries', newId);
    const newEnquiry: Enquiry = {
      ...enquiryData,
      id: newId,
      status: 'new',
      createdAt: new Date().toISOString(),
    };
    try {
      await setDoc(docRef, newEnquiry);
      return newId;
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `enquiries/${newId}`);
    }
  };

  const updateEnquiryStatus = async (id: string, status: Enquiry['status']): Promise<void> => {
    const docRef = doc(db, 'enquiries', id);
    try {
      await updateDoc(docRef, { status });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `enquiries/${id}`);
    }
  };

  const deleteEnquiry = async (id: string): Promise<void> => {
    const docRef = doc(db, 'enquiries', id);
    try {
      await deleteDoc(docRef);
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `enquiries/${id}`);
    }
  };

  // Content & Settings
  const updateSiteContent = async (newContent: Partial<SiteContent>): Promise<void> => {
    const docRef = doc(db, 'site_content', 'main');
    try {
      await setDoc(docRef, { ...siteContent, ...newContent }, { merge: true });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, 'site_content/main');
    }
  };

  const updateSettings = async (newSettings: Partial<Settings>): Promise<void> => {
    const docRef = doc(db, 'settings', 'general');
    try {
      await setDoc(docRef, { ...settings, ...newSettings }, { merge: true });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, 'settings/general');
    }
  };

  return (
    <DataContext.Provider
      value={{
        categories,
        products,
        gallery,
        testimonials,
        enquiries,
        siteContent,
        settings,
        loading,
        seedingInProgress,
        seedDatabase,
        addProduct,
        updateProduct,
        deleteProduct,
        bulkUpdatePrices,
        addCategory,
        updateCategory,
        deleteCategory,
        addGalleryItem,
        updateGalleryItem,
        deleteGalleryItem,
        addTestimonial,
        updateTestimonial,
        deleteTestimonial,
        submitEnquiry,
        updateEnquiryStatus,
        deleteEnquiry,
        updateSiteContent,
        updateSettings,
      }}
    >
      {children}
    </DataContext.Provider>
  );
};

export const useData = (): DataContextType => {
  const context = useContext(DataContext);
  if (!context) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
};
