import { Category, Product, GalleryItem, Testimonial, SiteContent, Settings } from '../types';

export const SEED_CATEGORIES: Category[] = [
  {
    id: 'pvc-panels',
    name_en: 'PVC Wall Panels',
    name_hi: 'पीवीसी वॉल पैनल्स',
    slug: 'pvc-panels',
    icon: 'Layers',
    displayOrder: 1,
    description_en: '100% waterproof, termite-proof lightweight tongue-and-groove decorative wall panels.',
    description_hi: '100% वाटरप्रूफ और दीमक रोधी सजावटी पीवीसी दीवार पैनल्स।'
  },
  {
    id: 'charcoal-panels',
    name_en: 'Charcoal Louvers',
    name_hi: 'चारकोल लवर्स',
    slug: 'charcoal-panels',
    icon: 'Grid',
    displayOrder: 2,
    description_en: 'Ultra-luxurious fluted charcoal panels with metallic and matte textures for feature walls.',
    description_hi: 'फीचर वॉल्स और टीवी यूनिट्स के लिए अल्ट्रा-लक्ज़री फ्लूटेड चारकोल पैनल्स।'
  },
  {
    id: 'wpc-panels',
    name_en: 'WPC Fluted Panels',
    name_hi: 'WPC फ्लूटेड पैनल्स',
    slug: 'wpc-panels',
    icon: 'Maximize2',
    displayOrder: 3,
    description_en: 'Heavy-duty wood plastic composite fluted panels for luxury living and exterior cladding.',
    description_hi: 'लिविंग रूम और बाहरी दीवारों के लिए टिकाऊ वुड प्लास्टिक कंपोजिट पैनल्स।'
  },
  {
    id: 'uv-marble-sheets',
    name_en: 'UV Marble Sheets',
    name_hi: 'यूवी मार्बल शीट्स',
    slug: 'uv-marble-sheets',
    icon: 'Sparkles',
    displayOrder: 4,
    description_en: 'High-gloss Italian marble look PVC sheets for TV units, lobby walls, and moisture areas.',
    description_hi: 'इटैलियन मार्बल लुक वाली हाई-ग्लॉस 8x4 फीट वाटरप्रूफ पीवीसी शीट्स।'
  },
  {
    id: 'decorative-lights',
    name_en: 'Designer Lighting',
    name_hi: 'डिजाइनर लाइट्स',
    slug: 'decorative-lights',
    icon: 'Lightbulb',
    displayOrder: 5,
    description_en: 'Concealed magnetic profile lights, warm COB spot lights, cove strips and wall sconces.',
    description_hi: 'मैग्नेटिक प्रोफाइल लाइट्स, कोव लाइट्स और वार्म स्पॉट लाइट्स।'
  },
  {
    id: 'ceiling-work',
    name_en: 'Ceiling Solutions',
    name_hi: 'सीलिंग कार्य',
    slug: 'ceiling-work',
    icon: 'Box',
    displayOrder: 6,
    description_en: 'Modern PVC ceiling & false ceiling designs with ambient cove lighting integration.',
    description_hi: 'मॉडर्न पीवीसी सीलिंग और फॉल्स सीलिंग डिजाइन विद कोव लाइटिंग।'
  },
  {
    id: 'turnkey-interiors',
    name_en: 'Turnkey Interiors',
    name_hi: 'टर्नकी इंटीरियर कार्य',
    slug: 'turnkey-interiors',
    icon: 'Home',
    displayOrder: 7,
    description_en: 'End-to-end wall styling, panel installation, lighting, and finishing for homes & shops.',
    description_hi: 'घर, ऑफिस और शोरूम के लिए मटीरियल, डिजाइन व इंस्टॉलेशन सहित संपूर्ण कार्य।'
  }
];

export const SEED_PRODUCTS: Product[] = [
  {
    id: 'prod-charcoal-01',
    name_en: 'Matte Royal Charcoal Louver Panel',
    name_hi: 'रॉयल चारकोल लाउवर पैनल (मैट फिनिश)',
    categoryId: 'charcoal-panels',
    categorySlug: 'charcoal-panels',
    description_en: 'High-density extruded charcoal fluted panel with deep matte dark finish. Ideal for TV backdrop and bed headboard feature walls.',
    description_hi: 'हाई-डेंसिटी एक्सट्रूडेड चारकोल पैनल। टीवी यूनिट बैकड्रॉप और मास्टर बेडरूम की दीवारों के लिए अत्यंत लोकप्रिय।',
    size: '8 ft × 5 inch (2440mm × 125mm)',
    thickness: '12 mm Deep Flute',
    finish_colors: 'Midnight Black, Smoked Oak, Slate Bronze, Graphite Grey',
    price: 1350,
    priceUnit: 'piece',
    installationIncluded: false,
    images: [
      'https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=1200&q=80'
    ],
    featured: true,
    inStock: true,
    displayOrder: 1
  },
  {
    id: 'prod-charcoal-02',
    name_en: 'Champagne Gold Inlay Charcoal Panel',
    name_hi: 'शैम्पेन गोल्ड इनले चारकोल पैनल',
    categoryId: 'charcoal-panels',
    categorySlug: 'charcoal-panels',
    description_en: 'Luxury charcoal louver with genuine brushed gold metallic strip inserts. Gives a boutique 5-star hotel ambiance.',
    description_hi: 'गोल्ड मेटैलिक स्ट्रिप के साथ लक्ज़री चारकोल लाउवर पैनल। लिविंग रूम में फाइव-स्टार होटल जैसी चमक देता है।',
    size: '8 ft × 4.75 inch (2440mm × 120mm)',
    thickness: '15 mm Architectural Profile',
    finish_colors: 'Black with Gold Inlay, Walnut with Brass Inlay',
    price: 1650,
    priceUnit: 'piece',
    installationIncluded: false,
    images: [
      'https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&q=80'
    ],
    featured: true,
    inStock: true,
    displayOrder: 2
  },
  {
    id: 'prod-uv-01',
    name_en: 'Statuario Gold 8x4 UV Marble Sheet',
    name_hi: 'स्टैचुएरी गोल्ड 8x4 यूवी मार्बल शीट',
    categoryId: 'uv-marble-sheets',
    categorySlug: 'uv-marble-sheets',
    description_en: 'Heavy-duty 3mm UV coated high-gloss sheet replicating exotic Italian Statuario marble with warm golden veins. Seamless TV console backing.',
    description_hi: 'इटैलियन स्टैचुएरी मार्बल जैसी हाई-ग्लॉस 8x4 फीट शीट। वाटरप्रूफ, स्क्रेच-रेसिस्टेंट और सीलन से पूरी तरह सुरक्षित।',
    size: '8 ft × 4 ft (2440mm × 1220mm)',
    thickness: '3.0 mm High-Gloss UV Layer',
    finish_colors: 'Statuario Gold Vein, Carrara White, Black Marquina',
    price: 2150,
    priceUnit: 'piece',
    installationIncluded: false,
    images: [
      'https://images.unsplash.com/photo-1600585154526-990dced4db0d?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=1200&q=80'
    ],
    featured: true,
    inStock: true,
    displayOrder: 3
  },
  {
    id: 'prod-uv-02',
    name_en: 'Black Portoro Gold Vein UV Marble Sheet',
    name_hi: 'ब्लैक पोर्टोरो गोल्ड यूवी मार्बल शीट',
    categoryId: 'uv-marble-sheets',
    categorySlug: 'uv-marble-sheets',
    description_en: 'Dramatic deep black Italian stone aesthetic with dramatic golden lightning veins. Perfect for modern entertainment walls and bars.',
    description_hi: 'गहरे काले रंग और गोल्डन नसों वाली एक्सक्लूसिव मार्बल शीट। मॉडर्न टीवी वॉल्स और बार काउंटर्स के लिए बेस्ट।',
    size: '8 ft × 4 ft (2440mm × 1220mm)',
    thickness: '3.2 mm UV Cured',
    finish_colors: 'Deep Black Nero Portoro, Emerald Green Onyx',
    price: 2400,
    priceUnit: 'piece',
    installationIncluded: false,
    images: [
      'https://images.unsplash.com/photo-1600565193348-f74bd3c7ccdf?auto=format&fit=crop&w=1200&q=80'
    ],
    featured: false,
    inStock: true,
    displayOrder: 4
  },
  {
    id: 'prod-wpc-01',
    name_en: 'Natural Teak WPC Fluted Wall Louver',
    name_hi: 'नेचुरल टीक WPC फ्लूटेड वॉल लाउवर',
    categoryId: 'wpc-panels',
    categorySlug: 'wpc-panels',
    description_en: 'Eco-friendly wood-plastic composite panel with realistic wood grain texture. Borer proof, fire retardant, zero maintenance.',
    description_hi: 'लकड़ी के खूबसूरत टेक्सचर वाला WPC पैनल। दीमक-रोधी, वाटरप्रूफ और 15 साल तक चलने वाली मजबूती।',
    size: '9.5 ft × 6 inch (2900mm × 150mm)',
    thickness: '18 mm Heavy Fluted',
    finish_colors: 'Burma Teak, Brazilian Walnut, Dark Wenge, Natural Cedar',
    price: 165,
    priceUnit: 'sq ft',
    installationIncluded: true,
    images: [
      'https://images.unsplash.com/photo-1600585152220-90363fe7e115?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&w=1200&q=80'
    ],
    featured: true,
    inStock: true,
    displayOrder: 5
  },
  {
    id: 'prod-pvc-01',
    name_en: 'Heavy-Duty 3D Groove PVC Wall Panel',
    name_hi: 'हैवी-ड्यूटी 3D ग्रूव्ज पीवीसी वॉल पैनल',
    categoryId: 'pvc-panels',
    categorySlug: 'pvc-panels',
    description_en: 'Budget-friendly, 100% moisture-barrier PVC panel for damp walls (seelan). Fast clip-on interlocking installation.',
    description_hi: 'सीलन वाली दीवारों का पक्का इलाज। वाटरप्रूफ, जल्दी लगने वाला और आसानी से साफ होने वाला पीवीसी पैनल।',
    size: '10 ft × 10 inch (3000mm × 250mm)',
    thickness: '8.5 mm Double Ribbed',
    finish_colors: 'Classic Ivory, Beige Oak, White Wood, Grey Metallic',
    price: 78,
    priceUnit: 'sq ft',
    installationIncluded: true,
    images: [
      'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&q=80'
    ],
    featured: true,
    inStock: true,
    displayOrder: 6
  },
  {
    id: 'prod-pvc-02',
    name_en: 'Designer Walnut Wood Grain PVC Panel',
    name_hi: 'डिजाइनर वॉलनट वुड ग्रेन पीवीसी पैनल',
    categoryId: 'pvc-panels',
    categorySlug: 'pvc-panels',
    description_en: 'Rich natural walnut timber look PVC wall panel with subtle satin sheen. Transforms bare walls into cozy warm spaces.',
    description_hi: 'नेचुरल वॉलनट वुड का प्रीमियम फिनिश। बेडरूम और लॉबी की दीवारों को देता है रिच और वार्म लुक।',
    size: '10 ft × 8 inch',
    thickness: '9 mm Reinforced',
    finish_colors: 'American Walnut, Royal Mahogany, Scandinavian Birch',
    price: 85,
    priceUnit: 'sq ft',
    installationIncluded: true,
    images: [
      'https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?auto=format&fit=crop&w=1200&q=80'
    ],
    featured: false,
    inStock: true,
    displayOrder: 7
  },
  {
    id: 'prod-light-01',
    name_en: 'Magnetic Recessed Profile Light Channel',
    name_hi: 'मैग्नेटिक रीसेस्ड प्रोफाइल लाइट चैनल',
    categoryId: 'decorative-lights',
    categorySlug: 'decorative-lights',
    description_en: 'Sleek anodized aluminum magnetic track system with 48V low voltage safety. Clip spot lights, diffuse linear lights anywhere.',
    description_hi: 'आधुनिक स्लीक मैग्नेटिक ट्रैक लाइट सिस्टम। सीलिंग और दीवारों पर मनचाही जगह स्पॉटलाइट या लीनियर लाइट लगाएं।',
    size: '2 Meter / 3 Meter Track Rails',
    thickness: 'Slim Trimless Profile',
    finish_colors: 'Deep Matte Black, Arctic White',
    price: 420,
    priceUnit: 'running ft',
    installationIncluded: false,
    images: [
      'https://images.unsplash.com/photo-1513519245088-0e12902e5a38?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1507473885765-e6ed057f782c?auto=format&fit=crop&w=1200&q=80'
    ],
    featured: true,
    inStock: true,
    displayOrder: 8
  },
  {
    id: 'prod-light-02',
    name_en: 'Architectural LED Warm Silicone Cove Strip (3000K)',
    name_hi: 'वार्म व्हाइट सिलिकॉन कोव लाइट स्ट्रिप (3000K)',
    categoryId: 'decorative-lights',
    categorySlug: 'decorative-lights',
    description_en: 'Dotless uniform neon silicone LED cove strip light for panel backdrops, false ceiling perimeters, and under-cabinet glow.',
    description_hi: 'डॉटलेस हाई-क्वालिटी सिलिकॉन एलईडी स्ट्रिप। पैनल्स के पीछे और फॉल्स सीलिंग में देती है स्मूथ वार्म ग्लो।',
    size: '5 Meter Roll (High Density 240 LEDs/m)',
    thickness: 'IP65 Flexible Silicone',
    finish_colors: 'Warm White (3000K), Neutral White (4000K), Amber Gold',
    price: 380,
    priceUnit: 'running ft',
    installationIncluded: true,
    images: [
      'https://images.unsplash.com/photo-1540932239986-30128078f3c5?auto=format&fit=crop&w=1200&q=80'
    ],
    featured: false,
    inStock: true,
    displayOrder: 9
  },
  {
    id: 'prod-light-03',
    name_en: 'Anti-Glare Architectural COB Spot Light',
    name_hi: 'एंटी-ग्लेयर आर्किटेक्चरल COB स्पॉट लाइट',
    categoryId: 'decorative-lights',
    categorySlug: 'decorative-lights',
    description_en: '7W / 12W deep recessed spot light with dark reflector for museum-grade wall washing highlights without direct glare.',
    description_hi: '7W / 12W डीप रीसेस्ड वार्म स्पॉट लाइट। पैनल्स के टेक्सचर को खूबसूरती से उभारती है, आंखों में चुभती नहीं।',
    size: 'Die-cast Aluminium Round',
    thickness: 'Cutout 70mm - 85mm',
    finish_colors: 'Black Cup, Rose Gold Cup, White Cup',
    price: 350,
    priceUnit: 'piece',
    installationIncluded: true,
    images: [
      'https://images.unsplash.com/photo-1507473885765-e6ed057f782c?auto=format&fit=crop&w=1200&q=80'
    ],
    featured: false,
    inStock: true,
    displayOrder: 10
  },
  {
    id: 'prod-ceil-01',
    name_en: 'Premium PVC False Ceiling with Wooden Battens',
    name_hi: 'प्रीमियम पीवीसी फॉल्स सीलिंग विद वुडन बैटन्स',
    categoryId: 'ceiling-work',
    categorySlug: 'ceiling-work',
    description_en: 'Lightweight, damp-proof PVC ceiling system with GI channel framing, light cuts, and contrasting teak perimeter borders.',
    description_hi: 'जीआई चैनल फ्रेमिंग, वार्म लाइट कट्स और वुडन बॉर्डर के साथ टिकाऊ पीवीसी फॉल्स सीलिंग।',
    size: 'Custom Room Dimensions',
    thickness: 'Complete Grid & Panel System',
    finish_colors: 'Pure White + Natural Teak, Grey Marble + Gold Trim',
    price: 95,
    priceUnit: 'sq ft',
    installationIncluded: true,
    images: [
      'https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=1200&q=80'
    ],
    featured: true,
    inStock: true,
    displayOrder: 11
  },
  {
    id: 'prod-turnkey-01',
    name_en: 'Signature TV Media Wall Complete Package',
    name_hi: 'सिग्नेचर टीवी मीडिया वॉल कम्प्लीट पैकेज',
    categoryId: 'turnkey-interiors',
    categorySlug: 'turnkey-interiors',
    description_en: 'Turnkey feature wall combining Statuario UV marble slab, dark charcoal louvers, warm concealed LED profile lighting and floating drawer console.',
    description_hi: 'संपूर्ण टीवी यूनिट वॉल: स्टैचुएरी मार्बल शीट + चारकोल लवर्स + हिडन वार्म एलईडी लाइट्स + फ्लोटिंग रैक। 48 घंटे में पूरा तैयार।',
    size: 'Standard 10 ft × 8 ft Wall Area',
    thickness: 'Multi-layer Architectural Paneling',
    finish_colors: 'Custom Curated Palette (Client Choice)',
    price: 38500,
    priceUnit: 'set',
    installationIncluded: true,
    images: [
      'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&w=1200&q=80'
    ],
    featured: true,
    inStock: true,
    displayOrder: 12
  }
];

export const SEED_GALLERY: GalleryItem[] = [
  {
    id: 'gal-01',
    title_en: 'Luxury TV Lounge Feature Wall',
    title_hi: 'लक्ज़री टीवी लाउंज फीचर वॉल',
    category: 'tv_unit',
    image: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&q=80',
    beforeImage: 'https://images.unsplash.com/photo-1590381105924-c72589b9ef3f?auto=format&fit=crop&w=1200&q=80',
    panelType: 'Charcoal Fluted Louvers + Statuario UV Marble + 3000K Cove LED',
    linkedProductId: 'prod-turnkey-01',
    location: 'Mansarovar, Jaipur',
    displayOrder: 1
  },
  {
    id: 'gal-02',
    title_en: 'Minimalist Master Bedroom Bedhead Paneling',
    title_hi: 'मास्टर बेडरूम हेडबोर्ड वॉल पैनल्स',
    category: 'bedroom',
    image: 'https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?auto=format&fit=crop&w=1200&q=80',
    beforeImage: 'https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1200&q=80',
    panelType: 'WPC Teak Slat Panels + Soft Brass Trims',
    linkedProductId: 'prod-wpc-01',
    location: 'DLF Phase 5, Gurugram',
    displayOrder: 2
  },
  {
    id: 'gal-03',
    title_en: 'Executive Boardroom Acoustic Louver Wall',
    title_hi: 'कॉर्पोरेट बोर्डरूम चारकोल वॉल',
    category: 'office',
    image: 'https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&w=1200&q=80',
    panelType: 'Matte Royal Charcoal Louver Panel',
    linkedProductId: 'prod-charcoal-01',
    location: 'Noida Sector 62, Delhi NCR',
    displayOrder: 3
  },
  {
    id: 'gal-04',
    title_en: 'Double-Height Living Room Marble TV Wall',
    title_hi: 'डबल-हाइट लिविंग रूम यूवी मार्बल वॉल',
    category: 'living_room',
    image: 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=1200&q=80',
    beforeImage: 'https://images.unsplash.com/photo-1503387762-592deb58ef4e?auto=format&fit=crop&w=1200&q=80',
    panelType: 'Statuario Gold UV Marble Sheets + Backlit Profile Channels',
    linkedProductId: 'prod-uv-01',
    location: 'Vaishali Nagar, Jaipur',
    displayOrder: 4
  },
  {
    id: 'gal-05',
    title_en: 'Boutique Jewellery Showroom Entrance',
    title_hi: 'ज्वैलरी शोरूम एंट्रेंस वॉल डिजाइन',
    category: 'shop',
    image: 'https://images.unsplash.com/photo-1600565193348-f74bd3c7ccdf?auto=format&fit=crop&w=1200&q=80',
    panelType: 'Champagne Gold Inlay Charcoal Panels + Spot Lights',
    linkedProductId: 'prod-charcoal-02',
    location: 'Johari Bazaar, Jaipur',
    displayOrder: 5
  },
  {
    id: 'gal-06',
    title_en: 'Designer Dining Room False Ceiling with Cove Lighting',
    title_hi: 'डाइनिंग एरिया पीवीसी सीलिंग और कोव लाइट्स',
    category: 'ceiling',
    image: 'https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=1200&q=80',
    panelType: 'PVC False Ceiling with Teak Battens + Magnetic Track',
    linkedProductId: 'prod-ceil-01',
    location: 'Malviya Nagar, Jaipur',
    displayOrder: 6
  }
];

export const SEED_TESTIMONIALS: Testimonial[] = [
  {
    id: 'test-01',
    name: 'Rajesh Sharma',
    city: 'Jaipur, Rajasthan',
    rating: 5,
    review_en: 'AK Interior transformed our entire living room in just 2 days! The charcoal louver finish with Statuario marble sheet looks phenomenal. Their finishing and concealed wiring for LED profile lights is top tier. Highly recommended!',
    review_hi: 'एके इंटीरियर ने सिर्फ 2 दिनों में हमारे पूरे लिविंग रूम का कायाकल्प कर दिया! चारकोल लाउवर और मार्बल शीट का कॉम्बिनेशन कमाल का लग रहा है। कारीगरों का काम बहुत साफ-सुथरा और समय पर हुआ।',
    projectType: '3BHK Living Room TV Media Wall',
    photo: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
    approved: true
  },
  {
    id: 'test-02',
    name: 'Vikram & Pooja Singhal',
    city: 'Gurugram, Haryana',
    rating: 5,
    review_en: 'We had persistent dampness (seelan) on our bedroom walls which destroyed expensive paint every monsoon. AK Interior recommended their waterproof PVC and charcoal panels. One year later, zero moisture issue and the room feels like a luxury resort.',
    review_hi: 'हमारे बेडरूम की दीवार पर बहुत सीलन आती थी जिससे पेंट खराब हो जाता था। एके इंटीरियर के वाटरप्रूफ पैनल्स लगवाने के बाद सीलन की समस्या हमेशा के लिए खत्म हो गई। बहुत बेहतरीन काम!',
    projectType: 'Master Bedroom Bedhead Paneling',
    photo: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
    approved: true
  },
  {
    id: 'test-03',
    name: 'Ar. Manish Mehta (Principal Architect)',
    city: 'Delhi NCR',
    rating: 5,
    review_en: 'As an architect, I am very picky about flute alignment and joint lines. The AK Interior installation crew executes with millimeter precision. They bring original catalogues, samples on site and finish strictly within quoted time.',
    review_hi: 'एक आर्किटेक्ट होने के नाते मुझे काम में परफेक्ट फिनिशिंग चाहिए। एके इंटीरियर की टीम बहुत प्रोफेशनल है। जॉइंट्स और लाइट कट्स बिल्कुल सटीक तरीके से फिट किए।',
    projectType: 'Corporate Office Paneling & Track Lights',
    photo: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=300&q=80',
    approved: true
  },
  {
    id: 'test-04',
    name: 'Sunita Aggarwal',
    city: 'Noida, UP',
    rating: 5,
    review_en: 'Transparent pricing with no hidden charges. They gave me a free site visit, measured everything accurately, and showed me 5 different charcoal louvers with brass inlays. The final result exceeded my expectations!',
    review_hi: 'पारदर्शी दाम और कोई छिपा हुआ चार्ज नहीं। फ्री साइट विजिट की और कई सारे सैंपल्स दिखाए। काम पूरा होने के बाद टीवी वॉल बहुत ही सुंदर लग रही है।',
    projectType: 'Drawing Room Feature Wall',
    photo: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=300&q=80',
    approved: true
  },
  {
    id: 'test-05',
    name: 'Gaurav Khandelwal',
    city: 'Ajmer Road, Jaipur',
    rating: 5,
    review_en: 'Got PVC ceiling and magnetic profile lights done for our newly opened fashion boutique. Everyone who walks into the store compliments the ceiling aesthetics. Superb craftsmanship by Tarun and his team.',
    review_hi: 'हमारे नए बुटीक के लिए पीवीसी सीलिंग और प्रोफाइल लाइट्स का काम करवाया। जो भी ग्राहक आता है वो सीलिंग की तारीफ करता है। बहुत-बहुत धन्यवाद एके इंटीरियर टीम!',
    projectType: 'Retail Boutique Ceiling & Profile Lights',
    photo: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=300&q=80',
    approved: true
  },
  {
    id: 'test-06',
    name: 'Deepak Choudhary',
    city: 'Chandigarh',
    rating: 5,
    review_en: 'The best thing about AK Interior is that they handle everything turnkey—material supply, design advice, installation, and clean-up. No headache of dealing with multiple vendors. 10/10 quality.',
    review_hi: 'सबसे अच्छी बात यह है कि मटीरियल, डिजाइन और इंस्टॉलेशन सब कुछ एक ही जगह हो गया। अलग-अलग ठेकेदारों के चक्कर नहीं काटने पड़े। शानदार सर्विस!',
    projectType: 'Full Villa Turnkey Wall Paneling',
    photo: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?auto=format&fit=crop&w=300&q=80',
    approved: true
  }
];

export const SEED_SITE_CONTENT: SiteContent = {
  heroHeadline_en: 'Transform Your Walls Into Art',
  heroHeadline_hi: 'अपनी दीवारों को बनाइए कला',
  heroSubheadline_en: 'Premium PVC Panels • Charcoal Louvers • UV Marble Sheets • Designer Lighting • Turnkey Interiors',
  heroSubheadline_hi: 'प्रीमियम पीवीसी पैनल्स • चारकोल लवर्स • यूवी मार्बल शीट्स • डिजाइनर लाइट्स • सम्पूर्ण इंटीरियर कार्य',
  heroImages: [
    'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1920&q=85',
    'https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&w=1920&q=85',
    'https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?auto=format&fit=crop&w=1920&q=85'
  ],
  expYears: 10,
  projectsCompleted: 500,
  happyClients: 480,
  guaranteeYears: 10,
  aboutStory_en: 'Founded with a passion for architectural finesse, AK Interior has grown into one of North India’s most trusted interior finishing specialists. We recognized the frustration homeowners face with damp walls, peeling paint, and dusty, prolonged renovations. We introduced modern engineered surface solutions: charcoal louvers, heavy-duty PVC panels, UV marble sheets, and concealed architectural lighting that install cleanly within 24 to 48 hours. From material procurement to master installation, we take end-to-end responsibility with a firm 10-year quality guarantee.',
  aboutStory_hi: 'एके इंटीरियर उत्तर भारत की एक अग्रणी इंटीरियर फिनिशिंग कंपनी है। हमने हमेशा देखा कि कैसे सीलन और पपड़ी वाले पेंट से लोग परेशान रहते थे और हफ्तों चलने वाले पेंटिंग काम से घर में धूल-मिट्टी भर जाती थी। हमने पेश किए आधुनिक समाधान: चारकोल लवर्स, पीवीसी पैनल्स, यूवी मार्बल शीट्स और हिडन प्रोफाइल लाइट्स जो 24 से 48 घंटे में बिना किसी गंदगी के फिट हो जाते हैं। हम मटीरियल से लेकर इंस्टॉलेशन तक पूरी जिम्मेदारी निभाते हैं।',
  aboutOwnerName: 'Tarun Thakur & Craftsmen Team',
  aboutOwnerRole: 'Founders & Lead Installation Directors',
  whyChooseUs: [
    {
      id: 'why-01',
      icon: 'ShieldCheck',
      title_en: '100% Waterproof & Termite Proof',
      title_hi: '100% वाटरप्रूफ व दीमक-रोधी',
      desc_en: 'Engineered polymer and WPC panels that permanently shield your walls from monsoon seepage (seelan) and pests.',
      desc_hi: 'सीलन और दीमक से दीवारों को 100% सुरक्षा देने वाला हाई-क्वालिटी पॉलीमर मटीरियल।'
    },
    {
      id: 'why-02',
      icon: 'Users',
      title_en: 'Master In-House Installation Team',
      title_hi: 'अनुभवी कारीगरों की इन-हाउस टीम',
      desc_en: 'No third-party subcontractors. Our trained full-time carpenters and electricians guarantee millimeter perfection.',
      desc_hi: 'कोई थर्ड पार्टी नहीं। हमारे अपने प्रशिक्षित कारीगर बारीकी से इंस्टॉलेशन पूरा करते हैं।'
    },
    {
      id: 'why-03',
      icon: 'FileText',
      title_en: 'Transparent Per-Sq-Ft Pricing',
      title_hi: 'पारदर्शी व स्पष्ट मूल्य निर्धारण',
      desc_en: 'Clear itemized quotations with no surprise hidden fees. You pay exactly what was measured and agreed.',
      desc_hi: 'बिना किसी छिपे हुए खर्च के स्पष्ट बिलिंग। सटीक नाप के आधार पर उचित मूल्य।'
    },
    {
      id: 'why-04',
      icon: 'Clock',
      title_en: '24–48 Hour Swift Handover',
      title_hi: '24 से 48 घंटे में त्वरित डिलीवरी',
      desc_en: 'Complete room paneling installed in 1 to 2 days without paint odors, dust, or prolonged household disruption.',
      desc_hi: 'बिना धूल और बदबू के मात्र 1-2 दिनों में आपके कमरे की वॉल तैयार।'
    },
    {
      id: 'why-05',
      icon: 'Award',
      title_en: '10-Year Quality Guarantee',
      title_hi: '10 साल की मजबूती की गारंटी',
      desc_en: 'High-grade UV-resistant coatings and heavy-density polymers that do not fade, warp, or crack over time.',
      desc_hi: 'रंग न उड़ने और पैनल मुड़ने या टूटने से सुरक्षा की लंबी 10 वर्षीय वारंटी।'
    },
    {
      id: 'why-06',
      icon: 'MapPin',
      title_en: 'Complimentary Free Site Visit',
      title_hi: 'मुफ्त ऑन-साइट विजिट व सैंपल्स',
      desc_en: 'Our interior consultant visits your home with physical catalogs and panel swatches to take laser measurements.',
      desc_hi: 'हमारा एक्सपर्ट आपके घर आकर लेज़र से सटीक नाप लेता है और ओरिजिनल सैंपल्स दिखाता है।'
    }
  ],
  processSteps: [
    {
      step: '01',
      title_en: 'Initial Enquiry & Phone Consultation',
      title_hi: 'संपर्क व प्राथमिक बातचीत',
      desc_en: 'Share your room photos, wall dimensions, or design ideas via WhatsApp or our instant quote form.',
      desc_hi: 'व्हाट्सएप या फॉर्म द्वारा अपने कमरे की तस्वीरें या अनुमानित नाप साझा करें।'
    },
    {
      step: '02',
      title_en: 'Free Site Visit & Laser Measurement',
      title_hi: 'फ्री साइट विजिट व लेज़र नाप',
      desc_en: 'Our technician visits your location with full physical sample boxes to examine wall conditions and take exact measurements.',
      desc_hi: 'हमारा प्रतिनिधि आपके घर आकर दीवारों की जांच करता है और ओरिजिनल सैंपल दिखाता है।'
    },
    {
      step: '03',
      title_en: 'Design Concept & Transparent Quotation',
      title_hi: 'डिजाइन सुझाव व स्पष्ट कोटेशन',
      desc_en: 'We recommend the perfect panel combinations (louver + marble sheet + cove lights) and share a transparent itemized estimate.',
      desc_hi: 'आपके बजट के अनुसार बेहतरीन कॉम्बिनेशन और पूरी कीमत का लिखित विवरण दिया जाता है।'
    },
    {
      step: '04',
      title_en: 'Material Delivery & Master Installation',
      title_hi: 'मटीरियल डिलीवरी व कुशल इंस्टॉलेशन',
      desc_en: 'Premium factory-sealed panels arrive at your doorstep. Our master installers mount, align, and wire lights within 24–48 hours.',
      desc_hi: 'हमारी टीम द्वारा सुरक्षित तरीके से पैनल्स और लाइट्स की फिटिंग 1-2 दिन में पूरी की जाती है।'
    },
    {
      step: '05',
      title_en: 'Final Inspection & 10-Yr Warranty Handover',
      title_hi: 'अंतिम निरीक्षण व हैंडओवर',
      desc_en: 'Thorough joint inspection, surface wipe-down, lighting test, and issuance of your warranty certificate.',
      desc_hi: 'पूरी फिनिशिंग की जांच, टेस्टिंग और वारंटी सर्टिफिकेट के साथ प्रोजेक्ट हैंडओवर।'
    }
  ],
  faqs: [
    {
      id: 'faq-01',
      category: 'Durability',
      q_en: 'Are PVC and Charcoal panels completely waterproof against wall dampness (seelan)?',
      q_hi: 'क्या पीवीसी और चारकोल पैनल्स सीलन (moisture) के खिलाफ पूरी तरह वाटरप्रूफ हैं?',
      a_en: 'Yes, 100%! Both our PVC and Charcoal louver panels are made from high-density synthetic polymers that do not absorb moisture or rot. Unlike wallpaper or paint that peels off due to seelan, these panels act as an impermeable architectural barrier.',
      a_hi: 'जी हाँ, बिल्कुल! हमारे पीवीसी और चारकोल लवर्स वाटरप्रूफ पॉलीमर से बने होते हैं जो पानी या नमी से कभी खराब नहीं होते। सीलन वाली दीवारों पर पेंट या वॉलपेपर तुरंत छूट जाता है, जबकि ये पैनल्स सालों-साल नए जैसे रहते हैं।'
    },
    {
      id: 'faq-02',
      category: 'Installation',
      q_en: 'How long does it take to install a full TV feature wall or bedroom?',
      q_hi: 'एक टीवी फीचर वॉल या बेडरूम तैयार करने में कितना समय लगता है?',
      a_en: 'A standard TV unit feature wall (with charcoal louvers, UV marble slab, and warm LED profile lights) takes only 6 to 8 hours. An entire room typically finishes in 1 to 2 days without messy plastering or paint odor.',
      a_hi: 'एक सामान्य टीवी फीचर वॉल (चारकोल लवर + मार्बल शीट + प्रोफाइल लाइट) मात्र 6 से 8 घंटे में तैयार हो जाती है। पूरे कमरे का काम 1 से 2 दिन में बिना किसी धूल या बदबू के पूरा हो जाता है।'
    },
    {
      id: 'faq-03',
      category: 'Comparison',
      q_en: 'What is the difference between PVC panels and Charcoal Louvers?',
      q_hi: 'पीवीसी पैनल्स और चारकोल लवर्स में क्या अंतर है?',
      a_en: 'PVC panels are lightweight, tongue-and-groove hollow sheets (often 8.5mm to 10mm) priced very affordably (₹70–₹95/sq ft), ideal for overall room walls and ceilings. Charcoal louvers are heavy, solid extruded panels with deep architectural flutes and luxury metallic/matte textures (₹1,200–₹1,800/piece), specifically chosen for focal feature walls.',
      a_hi: 'पीवीसी पैनल किफायती और हल्के होते हैं जो पूरे कमरे की दीवारों और सीलिंग के लिए बहुत उपयुक्त हैं। चारकोल लवर्स भारी, सॉलिड और 3D ग्रूव्ज वाले होते हैं जो टीवी बैकड्रॉप, बेड हेडबोर्ड और हाई-एंड फीचर वॉल्स को फाइव-स्टार लुक देते हैं।'
    },
    {
      id: 'faq-04',
      category: 'Pricing',
      q_en: 'How do you calculate the total cost for my home?',
      q_hi: 'कुल लागत की गणना कैसे की जाती है?',
      a_en: 'Cost is based on exact wall square footage (Length × Height in feet) plus the chosen material grade (e.g. PVC, Charcoal, UV Marble) and lighting options. We provide a 100% free site visit to take exact measurements so there are no surprise costs.',
      a_hi: 'लागत दीवार के कुल वर्ग फुट (लंबाई × ऊंचाई) और आपके द्वारा चुने गए मटीरियल पर निर्भर करती है। हम घर पर आकर फ्री में सटीक नाप लेते हैं और पहले ही पूरा कोटेशन दे देते हैं।'
    },
    {
      id: 'faq-05',
      category: 'Maintenance',
      q_en: 'How do I clean and maintain these wall panels?',
      q_hi: 'इन पैनल्स की सफाई और रखरखाव कैसे किया जाता है?',
      a_en: 'Virtually zero maintenance! Simply wipe down dust with a soft microfibre cloth or a damp sponge with mild soapy water. The UV coating prevents staining and scratch marks.',
      a_hi: 'इनकी मेंटेनेंस बहुत आसान है। किसी मुलायम कपड़े या हल्के गीले स्पंज से पोंछने पर ये बिल्कुल नए जैसे चमकने लगते हैं। इन पर कभी पेंट या पॉलिश कराने की जरूरत नहीं पड़ती।'
    },
    {
      id: 'faq-06',
      category: 'Warranty',
      q_en: 'What warranty does AK Interior offer?',
      q_hi: 'एके इंटीरियर क्या वारंटी प्रदान करता है?',
      a_en: 'We offer a 10-year material guarantee against warping, termite attack, and delamination, along with a 1-year complimentary service warranty on all installation and lighting connections.',
      a_hi: 'हम दीमक, मुड़ने और मटीरियल डिफेक्ट पर 10 साल की वारंटी और सभी इंस्टॉलेशन व लाइटिंग फिटिंग पर 1 साल की फ्री सर्विस वारंटी देते हैं।'
    }
  ]
};

export const SEED_SETTINGS: Settings = {
  businessName: 'AK Interior',
  tagline_en: 'Premium PVC Panels • Charcoal Louvers • Architectural Lighting',
  tagline_hi: 'प्रीमियम पीवीसी पैनल्स • चारकोल लवर्स • आर्किटेक्चरल लाइटिंग',
  phone: '+91 98765 43210',
  whatsappNumber: '919876543210',
  email: 'contact@akinterior.in',
  address: 'Plot 42, Marble & Architectural Panels Complex, Mansarovar, Jaipur, Rajasthan 302020',
  googleMapsEmbedUrl: 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d113911.36531398864!2d75.71448883641214!3d26.885141673891054!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x396c4adf4c57e281%3A0xce1c63a0cf22e09!2sJaipur%2C%20Rajasthan!5e0!3m2!1sen!2sin!4v1700000000000!5m2!1sen!2sin',
  workingHours: 'Mon - Sat: 9:30 AM – 8:00 PM | Sunday: 10:30 AM – 5:00 PM',
  instagramUrl: 'https://instagram.com/akinterior_official',
  facebookUrl: 'https://facebook.com/akinteriorindia',
  youtubeUrl: 'https://youtube.com/@akinterior',
  seoTitle: 'AK Interior - Premium Wall Panels, Charcoal Louvers & Lighting in India',
  seoDescription: 'Leading supplier and installation experts for PVC wall panels, charcoal fluted louvers, WPC slats, UV marble sheets and architectural cove lighting across India.',
  accentColor: '#C9A24B'
};
