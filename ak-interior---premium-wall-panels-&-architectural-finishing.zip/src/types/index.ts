export type Language = 'en' | 'hi';

export interface Category {
  id: string;
  name_en: string;
  name_hi: string;
  slug: string;
  icon?: string;
  displayOrder: number;
  description_en: string;
  description_hi: string;
}

export interface Product {
  id: string;
  name_en: string;
  name_hi: string;
  categoryId: string;
  categorySlug: string;
  description_en: string;
  description_hi: string;
  size: string; // e.g., "8 ft x 5 in" or "8 ft x 4 ft"
  thickness: string; // e.g., "12 mm" or "3 mm UV Coated"
  finish_colors: string; // e.g., "Teak, Charcoal Grey, Champagne Gold, Walnut"
  price: number;
  priceUnit: string; // "sq ft", "piece", "running ft", "box"
  installationIncluded: boolean;
  images: string[];
  featured?: boolean;
  inStock?: boolean;
  displayOrder?: number;
  updatedAt?: string;
}

export interface GalleryItem {
  id: string;
  title_en: string;
  title_hi: string;
  category: 'living_room' | 'bedroom' | 'tv_unit' | 'office' | 'shop' | 'lights' | 'ceiling' | string;
  image: string;
  beforeImage?: string; // For Before/After interactive slider
  panelType: string;
  linkedProductId?: string;
  location: string;
  displayOrder?: number;
  updatedAt?: string;
}

export interface Testimonial {
  id: string;
  name: string;
  city: string;
  rating: number;
  review_en: string;
  review_hi: string;
  projectType: string;
  photo: string;
  approved: boolean;
  createdAt?: string;
}

export interface Enquiry {
  id: string;
  name: string;
  phone: string;
  city: string;
  service: string;
  approxAreaSqFt: string;
  message: string;
  status: 'new' | 'contacted' | 'closed';
  createdAt: string;
}

export interface WhyChooseUsItem {
  id: string;
  icon: string;
  title_en: string;
  title_hi: string;
  desc_en: string;
  desc_hi: string;
}

export interface ProcessStep {
  step: string;
  title_en: string;
  title_hi: string;
  desc_en: string;
  desc_hi: string;
}

export interface FAQItem {
  id: string;
  q_en: string;
  q_hi: string;
  a_en: string;
  a_hi: string;
  category: string;
}

export interface SiteContent {
  heroHeadline_en: string;
  heroHeadline_hi: string;
  heroSubheadline_en: string;
  heroSubheadline_hi: string;
  heroImages: string[];
  expYears: number;
  projectsCompleted: number;
  happyClients: number;
  guaranteeYears: number;
  aboutStory_en: string;
  aboutStory_hi: string;
  aboutOwnerName: string;
  aboutOwnerRole: string;
  whyChooseUs: WhyChooseUsItem[];
  processSteps: ProcessStep[];
  faqs: FAQItem[];
}

export interface Settings {
  businessName: string;
  tagline_en: string;
  tagline_hi: string;
  phone: string;
  whatsappNumber: string;
  email: string;
  address: string;
  googleMapsEmbedUrl: string;
  workingHours: string;
  instagramUrl: string;
  facebookUrl: string;
  youtubeUrl: string;
  seoTitle: string;
  seoDescription: string;
  accentColor: string;
}
