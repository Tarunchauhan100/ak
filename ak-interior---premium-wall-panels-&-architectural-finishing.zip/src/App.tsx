import React, { useState, useEffect } from 'react';
import { LanguageProvider } from './context/LanguageContext';
import { AuthProvider, useAuth } from './context/AuthContext';
import { DataProvider, useData } from './context/DataContext';

import { Navbar } from './components/common/Navbar';
import { Footer } from './components/common/Footer';
import { WhatsAppButton } from './components/common/WhatsAppButton';
import { QuoteModal } from './components/public/QuoteModal';

import { Hero } from './components/public/Hero';
import { CategoriesOverview } from './components/public/CategoriesOverview';
import { ProductsPricing } from './components/public/ProductsPricing';
import { CostCalculator } from './components/public/CostCalculator';
import { GallerySection } from './components/public/GallerySection';
import { WhyChooseUs } from './components/public/WhyChooseUs';
import { ProcessSection } from './components/public/ProcessSection';
import { AboutSection } from './components/public/AboutSection';
import { TestimonialsSection } from './components/public/TestimonialsSection';
import { FAQSection } from './components/public/FAQSection';
import { ContactSection } from './components/public/ContactSection';

import { AdminLogin } from './components/admin/AdminLogin';
import { AdminLayout } from './components/admin/AdminLayout';

function MainApp() {
  const { isAdmin } = useAuth();
  const { settings } = useData();

  const [isAdminView, setIsAdminView] = useState<boolean>(() => {
    return window.location.pathname.startsWith('/admin') || window.location.hash === '#admin';
  });

  const [isLoginModalOpen, setIsLoginModalOpen] = useState<boolean>(false);
  const [isQuoteModalOpen, setIsQuoteModalOpen] = useState<boolean>(false);
  const [quotePrefilledProduct, setQuotePrefilledProduct] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  // Handle URL changes & back/forward
  useEffect(() => {
    const handleLocationChange = () => {
      const isPathAdmin = window.location.pathname.startsWith('/admin') || window.location.hash === '#admin';
      setIsAdminView(isPathAdmin);
    };

    window.addEventListener('popstate', handleLocationChange);
    window.addEventListener('hashchange', handleLocationChange);
    return () => {
      window.removeEventListener('popstate', handleLocationChange);
      window.removeEventListener('hashchange', handleLocationChange);
    };
  }, []);

  const openAdmin = () => {
    if (isAdmin) {
      window.history.pushState({}, '', '#admin');
      setIsAdminView(true);
    } else {
      setIsLoginModalOpen(true);
    }
  };

  const closeAdmin = () => {
    window.history.pushState({}, '', '#home');
    setIsAdminView(false);
  };

  const handleOpenQuoteModal = (productName?: string) => {
    setQuotePrefilledProduct(productName || '');
    setIsQuoteModalOpen(true);
  };

  // If in Admin view and user is authorized, render AdminLayout
  if (isAdminView && isAdmin) {
    return <AdminLayout onBackToWebsite={closeAdmin} />;
  }

  return (
    <div className="min-h-screen bg-[#121212] text-[#F7F3EC] selection:bg-[#C9A24B] selection:text-[#121212] flex flex-col relative">
      {/* Sticky Top Navbar */}
      <Navbar
        onOpenQuoteModal={handleOpenQuoteModal}
        onOpenAdmin={openAdmin}
      />

      {/* Main Public Website Sections */}
      <main className="flex-1">
        {/* A) Hero screen with Ken Burns slideshow & live counters */}
        <Hero onOpenQuoteModal={handleOpenQuoteModal} />

        {/* B) What We Offer: Category cards */}
        <CategoriesOverview onSelectCategory={setSelectedCategory} />

        {/* C) Services & Pricing: Catalog with Grid vs Table toggle */}
        <ProductsPricing
          selectedCategoryId={selectedCategory}
          onSelectCategory={setSelectedCategory}
          onOpenQuoteModal={handleOpenQuoteModal}
        />

        {/* Interactive Wall & Lighting Cost Estimator */}
        <CostCalculator onOpenQuoteModal={handleOpenQuoteModal} />

        {/* D) Panel & Project Gallery with Lightbox & Before/After slider */}
        <GallerySection
          onOpenQuoteModal={handleOpenQuoteModal}
          onSelectCategory={setSelectedCategory}
        />

        {/* E) Why Choose Us */}
        <WhyChooseUs onOpenQuoteModal={handleOpenQuoteModal} />

        {/* F) Our 5-Step Process */}
        <ProcessSection onOpenQuoteModal={handleOpenQuoteModal} />

        {/* G) About Us & Craftsmen */}
        <AboutSection />

        {/* H) Customer Testimonials Carousel */}
        <TestimonialsSection />

        {/* I) Frequently Asked Questions */}
        <FAQSection />

        {/* J) Contact & Free Site Visit Booking */}
        <ContactSection />
      </main>

      {/* K) Footer */}
      <Footer
        onOpenAdmin={openAdmin}
        onOpenQuoteModal={handleOpenQuoteModal}
      />

      {/* Floating Action Button (WhatsApp & Mobile Quick-Call) */}
      <WhatsAppButton />

      {/* Quote & Free Site Visit Modal */}
      <QuoteModal
        isOpen={isQuoteModalOpen}
        onClose={() => setIsQuoteModalOpen(false)}
        prefilledProduct={quotePrefilledProduct}
      />

      {/* Admin Owner Login Modal */}
      {isLoginModalOpen && (
        <AdminLogin
          onClose={() => setIsLoginModalOpen(false)}
          onSuccess={() => {
            setIsLoginModalOpen(false);
            window.history.pushState({}, '', '#admin');
            setIsAdminView(true);
          }}
        />
      )}
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <DataProvider>
        <LanguageProvider>
          <MainApp />
        </LanguageProvider>
      </DataProvider>
    </AuthProvider>
  );
}
