import React from 'react';
import { useData } from '../../context/DataContext';
import { 
  Package, 
  Image as ImageIcon, 
  MessageSquare, 
  Users, 
  PhoneCall, 
  MessageCircle, 
  ArrowUpRight, 
  Plus, 
  Sparkles,
  TrendingUp,
  Clock,
  Layers,
  CheckCircle2
} from 'lucide-react';
import { Enquiry } from '../../types';

interface AdminDashboardProps {
  onNavigate: (tab: string) => void;
  onOpenAddProduct: () => void;
  onOpenAddGallery: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  onNavigate,
  onOpenAddProduct,
  onOpenAddGallery,
}) => {
  const { products, gallery, testimonials, enquiries, updateEnquiryStatus, settings } = useData();

  const newEnquiries = enquiries.filter(e => e.status === 'new');
  const contactedEnquiries = enquiries.filter(e => e.status === 'contacted');

  const handleStatusChange = async (enquiryId: string, status: Enquiry['status']) => {
    try {
      await updateEnquiryStatus(enquiryId, status);
    } catch (err) {
      console.error(err);
    }
  };

  const getWhatsAppLeadUrl = (enq: Enquiry) => {
    const text = encodeURIComponent(
      `Hello ${enq.name}, this is AK Interior regarding your inquiry for ${enq.service} (${enq.approxAreaSqFt} sq ft). When would be a good time for a free site visit?`
    );
    const cleanPhone = enq.phone.replace(/[^0-9]/g, '');
    const phoneWithCountry = cleanPhone.length === 10 ? `91${cleanPhone}` : cleanPhone;
    return `https://wa.me/${phoneWithCountry}?text=${text}`;
  };

  return (
    <div className="space-y-8">
      {/* Welcome Banner */}
      <div className="bg-gradient-to-r from-[#181818] via-[#201D16] to-[#181818] border border-[#C9A24B]/30 p-6 sm:p-8 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-xl">
        <div>
          <div className="flex items-center gap-2 text-[#C9A24B] text-xs font-semibold uppercase tracking-widest mb-1.5">
            <Sparkles className="w-3.5 h-3.5" />
            <span>AK Interior Control Dashboard</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-serif font-bold text-white tracking-wide">
            Namaste, Owner
          </h2>
          <p className="text-xs text-neutral-400 mt-1 max-w-xl">
            You have full live control over products, INR prices, gallery photos, and quotes. Any changes made here are reflected on the public website in real time.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={onOpenAddProduct}
            className="px-4 py-2.5 bg-[#C9A24B] hover:bg-[#DFC27E] text-[#121212] font-bold text-xs uppercase tracking-wider flex items-center gap-1.5 shadow-md transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>Add New Panel</span>
          </button>
          <button
            onClick={onOpenAddGallery}
            className="px-4 py-2.5 bg-neutral-900 border border-neutral-700 hover:border-[#C9A24B] text-white font-semibold text-xs uppercase tracking-wider flex items-center gap-1.5 transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>Upload Project</span>
          </button>
        </div>
      </div>

      {/* KPI Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
        {/* Stat 1: Enquiries */}
        <div 
          onClick={() => onNavigate('enquiries')}
          className="bg-[#181818] border border-neutral-800 hover:border-[#C9A24B]/50 p-5 cursor-pointer transition-all group"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-medium text-neutral-400 uppercase tracking-wider">
              New Enquiries
            </span>
            <div className="w-8 h-8 rounded-full bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="text-3xl font-serif font-bold text-white group-hover:text-gold-gradient transition-colors">
            {newEnquiries.length}
          </div>
          <div className="text-[11px] text-neutral-500 mt-1 flex items-center justify-between">
            <span>{enquiries.length} total leads received</span>
            <span className="text-[#C9A24B]">View Inbox →</span>
          </div>
        </div>

        {/* Stat 2: Products */}
        <div 
          onClick={() => onNavigate('products')}
          className="bg-[#181818] border border-neutral-800 hover:border-[#C9A24B]/50 p-5 cursor-pointer transition-all group"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-medium text-neutral-400 uppercase tracking-wider">
              Live Products
            </span>
            <div className="w-8 h-8 rounded-full bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-blue-400">
              <Package className="w-4 h-4" />
            </div>
          </div>
          <div className="text-3xl font-serif font-bold text-white group-hover:text-gold-gradient transition-colors">
            {products.length}
          </div>
          <div className="text-[11px] text-neutral-500 mt-1 flex items-center justify-between">
            <span>Panels, lights & ceilings</span>
            <span className="text-[#C9A24B]">Manage →</span>
          </div>
        </div>

        {/* Stat 3: Gallery Portfolio */}
        <div 
          onClick={() => onNavigate('gallery')}
          className="bg-[#181818] border border-neutral-800 hover:border-[#C9A24B]/50 p-5 cursor-pointer transition-all group"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-medium text-neutral-400 uppercase tracking-wider">
              Gallery Projects
            </span>
            <div className="w-8 h-8 rounded-full bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <ImageIcon className="w-4 h-4" />
            </div>
          </div>
          <div className="text-3xl font-serif font-bold text-white group-hover:text-gold-gradient transition-colors">
            {gallery.length}
          </div>
          <div className="text-[11px] text-neutral-500 mt-1 flex items-center justify-between">
            <span>Showcase installations</span>
            <span className="text-[#C9A24B]">View →</span>
          </div>
        </div>

        {/* Stat 4: Testimonials */}
        <div 
          onClick={() => onNavigate('testimonials')}
          className="bg-[#181818] border border-neutral-800 hover:border-[#C9A24B]/50 p-5 cursor-pointer transition-all group"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-medium text-neutral-400 uppercase tracking-wider">
              Client Reviews
            </span>
            <div className="w-8 h-8 rounded-full bg-purple-500/10 border border-purple-500/30 flex items-center justify-center text-purple-400">
              <MessageSquare className="w-4 h-4" />
            </div>
          </div>
          <div className="text-3xl font-serif font-bold text-white group-hover:text-gold-gradient transition-colors">
            {testimonials.length}
          </div>
          <div className="text-[11px] text-neutral-500 mt-1 flex items-center justify-between">
            <span>Verified 5-star feedback</span>
            <span className="text-[#C9A24B]">Manage →</span>
          </div>
        </div>
      </div>

      {/* Recent Enquiries Section */}
      <div className="bg-[#181818] border border-neutral-800 p-6 space-y-4">
        <div className="flex items-center justify-between border-b border-neutral-800 pb-4">
          <div>
            <h3 className="text-lg font-serif font-bold text-white tracking-wide">
              Recent Quote Requests & Inquiries
            </h3>
            <p className="text-xs text-neutral-400">
              Prospective clients who submitted the site visit / quote form on the website.
            </p>
          </div>

          <button
            onClick={() => onNavigate('enquiries')}
            className="text-xs text-[#DFC27E] hover:underline flex items-center gap-1 font-medium"
          >
            <span>View All ({enquiries.length})</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {enquiries.length === 0 ? (
          <div className="text-center py-12 text-neutral-500 text-xs">
            No quote enquiries submitted yet. When customers submit the form on the website, they will appear here immediately.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#1F1F1F] text-neutral-400 uppercase font-mono tracking-wider border-b border-neutral-800">
                <tr>
                  <th className="py-3 px-4">Customer</th>
                  <th className="py-3 px-4">Contact</th>
                  <th className="py-3 px-4">Location</th>
                  <th className="py-3 px-4">Service & Area</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-center">One-Click Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-800">
                {enquiries.slice(0, 5).map((enq) => (
                  <tr key={enq.id} className="hover:bg-neutral-800/40 transition-colors">
                    <td className="py-3.5 px-4 font-semibold text-white">
                      <div>{enq.name}</div>
                      <span className="text-[10px] text-neutral-500 font-mono">
                        {enq.createdAt ? new Date(enq.createdAt).toLocaleDateString() : 'Recent'}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 font-mono text-neutral-300">
                      <a href={`tel:${enq.phone.replace(/[^0-9+]/g, '')}`} className="hover:text-[#DFC27E]">
                        {enq.phone}
                      </a>
                    </td>
                    <td className="py-3.5 px-4 text-neutral-400">
                      {enq.city || 'N/A'}
                    </td>
                    <td className="py-3.5 px-4 text-neutral-300">
                      <div className="font-medium text-white">{enq.service}</div>
                      <span className="text-[10px] text-neutral-400">{enq.approxAreaSqFt} sq ft</span>
                    </td>
                    <td className="py-3.5 px-4">
                      <select
                        value={enq.status}
                        onChange={(e) => handleStatusChange(enq.id, e.target.value as Enquiry['status'])}
                        className={`text-[11px] font-semibold uppercase px-2 py-1 rounded-none border focus:outline-none ${
                          enq.status === 'new'
                            ? 'bg-amber-950/60 border-amber-600 text-amber-300'
                            : enq.status === 'contacted'
                            ? 'bg-blue-950/60 border-blue-600 text-blue-300'
                            : 'bg-emerald-950/60 border-emerald-600 text-emerald-300'
                        }`}
                      >
                        <option value="new" className="bg-[#181818] text-white">New Lead</option>
                        <option value="contacted" className="bg-[#181818] text-white">Contacted</option>
                        <option value="closed" className="bg-[#181818] text-white">Closed / Won</option>
                      </select>
                    </td>
                    <td className="py-3.5 px-4 text-center">
                      <div className="flex items-center justify-center gap-2">
                        <a
                          href={getWhatsAppLeadUrl(enq)}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="p-1.5 bg-[#25D366]/20 hover:bg-[#25D366]/30 border border-[#25D366]/40 text-[#25D366]"
                          title="Reply on WhatsApp"
                        >
                          <MessageCircle className="w-3.5 h-3.5" />
                        </a>
                        <a
                          href={`tel:${enq.phone.replace(/[^0-9+]/g, '')}`}
                          className="p-1.5 bg-neutral-800 hover:bg-neutral-700 border border-neutral-700 text-neutral-200"
                          title="Call Customer"
                        >
                          <PhoneCall className="w-3.5 h-3.5" />
                        </a>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
