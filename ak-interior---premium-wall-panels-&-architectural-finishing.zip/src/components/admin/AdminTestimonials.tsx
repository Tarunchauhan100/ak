import React, { useState } from 'react';
import { useData } from '../../context/DataContext';
import { Testimonial } from '../../types';
import { Plus, Edit3, Trash2, X, Star, CheckCircle, Eye, EyeOff } from 'lucide-react';

export const AdminTestimonials: React.FC = () => {
  const { testimonials, addTestimonial, updateTestimonial, deleteTestimonial } = useData();

  const [modalOpen, setModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<Testimonial | null>(null);

  const [form, setForm] = useState({
    name: '',
    city: 'Jaipur, Rajasthan',
    rating: 5,
    review_en: '',
    review_hi: '',
    projectType: '3BHK Living Room Wall Panelling',
    photo: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
    approved: true,
  });

  const openAdd = () => {
    setEditingItem(null);
    setForm({
      name: '',
      city: 'Jaipur, Rajasthan',
      rating: 5,
      review_en: '',
      review_hi: '',
      projectType: '3BHK Living Room TV Media Wall',
      photo: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
      approved: true,
    });
    setModalOpen(true);
  };

  const openEdit = (t: Testimonial) => {
    setEditingItem(t);
    setForm({
      name: t.name,
      city: t.city,
      rating: t.rating,
      review_en: t.review_en,
      review_hi: t.review_hi,
      projectType: t.projectType,
      photo: t.photo,
      approved: t.approved !== false,
    });
    setModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editingItem) {
        await updateTestimonial(editingItem.id, form);
      } else {
        await addTestimonial(form);
      }
      setModalOpen(false);
    } catch (err) {
      console.error(err);
      alert('Error saving testimonial.');
    }
  };

  const handleDelete = async (id: string, name: string) => {
    if (confirm(`Delete testimonial from "${name}"?`)) {
      try {
        await deleteTestimonial(id);
      } catch (err) {
        console.error(err);
      }
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 bg-[#181818] border border-neutral-800 p-5">
        <div>
          <h2 className="text-xl font-serif font-bold text-white tracking-wide">
            Client Testimonials Manager
          </h2>
          <p className="text-xs text-neutral-400">
            Publish client feedback, manage star ratings, and toggle display approvals.
          </p>
        </div>

        <button
          onClick={openAdd}
          className="px-4 py-2.5 bg-[#C9A24B] hover:bg-[#DFC27E] text-[#121212] text-xs font-bold uppercase tracking-wider flex items-center gap-2 cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Add Testimonial</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {testimonials.map((t) => (
          <div
            key={t.id}
            className="bg-[#181818] border border-neutral-800 p-6 flex flex-col justify-between hover:border-[#C9A24B]/40 transition-colors"
          >
            <div>
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <img
                    src={t.photo || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=100&q=80'}
                    alt={t.name}
                    className="w-12 h-12 rounded-full object-cover border border-[#C9A24B]"
                  />
                  <div>
                    <h3 className="font-serif font-bold text-white text-base">{t.name}</h3>
                    <p className="text-xs text-[#DFC27E]">{t.city}</p>
                    <span className="text-[10px] text-neutral-400 font-light">{t.projectType}</span>
                  </div>
                </div>

                <button
                  onClick={() => updateTestimonial(t.id, { approved: !(t.approved !== false) })}
                  className={`px-2 py-1 text-[10px] uppercase font-mono border flex items-center gap-1 ${
                    t.approved !== false
                      ? 'border-emerald-700/60 text-emerald-400 bg-emerald-950/30'
                      : 'border-neutral-700 text-neutral-500 bg-neutral-900'
                  }`}
                >
                  {t.approved !== false ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3" />}
                  <span>{t.approved !== false ? 'Approved' : 'Hidden'}</span>
                </button>
              </div>

              {/* Stars */}
              <div className="flex items-center gap-1 text-[#C9A24B] mb-3">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`w-3.5 h-3.5 ${i < t.rating ? 'fill-[#C9A24B]' : 'text-neutral-700'}`}
                  />
                ))}
              </div>

              <p className="text-xs text-neutral-300 italic mb-2 leading-relaxed">
                "{t.review_en}"
              </p>
              {t.review_hi && (
                <p className="text-xs text-neutral-400 font-hindi leading-relaxed">
                  "{t.review_hi}"
                </p>
              )}
            </div>

            <div className="pt-4 border-t border-neutral-800/80 mt-4 flex items-center justify-end gap-3">
              <button
                onClick={() => openEdit(t)}
                className="text-xs text-neutral-400 hover:text-white flex items-center gap-1"
              >
                <Edit3 className="w-3.5 h-3.5" />
                <span>Edit</span>
              </button>
              <button
                onClick={() => handleDelete(t.id, t.name)}
                className="text-xs text-red-400 hover:text-red-300 flex items-center gap-1 ml-2"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Delete</span>
              </button>
            </div>
          </div>
        ))}
      </div>

      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
          <div className="bg-[#181818] border border-[#C9A24B]/40 max-w-lg w-full max-h-[90vh] overflow-y-auto p-6 space-y-4 text-neutral-200">
            <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
              <h3 className="text-base font-serif font-bold text-white">
                {editingItem ? 'Edit Review' : 'Add Client Review'}
              </h3>
              <button onClick={() => setModalOpen(false)} className="text-neutral-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-neutral-300 mb-1">Client Name *</label>
                  <input
                    type="text"
                    required
                    value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                    className="w-full bg-[#121212] border border-neutral-700 px-3 py-2 text-sm text-white focus:outline-none focus:border-[#C9A24B]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-neutral-300 mb-1">City / State *</label>
                  <input
                    type="text"
                    required
                    value={form.city}
                    onChange={(e) => setForm({ ...form, city: e.target.value })}
                    className="w-full bg-[#121212] border border-neutral-700 px-3 py-2 text-sm text-white focus:outline-none focus:border-[#C9A24B]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-neutral-300 mb-1">Rating (1 to 5 Stars)</label>
                  <select
                    value={form.rating}
                    onChange={(e) => setForm({ ...form, rating: Number(e.target.value) })}
                    className="w-full bg-[#121212] border border-neutral-700 px-3 py-2 text-sm text-white focus:outline-none focus:border-[#C9A24B]"
                  >
                    <option value={5}>5 Stars (Excellent)</option>
                    <option value={4}>4 Stars (Good)</option>
                    <option value={3}>3 Stars</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-neutral-300 mb-1">Project Executed</label>
                  <input
                    type="text"
                    value={form.projectType}
                    onChange={(e) => setForm({ ...form, projectType: e.target.value })}
                    placeholder="e.g. Living Room TV Media Wall"
                    className="w-full bg-[#121212] border border-neutral-700 px-3 py-2 text-sm text-white focus:outline-none focus:border-[#C9A24B]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-neutral-300 mb-1">Photo URL</label>
                <input
                  type="text"
                  value={form.photo}
                  onChange={(e) => setForm({ ...form, photo: e.target.value })}
                  placeholder="https://images.unsplash.com/..."
                  className="w-full bg-[#121212] border border-neutral-700 px-3 py-2 text-sm text-white focus:outline-none focus:border-[#C9A24B]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-neutral-300 mb-1">Review (English) *</label>
                <textarea
                  rows={3}
                  required
                  value={form.review_en}
                  onChange={(e) => setForm({ ...form, review_en: e.target.value })}
                  className="w-full bg-[#121212] border border-neutral-700 px-3 py-2 text-sm text-white focus:outline-none focus:border-[#C9A24B]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-neutral-300 mb-1">Review (Hindi)</label>
                <textarea
                  rows={2}
                  value={form.review_hi}
                  onChange={(e) => setForm({ ...form, review_hi: e.target.value })}
                  className="w-full bg-[#121212] border border-neutral-700 px-3 py-2 text-sm text-white focus:outline-none focus:border-[#C9A24B]"
                />
              </div>

              <div className="pt-2">
                <label className="flex items-center gap-2 text-xs cursor-pointer">
                  <input
                    type="checkbox"
                    checked={form.approved}
                    onChange={(e) => setForm({ ...form, approved: e.target.checked })}
                    className="accent-[#C9A24B]"
                  />
                  <span>Approved for display on website carousel</span>
                </label>
              </div>

              <div className="pt-3 border-t border-neutral-800 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2 text-xs text-neutral-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-[#C9A24B] hover:bg-[#DFC27E] text-[#121212] font-bold text-xs uppercase tracking-wider"
                >
                  Save Review
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
