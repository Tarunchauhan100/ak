import React, { useState } from 'react';
import { useData } from '../../context/DataContext';
import { Product } from '../../types';
import { 
  Plus, 
  Search, 
  Edit3, 
  Trash2, 
  Check, 
  X, 
  Sparkles, 
  Percent, 
  ArrowUpDown,
  Image as ImageIcon
} from 'lucide-react';

interface AdminProductsProps {
  // Can be controlled
}

export const AdminProducts: React.FC<AdminProductsProps> = () => {
  const { products, categories, addProduct, updateProduct, deleteProduct, bulkUpdatePrices } = useData();

  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [modalOpen, setModalOpen] = useState(false);
  const [bulkModalOpen, setBulkModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);

  // Form state
  const [form, setForm] = useState({
    name_en: '',
    name_hi: '',
    categoryId: 'charcoal-panels',
    categorySlug: 'charcoal-panels',
    description_en: '',
    description_hi: '',
    size: '8 ft × 5 inch',
    thickness: '12 mm',
    finish_colors: 'Midnight Black, Teak, Charcoal Grey',
    price: 1350,
    priceUnit: 'piece',
    installationIncluded: false,
    images: 'https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&w=1200&q=80',
    featured: false,
    inStock: true,
  });

  // Bulk update state
  const [bulkCat, setBulkCat] = useState('all');
  const [percentDelta, setPercentDelta] = useState(0);
  const [flatDelta, setFlatDelta] = useState(0);
  const [bulkMessage, setBulkMessage] = useState('');

  const filteredProducts = products.filter(p => {
    const matchCat = selectedCategory === 'all' || p.categoryId === selectedCategory || p.categorySlug === selectedCategory;
    const matchSearch = !search || p.name_en.toLowerCase().includes(search.toLowerCase()) || p.size.toLowerCase().includes(search.toLowerCase());
    return matchCat && matchSearch;
  });

  const openAddModal = () => {
    setEditingProduct(null);
    setForm({
      name_en: '',
      name_hi: '',
      categoryId: categories[0]?.id || 'charcoal-panels',
      categorySlug: categories[0]?.slug || 'charcoal-panels',
      description_en: '',
      description_hi: '',
      size: '8 ft × 5 inch',
      thickness: '12 mm',
      finish_colors: 'Midnight Black, Teak, Charcoal Grey',
      price: 1200,
      priceUnit: 'piece',
      installationIncluded: false,
      images: 'https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&w=1200&q=80',
      featured: false,
      inStock: true,
    });
    setModalOpen(true);
  };

  const openEditModal = (p: Product) => {
    setEditingProduct(p);
    setForm({
      name_en: p.name_en,
      name_hi: p.name_hi,
      categoryId: p.categoryId,
      categorySlug: p.categorySlug,
      description_en: p.description_en,
      description_hi: p.description_hi,
      size: p.size,
      thickness: p.thickness,
      finish_colors: p.finish_colors,
      price: p.price,
      priceUnit: p.priceUnit,
      installationIncluded: p.installationIncluded,
      images: p.images?.join(', ') || '',
      featured: !!p.featured,
      inStock: p.inStock !== false,
    });
    setModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    const imageList = form.images
      .split(',')
      .map(s => s.trim())
      .filter(s => s.length > 0);

    const targetCategory = categories.find(c => c.id === form.categoryId);

    const productPayload = {
      name_en: form.name_en,
      name_hi: form.name_hi,
      categoryId: form.categoryId,
      categorySlug: targetCategory?.slug || form.categoryId,
      description_en: form.description_en,
      description_hi: form.description_hi,
      size: form.size,
      thickness: form.thickness,
      finish_colors: form.finish_colors,
      price: Number(form.price),
      priceUnit: form.priceUnit,
      installationIncluded: Boolean(form.installationIncluded),
      images: imageList.length ? imageList : ['https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=800&q=80'],
      featured: form.featured,
      inStock: form.inStock,
    };

    try {
      if (editingProduct) {
        await updateProduct(editingProduct.id, productPayload);
      } else {
        await addProduct(productPayload);
      }
      setModalOpen(false);
    } catch (err) {
      console.error(err);
      alert('Error saving product. Check console.');
    }
  };

  const handleDelete = async (id: string, name: string) => {
    if (confirm(`Are you sure you want to delete "${name}"?`)) {
      try {
        await deleteProduct(id);
      } catch (err) {
        console.error(err);
      }
    }
  };

  const handleBulkUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const count = await bulkUpdatePrices(bulkCat, Number(percentDelta), Number(flatDelta));
      setBulkMessage(`Successfully updated prices for ${count} product(s)!`);
      setTimeout(() => {
        setBulkMessage('');
        setBulkModalOpen(false);
      }, 1500);
    } catch (err) {
      console.error(err);
      setBulkMessage('Failed to execute bulk update.');
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Action Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 bg-[#181818] border border-neutral-800 p-5">
        <div>
          <h2 className="text-xl font-serif font-bold text-white tracking-wide">
            Panels, Products & Pricing Manager
          </h2>
          <p className="text-xs text-neutral-400">
            Add new designs, modify per-sq-ft or per-piece rates, or run bulk price adjustments.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setBulkModalOpen(true)}
            className="px-4 py-2.5 bg-neutral-900 border border-neutral-700 hover:border-[#C9A24B] text-neutral-200 text-xs font-semibold uppercase tracking-wider flex items-center gap-2"
          >
            <Percent className="w-3.5 h-3.5 text-[#C9A24B]" />
            <span>Bulk Price Update</span>
          </button>

          <button
            onClick={openAddModal}
            className="px-4 py-2.5 bg-[#C9A24B] hover:bg-[#DFC27E] text-[#121212] text-xs font-bold uppercase tracking-wider flex items-center gap-2 shadow-md cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Add Product</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4">
        <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
          <button
            onClick={() => setSelectedCategory('all')}
            className={`px-3 py-1.5 text-xs font-semibold uppercase ${
              selectedCategory === 'all'
                ? 'bg-[#C9A24B] text-[#121212]'
                : 'bg-[#181818] text-neutral-300 border border-neutral-800'
            }`}
          >
            All ({products.length})
          </button>
          {categories.map(c => (
            <button
              key={c.id}
              onClick={() => setSelectedCategory(c.id)}
              className={`px-3 py-1.5 text-xs font-semibold uppercase whitespace-nowrap ${
                selectedCategory === c.id
                  ? 'bg-[#C9A24B] text-[#121212]'
                  : 'bg-[#181818] text-neutral-300 border border-neutral-800'
              }`}
            >
              {c.name_en}
            </button>
          ))}
        </div>

        <div className="relative max-w-xs w-full">
          <Search className="w-4 h-4 text-neutral-500 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search panels..."
            className="w-full bg-[#181818] border border-neutral-700 pl-9 pr-3 py-1.5 text-xs text-white focus:outline-none focus:border-[#C9A24B]"
          />
        </div>
      </div>

      {/* Products Table */}
      <div className="bg-[#181818] border border-neutral-800 overflow-x-auto shadow-xl">
        <table className="w-full text-left text-xs">
          <thead className="bg-[#1F1F1F] text-neutral-400 uppercase font-mono tracking-wider border-b border-neutral-800">
            <tr>
              <th className="py-3 px-4">Panel Details</th>
              <th className="py-3 px-4">Category</th>
              <th className="py-3 px-4">Size & Thickness</th>
              <th className="py-3 px-4">Price (INR)</th>
              <th className="py-3 px-4">Fitting</th>
              <th className="py-3 px-4">Status</th>
              <th className="py-3 px-4 text-center">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-neutral-800">
            {filteredProducts.map((p) => {
              const catObj = categories.find(c => c.id === p.categoryId || c.slug === p.categorySlug);

              return (
                <tr key={p.id} className="hover:bg-neutral-800/40 transition-colors">
                  <td className="py-3.5 px-4">
                    <div className="flex items-center gap-3">
                      <img
                        src={p.images?.[0] || 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=100&q=80'}
                        alt={p.name_en}
                        className="w-12 h-12 object-cover border border-neutral-700 shrink-0"
                      />
                      <div>
                        <div className="font-serif font-bold text-sm text-white">{p.name_en}</div>
                        <div className="text-[11px] text-neutral-400 font-hindi">{p.name_hi}</div>
                        {p.featured && (
                          <span className="text-[10px] text-[#DFC27E] uppercase font-mono tracking-wider font-semibold">
                            ★ Featured
                          </span>
                        )}
                      </div>
                    </div>
                  </td>
                  <td className="py-3.5 px-4 text-neutral-300">
                    {catObj ? catObj.name_en : p.categorySlug}
                  </td>
                  <td className="py-3.5 px-4 font-mono text-neutral-300">
                    <div>{p.size}</div>
                    <div className="text-[10px] text-neutral-500">{p.thickness}</div>
                  </td>
                  <td className="py-3.5 px-4">
                    <span className="font-serif font-bold text-base text-gold-gradient">
                      ₹{p.price.toLocaleString('en-IN')}
                    </span>
                    <span className="text-[10px] text-neutral-400 font-mono block">
                      / {p.priceUnit}
                    </span>
                  </td>
                  <td className="py-3.5 px-4">
                    {p.installationIncluded ? (
                      <span className="text-emerald-400 font-medium">Included</span>
                    ) : (
                      <span className="text-neutral-500">Material Only</span>
                    )}
                  </td>
                  <td className="py-3.5 px-4">
                    <button
                      onClick={() => updateProduct(p.id, { inStock: !(p.inStock !== false) })}
                      className={`px-2 py-0.5 text-[10px] font-mono uppercase border ${
                        p.inStock !== false
                          ? 'border-emerald-700/60 text-emerald-400 bg-emerald-950/30'
                          : 'border-neutral-700 text-neutral-500 bg-neutral-900'
                      }`}
                    >
                      {p.inStock !== false ? 'In Stock' : 'Out of Stock'}
                    </button>
                  </td>
                  <td className="py-3.5 px-4 text-center">
                    <div className="flex items-center justify-center gap-2">
                      <button
                        onClick={() => openEditModal(p)}
                        className="p-1.5 text-neutral-400 hover:text-[#C9A24B] hover:bg-neutral-800 transition-colors"
                        title="Edit Product"
                      >
                        <Edit3 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDelete(p.id, p.name_en)}
                        className="p-1.5 text-neutral-400 hover:text-red-400 hover:bg-neutral-800 transition-colors"
                        title="Delete Product"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Add / Edit Product Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
          <div className="bg-[#181818] border border-[#C9A24B]/40 max-w-2xl w-full max-h-[90vh] overflow-y-auto p-6 space-y-5 text-neutral-200">
            <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
              <h3 className="text-lg font-serif font-bold text-white">
                {editingProduct ? 'Edit Product & Pricing' : 'Add New Panel / Lighting Product'}
              </h3>
              <button onClick={() => setModalOpen(false)} className="text-neutral-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-neutral-300 mb-1">
                    Product Name (English) *
                  </label>
                  <input
                    type="text"
                    required
                    value={form.name_en}
                    onChange={(e) => setForm({ ...form, name_en: e.target.value })}
                    className="w-full bg-[#121212] border border-neutral-700 px-3 py-2 text-sm text-white focus:outline-none focus:border-[#C9A24B]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-neutral-300 mb-1">
                    Product Name (Hindi)
                  </label>
                  <input
                    type="text"
                    value={form.name_hi}
                    onChange={(e) => setForm({ ...form, name_hi: e.target.value })}
                    className="w-full bg-[#121212] border border-neutral-700 px-3 py-2 text-sm text-white focus:outline-none focus:border-[#C9A24B]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-neutral-300 mb-1">
                    Category *
                  </label>
                  <select
                    value={form.categoryId}
                    onChange={(e) => setForm({ ...form, categoryId: e.target.value })}
                    className="w-full bg-[#121212] border border-neutral-700 px-3 py-2 text-sm text-white focus:outline-none focus:border-[#C9A24B]"
                  >
                    {categories.map(c => (
                      <option key={c.id} value={c.id}>{c.name_en}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-neutral-300 mb-1">
                    Price (INR) *
                  </label>
                  <input
                    type="number"
                    required
                    value={form.price}
                    onChange={(e) => setForm({ ...form, price: Number(e.target.value) })}
                    className="w-full bg-[#121212] border border-neutral-700 px-3 py-2 text-sm text-white focus:outline-none focus:border-[#C9A24B]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-neutral-300 mb-1">
                    Price Unit *
                  </label>
                  <select
                    value={form.priceUnit}
                    onChange={(e) => setForm({ ...form, priceUnit: e.target.value })}
                    className="w-full bg-[#121212] border border-neutral-700 px-3 py-2 text-sm text-white focus:outline-none focus:border-[#C9A24B]"
                  >
                    <option value="sq ft">sq ft</option>
                    <option value="piece">piece</option>
                    <option value="running ft">running ft</option>
                    <option value="set">set</option>
                    <option value="box">box</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-neutral-300 mb-1">
                    Dimensions / Size
                  </label>
                  <input
                    type="text"
                    value={form.size}
                    onChange={(e) => setForm({ ...form, size: e.target.value })}
                    placeholder="e.g. 8 ft x 5 in"
                    className="w-full bg-[#121212] border border-neutral-700 px-3 py-2 text-sm text-white focus:outline-none focus:border-[#C9A24B]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-neutral-300 mb-1">
                    Thickness / Profile
                  </label>
                  <input
                    type="text"
                    value={form.thickness}
                    onChange={(e) => setForm({ ...form, thickness: e.target.value })}
                    placeholder="e.g. 12 mm"
                    className="w-full bg-[#121212] border border-neutral-700 px-3 py-2 text-sm text-white focus:outline-none focus:border-[#C9A24B]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-neutral-300 mb-1">
                    Available Finishes / Colors
                  </label>
                  <input
                    type="text"
                    value={form.finish_colors}
                    onChange={(e) => setForm({ ...form, finish_colors: e.target.value })}
                    placeholder="e.g. Teak, Champagne Gold, Black"
                    className="w-full bg-[#121212] border border-neutral-700 px-3 py-2 text-sm text-white focus:outline-none focus:border-[#C9A24B]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-neutral-300 mb-1">
                  Image URLs (comma-separated URLs)
                </label>
                <input
                  type="text"
                  value={form.images}
                  onChange={(e) => setForm({ ...form, images: e.target.value })}
                  placeholder="https://images.unsplash.com/..."
                  className="w-full bg-[#121212] border border-neutral-700 px-3 py-2 text-sm text-white focus:outline-none focus:border-[#C9A24B]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-neutral-300 mb-1">
                  Description (English)
                </label>
                <textarea
                  rows={2}
                  value={form.description_en}
                  onChange={(e) => setForm({ ...form, description_en: e.target.value })}
                  className="w-full bg-[#121212] border border-neutral-700 px-3 py-2 text-sm text-white focus:outline-none focus:border-[#C9A24B]"
                />
              </div>

              <div className="flex flex-wrap items-center gap-6 pt-2">
                <label className="flex items-center gap-2 text-xs cursor-pointer">
                  <input
                    type="checkbox"
                    checked={form.installationIncluded}
                    onChange={(e) => setForm({ ...form, installationIncluded: e.target.checked })}
                    className="accent-[#C9A24B]"
                  />
                  <span>Installation included in price</span>
                </label>

                <label className="flex items-center gap-2 text-xs cursor-pointer">
                  <input
                    type="checkbox"
                    checked={form.featured}
                    onChange={(e) => setForm({ ...form, featured: e.target.checked })}
                    className="accent-[#C9A24B]"
                  />
                  <span>Featured on Home Page</span>
                </label>

                <label className="flex items-center gap-2 text-xs cursor-pointer">
                  <input
                    type="checkbox"
                    checked={form.inStock}
                    onChange={(e) => setForm({ ...form, inStock: e.target.checked })}
                    className="accent-[#C9A24B]"
                  />
                  <span>In Stock</span>
                </label>
              </div>

              <div className="pt-4 border-t border-neutral-800 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2 text-xs text-neutral-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-[#C9A24B] hover:bg-[#DFC27E] text-[#121212] font-bold text-xs uppercase tracking-wider"
                >
                  Save Product
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Bulk Price Update Modal */}
      {bulkModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
          <div className="bg-[#181818] border border-[#C9A24B]/40 max-w-md w-full p-6 space-y-4 text-neutral-200 shadow-2xl">
            <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
              <h3 className="text-base font-serif font-bold text-white flex items-center gap-2">
                <Percent className="w-4 h-4 text-[#C9A24B]" />
                <span>Bulk Price Adjustment</span>
              </h3>
              <button onClick={() => setBulkModalOpen(false)} className="text-neutral-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-neutral-400">
              Quickly adjust prices across an entire category (e.g. apply 10% festival hike or ₹50 discount).
            </p>

            {bulkMessage && (
              <div className="p-3 bg-neutral-900 border border-[#C9A24B] text-xs text-[#DFC27E]">
                {bulkMessage}
              </div>
            )}

            <form onSubmit={handleBulkUpdate} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-neutral-300 mb-1">
                  Target Category
                </label>
                <select
                  value={bulkCat}
                  onChange={(e) => setBulkCat(e.target.value)}
                  className="w-full bg-[#121212] border border-neutral-700 px-3 py-2 text-sm text-white focus:outline-none focus:border-[#C9A24B]"
                >
                  <option value="all">All Categories</option>
                  {categories.map(c => (
                    <option key={c.id} value={c.id}>{c.name_en}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-neutral-300 mb-1">
                  Percentage Adjustment (%)
                </label>
                <input
                  type="number"
                  step="0.5"
                  value={percentDelta}
                  onChange={(e) => setPercentDelta(Number(e.target.value))}
                  placeholder="e.g. 10 for +10% or -5 for -5%"
                  className="w-full bg-[#121212] border border-neutral-700 px-3 py-2 text-sm text-white focus:outline-none focus:border-[#C9A24B]"
                />
                <span className="text-[10px] text-neutral-500 mt-0.5 block">Enter positive number to increase, negative to decrease.</span>
              </div>

              <div>
                <label className="block text-xs font-semibold text-neutral-300 mb-1">
                  Flat INR Adjustment (₹)
                </label>
                <input
                  type="number"
                  step="1"
                  value={flatDelta}
                  onChange={(e) => setFlatDelta(Number(e.target.value))}
                  placeholder="e.g. 50 or -50"
                  className="w-full bg-[#121212] border border-neutral-700 px-3 py-2 text-sm text-white focus:outline-none focus:border-[#C9A24B]"
                />
              </div>

              <div className="pt-3 border-t border-neutral-800 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setBulkModalOpen(false)}
                  className="px-4 py-2 text-xs text-neutral-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-[#C9A24B] hover:bg-[#DFC27E] text-[#121212] font-bold text-xs uppercase tracking-wider"
                >
                  Apply Updates Now
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
