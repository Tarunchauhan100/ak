import React, { useState } from 'react';
import { useData } from '../../context/DataContext';
import { GalleryItem } from '../../types';
import { Plus, Edit3, Trash2, X, Image as ImageIcon, MapPin, Layers, SplitSquareHorizontal } from 'lucide-react';

export const AdminGallery: React.FC = () => {
  const { gallery, products, addGalleryItem, updateGalleryItem, deleteGalleryItem } = useData();

  const [modalOpen, setModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<GalleryItem | null>(null);

  const [form, setForm] = useState({
    title_en: '',
    title_hi: '',
    category: 'tv_unit',
    image: '',
    beforeImage: '',
    panelType: 'Charcoal Louvers + LED Profile',
    linkedProductId: '',
    location: 'Jaipur, Rajasthan',
    displayOrder: 1,
  });

  const openAdd = () => {
    setEditingItem(null);
    setForm({
      title_en: '',
      title_hi: '',
      category: 'tv_unit',
      image: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&q=80',
      beforeImage: '',
      panelType: 'Charcoal Fluted Louvers + Statuario UV Marble + 3000K Cove LED',
      linkedProductId: products[0]?.id || '',
      location: 'Jaipur, Rajasthan',
      displayOrder: gallery.length + 1,
    });
    setModalOpen(true);
  };

  const openEdit = (item: GalleryItem) => {
    setEditingItem(item);
    setForm({
      title_en: item.title_en,
      title_hi: item.title_hi,
      category: item.category,
      image: item.image,
      beforeImage: item.beforeImage || '',
      panelType: item.panelType,
      linkedProductId: item.linkedProductId || '',
      location: item.location,
      displayOrder: item.displayOrder || 1,
    });
    setModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.image.trim()) {
      alert('Please provide an image URL');
      return;
    }

    try {
      if (editingItem) {
        await updateGalleryItem(editingItem.id, form);
      } else {
        await addGalleryItem(form);
      }
      setModalOpen(false);
    } catch (err) {
      console.error(err);
      alert('Error saving gallery item.');
    }
  };

  const handleDelete = async (id: string, title: string) => {
    if (confirm(`Delete project "${title}"?`)) {
      try {
        await deleteGalleryItem(id);
      } catch (err) {
        console.error(err);
      }
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 bg-[#181818] border border-neutral-800 p-5">
        <div>
          <h2 className="text-xl font-serif font-bold text-white tracking-wide">
            Portfolio Gallery Manager
          </h2>
          <p className="text-xs text-neutral-400">
            Showcase completed room transformations, panel finishes, and interactive before/after comparisons.
          </p>
        </div>

        <button
          onClick={openAdd}
          className="px-4 py-2.5 bg-[#C9A24B] hover:bg-[#DFC27E] text-[#121212] text-xs font-bold uppercase tracking-wider flex items-center gap-2 cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Upload Project</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {gallery.map((item) => (
          <div
            key={item.id}
            className="bg-[#181818] border border-neutral-800 overflow-hidden flex flex-col justify-between group hover:border-[#C9A24B]/50 transition-colors"
          >
            <div>
              <div className="relative aspect-[16/10] bg-neutral-900 overflow-hidden">
                <img
                  src={item.image}
                  alt={item.title_en}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                {item.beforeImage && (
                  <div className="absolute top-2 left-2 bg-[#C9A24B] text-[#121212] text-[10px] font-bold px-2 py-0.5 uppercase flex items-center gap-1">
                    <SplitSquareHorizontal className="w-3 h-3" />
                    <span>Has Before Photo</span>
                  </div>
                )}
                <div className="absolute bottom-2 right-2 bg-black/80 text-white text-[10px] px-2 py-0.5 font-mono">
                  {item.category}
                </div>
              </div>

              <div className="p-5">
                <div className="flex items-center gap-1 text-[11px] text-[#DFC27E] mb-1">
                  <MapPin className="w-3 h-3" />
                  <span>{item.location}</span>
                </div>
                <h3 className="font-serif font-bold text-base text-white">{item.title_en}</h3>
                <p className="text-xs text-neutral-400 font-hindi mb-2">{item.title_hi}</p>
                <p className="text-xs text-neutral-300 font-mono bg-neutral-900 p-2 border border-neutral-800">
                  {item.panelType}
                </p>
              </div>
            </div>

            <div className="p-5 pt-0 border-t border-neutral-800/80 mt-2 flex items-center justify-end gap-3 pt-3">
              <button
                onClick={() => openEdit(item)}
                className="text-xs text-neutral-400 hover:text-white flex items-center gap-1"
              >
                <Edit3 className="w-3.5 h-3.5" />
                <span>Edit</span>
              </button>
              <button
                onClick={() => handleDelete(item.id, item.title_en)}
                className="text-xs text-red-400 hover:text-red-300 flex items-center gap-1 ml-2"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Delete</span>
              </button>
            </div>
          </div>
        ))}
      </div>

      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
          <div className="bg-[#181818] border border-[#C9A24B]/40 max-w-xl w-full max-h-[90vh] overflow-y-auto p-6 space-y-4 text-neutral-200">
            <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
              <h3 className="text-base font-serif font-bold text-white">
                {editingItem ? 'Edit Project Gallery Item' : 'Add New Portfolio Project'}
              </h3>
              <button onClick={() => setModalOpen(false)} className="text-neutral-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-neutral-300 mb-1">Title (English) *</label>
                <input
                  type="text"
                  required
                  value={form.title_en}
                  onChange={(e) => setForm({ ...form, title_en: e.target.value })}
                  className="w-full bg-[#121212] border border-neutral-700 px-3 py-2 text-sm text-white focus:outline-none focus:border-[#C9A24B]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-neutral-300 mb-1">Title (Hindi)</label>
                <input
                  type="text"
                  value={form.title_hi}
                  onChange={(e) => setForm({ ...form, title_hi: e.target.value })}
                  className="w-full bg-[#121212] border border-neutral-700 px-3 py-2 text-sm text-white focus:outline-none focus:border-[#C9A24B]"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-neutral-300 mb-1">Category *</label>
                  <select
                    value={form.category}
                    onChange={(e) => setForm({ ...form, category: e.target.value })}
                    className="w-full bg-[#121212] border border-neutral-700 px-3 py-2 text-sm text-white focus:outline-none focus:border-[#C9A24B]"
                  >
                    <option value="tv_unit">TV Unit Wall</option>
                    <option value="living_room">Living Room</option>
                    <option value="bedroom">Bedroom</option>
                    <option value="office">Office / Commercial</option>
                    <option value="shop">Shops & Showrooms</option>
                    <option value="ceiling">Ceiling & Lights</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-neutral-300 mb-1">Location *</label>
                  <input
                    type="text"
                    required
                    value={form.location}
                    onChange={(e) => setForm({ ...form, location: e.target.value })}
                    placeholder="e.g. Mansarovar, Jaipur"
                    className="w-full bg-[#121212] border border-neutral-700 px-3 py-2 text-sm text-white focus:outline-none focus:border-[#C9A24B]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-neutral-300 mb-1">Panel Type & Lighting Used</label>
                <input
                  type="text"
                  value={form.panelType}
                  onChange={(e) => setForm({ ...form, panelType: e.target.value })}
                  placeholder="e.g. Charcoal Fluted Louvers + Statuario UV Marble + 3000K Cove LED"
                  className="w-full bg-[#121212] border border-neutral-700 px-3 py-2 text-sm text-white focus:outline-none focus:border-[#C9A24B]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-neutral-300 mb-1">Finished Project Image URL *</label>
                <input
                  type="text"
                  required
                  value={form.image}
                  onChange={(e) => setForm({ ...form, image: e.target.value })}
                  placeholder="https://images.unsplash.com/..."
                  className="w-full bg-[#121212] border border-neutral-700 px-3 py-2 text-sm text-white focus:outline-none focus:border-[#C9A24B]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-neutral-300 mb-1">
                  Optional "Before" Image URL (Enables Before/After comparison slider)
                </label>
                <input
                  type="text"
                  value={form.beforeImage}
                  onChange={(e) => setForm({ ...form, beforeImage: e.target.value })}
                  placeholder="https://images.unsplash.com/... (Bare wall photo)"
                  className="w-full bg-[#121212] border border-neutral-700 px-3 py-2 text-sm text-white focus:outline-none focus:border-[#C9A24B]"
                />
              </div>

              <div className="pt-3 border-t border-neutral-800 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2 text-xs text-neutral-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-[#C9A24B] hover:bg-[#DFC27E] text-[#121212] font-bold text-xs uppercase tracking-wider"
                >
                  Save Project
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
