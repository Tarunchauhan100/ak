import React, { useState } from 'react';
import { useData } from '../../context/DataContext';
import { Category } from '../../types';
import { Plus, Edit3, Trash2, X, Layers } from 'lucide-react';

export const AdminCategories: React.FC = () => {
  const { categories, addCategory, updateCategory, deleteCategory } = useData();

  const [modalOpen, setModalOpen] = useState(false);
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);

  const [form, setForm] = useState({
    name_en: '',
    name_hi: '',
    slug: '',
    description_en: '',
    description_hi: '',
    displayOrder: 1,
  });

  const openAdd = () => {
    setEditingCategory(null);
    setForm({
      name_en: '',
      name_hi: '',
      slug: '',
      description_en: '',
      description_hi: '',
      displayOrder: categories.length + 1,
    });
    setModalOpen(true);
  };

  const openEdit = (c: Category) => {
    setEditingCategory(c);
    setForm({
      name_en: c.name_en,
      name_hi: c.name_hi,
      slug: c.slug,
      description_en: c.description_en,
      description_hi: c.description_hi,
      displayOrder: c.displayOrder || 1,
    });
    setModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editingCategory) {
        await updateCategory(editingCategory.id, form);
      } else {
        await addCategory(form);
      }
      setModalOpen(false);
    } catch (err) {
      console.error(err);
      alert('Error saving category.');
    }
  };

  const handleDelete = async (id: string, name: string) => {
    if (confirm(`Delete category "${name}"? Existing products may need re-assigning.`)) {
      try {
        await deleteCategory(id);
      } catch (err) {
        console.error(err);
      }
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 bg-[#181818] border border-neutral-800 p-5">
        <div>
          <h2 className="text-xl font-serif font-bold text-white tracking-wide">
            Product & Service Categories
          </h2>
          <p className="text-xs text-neutral-400">
            Organize offerings displayed on the website and catalog filters.
          </p>
        </div>

        <button
          onClick={openAdd}
          className="px-4 py-2.5 bg-[#C9A24B] hover:bg-[#DFC27E] text-[#121212] text-xs font-bold uppercase tracking-wider flex items-center gap-2 cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Add Category</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {categories.map((c) => (
          <div
            key={c.id}
            className="bg-[#181818] border border-neutral-800 p-6 flex flex-col justify-between hover:border-[#C9A24B]/40 transition-colors"
          >
            <div>
              <div className="flex items-center justify-between mb-3">
                <span className="text-[10px] font-mono text-[#DFC27E] uppercase bg-black/60 px-2 py-0.5">
                  Order: {c.displayOrder}
                </span>
                <span className="text-xs text-neutral-500 font-mono">slug: {c.slug}</span>
              </div>

              <h3 className="text-lg font-serif font-bold text-white mb-1">{c.name_en}</h3>
              <p className="text-xs text-[#DFC27E] font-hindi mb-3">{c.name_hi}</p>

              <p className="text-xs text-neutral-400 leading-relaxed font-light mb-4">
                {c.description_en}
              </p>
            </div>

            <div className="pt-4 border-t border-neutral-800 flex items-center justify-end gap-3">
              <button
                onClick={() => openEdit(c)}
                className="text-xs text-neutral-400 hover:text-white flex items-center gap-1"
              >
                <Edit3 className="w-3.5 h-3.5" />
                <span>Edit</span>
              </button>
              <button
                onClick={() => handleDelete(c.id, c.name_en)}
                className="text-xs text-red-400 hover:text-red-300 flex items-center gap-1 ml-2"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Delete</span>
              </button>
            </div>
          </div>
        ))}
      </div>

      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
          <div className="bg-[#181818] border border-[#C9A24B]/40 max-w-lg w-full p-6 space-y-4 text-neutral-200">
            <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
              <h3 className="text-base font-serif font-bold text-white">
                {editingCategory ? 'Edit Category' : 'Add New Category'}
              </h3>
              <button onClick={() => setModalOpen(false)} className="text-neutral-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-neutral-300 mb-1">Name (English) *</label>
                <input
                  type="text"
                  required
                  value={form.name_en}
                  onChange={(e) => setForm({ ...form, name_en: e.target.value })}
                  className="w-full bg-[#121212] border border-neutral-700 px-3 py-2 text-sm text-white focus:outline-none focus:border-[#C9A24B]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-neutral-300 mb-1">Name (Hindi)</label>
                <input
                  type="text"
                  value={form.name_hi}
                  onChange={(e) => setForm({ ...form, name_hi: e.target.value })}
                  className="w-full bg-[#121212] border border-neutral-700 px-3 py-2 text-sm text-white focus:outline-none focus:border-[#C9A24B]"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-neutral-300 mb-1">Slug (URL Key) *</label>
                  <input
                    type="text"
                    required
                    value={form.slug}
                    onChange={(e) => setForm({ ...form, slug: e.target.value.toLowerCase().replace(/\s+/g, '-') })}
                    className="w-full bg-[#121212] border border-neutral-700 px-3 py-2 text-sm text-white focus:outline-none focus:border-[#C9A24B]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-neutral-300 mb-1">Display Order</label>
                  <input
                    type="number"
                    value={form.displayOrder}
                    onChange={(e) => setForm({ ...form, displayOrder: Number(e.target.value) })}
                    className="w-full bg-[#121212] border border-neutral-700 px-3 py-2 text-sm text-white focus:outline-none focus:border-[#C9A24B]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-neutral-300 mb-1">Description (English)</label>
                <textarea
                  rows={2}
                  value={form.description_en}
                  onChange={(e) => setForm({ ...form, description_en: e.target.value })}
                  className="w-full bg-[#121212] border border-neutral-700 px-3 py-2 text-sm text-white focus:outline-none focus:border-[#C9A24B]"
                />
              </div>

              <div className="pt-3 border-t border-neutral-800 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2 text-xs text-neutral-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-[#C9A24B] hover:bg-[#DFC27E] text-[#121212] font-bold text-xs uppercase tracking-wider"
                >
                  Save Category
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
