import React, { useState } from 'react';
import { useData } from '../../context/DataContext';
import { SiteContent } from '../../types';
import { Save, Sparkles, Check, Plus, Trash2 } from 'lucide-react';

export const AdminContent: React.FC = () => {
  const { siteContent, updateSiteContent } = useData();

  const [form, setForm] = useState<SiteContent>({ ...siteContent });
  const [heroImagesString, setHeroImagesString] = useState(siteContent.heroImages?.join(', ') || '');
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [saving, setSaving] = useState(false);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setSavedSuccess(false);

    const imagesArray = heroImagesString
      .split(',')
      .map(s => s.trim())
      .filter(s => s.length > 0);

    const updated: Partial<SiteContent> = {
      ...form,
      heroImages: imagesArray.length ? imagesArray : form.heroImages,
      expYears: Number(form.expYears),
      projectsCompleted: Number(form.projectsCompleted),
      guaranteeYears: Number(form.guaranteeYears),
    };

    try {
      await updateSiteContent(updated);
      setSavedSuccess(true);
      setTimeout(() => setSavedSuccess(false), 3000);
    } catch (err) {
      console.error(err);
      alert('Error updating content.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-8">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 bg-[#181818] border border-neutral-800 p-5">
        <div>
          <h2 className="text-xl font-serif font-bold text-white tracking-wide">
            Website Content & Copy Editor
          </h2>
          <p className="text-xs text-neutral-400">
            Edit hero headlines, experience counters, story copy, and FAQs in English & Hindi.
          </p>
        </div>

        {savedSuccess && (
          <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-emerald-950/60 border border-emerald-600 text-emerald-300 text-xs font-semibold">
            <Check className="w-4 h-4" />
            <span>Changes published live!</span>
          </div>
        )}
      </div>

      <form onSubmit={handleSave} className="space-y-8">
        {/* Section 1: Hero Headlines & Images */}
        <div className="bg-[#181818] border border-neutral-800 p-6 space-y-4">
          <h3 className="text-base font-serif font-bold text-white border-b border-neutral-800 pb-2 flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-[#C9A24B]" />
            <span>Hero Screen Headlines & Slideshow</span>
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-neutral-300 mb-1">
                Hero Big Headline (English)
              </label>
              <input
                type="text"
                value={form.heroHeadline_en}
                onChange={(e) => setForm({ ...form, heroHeadline_en: e.target.value })}
                className="w-full bg-[#121212] border border-neutral-700 px-3 py-2 text-sm text-white focus:outline-none focus:border-[#C9A24B]"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-neutral-300 mb-1">
                Hero Big Headline (Hindi)
              </label>
              <input
                type="text"
                value={form.heroHeadline_hi}
                onChange={(e) => setForm({ ...form, heroHeadline_hi: e.target.value })}
                className="w-full bg-[#121212] border border-neutral-700 px-3 py-2 text-sm text-white focus:outline-none focus:border-[#C9A24B]"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-neutral-300 mb-1">
                Sub-Headline (English)
              </label>
              <input
                type="text"
                value={form.heroSubheadline_en}
                onChange={(e) => setForm({ ...form, heroSubheadline_en: e.target.value })}
                className="w-full bg-[#121212] border border-neutral-700 px-3 py-2 text-sm text-white focus:outline-none focus:border-[#C9A24B]"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-neutral-300 mb-1">
                Sub-Headline (Hindi)
              </label>
              <input
                type="text"
                value={form.heroSubheadline_hi}
                onChange={(e) => setForm({ ...form, heroSubheadline_hi: e.target.value })}
                className="w-full bg-[#121212] border border-neutral-700 px-3 py-2 text-sm text-white focus:outline-none focus:border-[#C9A24B]"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-neutral-300 mb-1">
              Hero Background Slideshow Images (comma separated URLs)
            </label>
            <textarea
              rows={2}
              value={heroImagesString}
              onChange={(e) => setHeroImagesString(e.target.value)}
              className="w-full bg-[#121212] border border-neutral-700 px-3 py-2 text-xs text-white focus:outline-none focus:border-[#C9A24B]"
            />
          </div>
        </div>

        {/* Section 2: Trust Metric Badges */}
        <div className="bg-[#181818] border border-neutral-800 p-6 space-y-4">
          <h3 className="text-base font-serif font-bold text-white border-b border-neutral-800 pb-2">
            Trust Metric Badges (Displayed under hero & in about section)
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-neutral-300 mb-1">
                Years of Experience
              </label>
              <input
                type="number"
                value={form.expYears}
                onChange={(e) => setForm({ ...form, expYears: Number(e.target.value) })}
                className="w-full bg-[#121212] border border-neutral-700 px-3 py-2 text-sm text-white focus:outline-none focus:border-[#C9A24B]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-neutral-300 mb-1">
                Projects Completed
              </label>
              <input
                type="number"
                value={form.projectsCompleted}
                onChange={(e) => setForm({ ...form, projectsCompleted: Number(e.target.value) })}
                className="w-full bg-[#121212] border border-neutral-700 px-3 py-2 text-sm text-white focus:outline-none focus:border-[#C9A24B]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-neutral-300 mb-1">
                Quality Guarantee (Years)
              </label>
              <input
                type="number"
                value={form.guaranteeYears}
                onChange={(e) => setForm({ ...form, guaranteeYears: Number(e.target.value) })}
                className="w-full bg-[#121212] border border-neutral-700 px-3 py-2 text-sm text-white focus:outline-none focus:border-[#C9A24B]"
              />
            </div>
          </div>
        </div>

        {/* Section 3: About Story */}
        <div className="bg-[#181818] border border-neutral-800 p-6 space-y-4">
          <h3 className="text-base font-serif font-bold text-white border-b border-neutral-800 pb-2">
            About Company & Founders
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-neutral-300 mb-1">
                Founders / Owner Name
              </label>
              <input
                type="text"
                value={form.aboutOwnerName}
                onChange={(e) => setForm({ ...form, aboutOwnerName: e.target.value })}
                className="w-full bg-[#121212] border border-neutral-700 px-3 py-2 text-sm text-white focus:outline-none focus:border-[#C9A24B]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-neutral-300 mb-1">
                Role / Title
              </label>
              <input
                type="text"
                value={form.aboutOwnerRole}
                onChange={(e) => setForm({ ...form, aboutOwnerRole: e.target.value })}
                className="w-full bg-[#121212] border border-neutral-700 px-3 py-2 text-sm text-white focus:outline-none focus:border-[#C9A24B]"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-neutral-300 mb-1">
              About Story (English)
            </label>
            <textarea
              rows={4}
              value={form.aboutStory_en}
              onChange={(e) => setForm({ ...form, aboutStory_en: e.target.value })}
              className="w-full bg-[#121212] border border-neutral-700 px-3 py-2 text-sm text-white focus:outline-none focus:border-[#C9A24B]"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-neutral-300 mb-1">
              About Story (Hindi)
            </label>
            <textarea
              rows={4}
              value={form.aboutStory_hi}
              onChange={(e) => setForm({ ...form, aboutStory_hi: e.target.value })}
              className="w-full bg-[#121212] border border-neutral-700 px-3 py-2 text-sm text-white focus:outline-none focus:border-[#C9A24B]"
            />
          </div>
        </div>

        {/* Save button sticky */}
        <div className="flex items-center justify-end gap-3 pt-4 border-t border-neutral-800">
          <button
            type="submit"
            disabled={saving}
            className="px-8 py-3.5 bg-[#C9A24B] hover:bg-[#DFC27E] text-[#121212] font-bold text-xs uppercase tracking-wider flex items-center gap-2 shadow-xl cursor-pointer disabled:opacity-50"
          >
            <Save className="w-4 h-4" />
            <span>{saving ? 'Saving...' : 'Publish Content Updates Live'}</span>
          </button>
        </div>
      </form>
    </div>
  );
};
