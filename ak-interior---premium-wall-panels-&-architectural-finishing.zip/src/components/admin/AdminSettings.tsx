import React, { useState } from 'react';
import { useData } from '../../context/DataContext';
import { Settings } from '../../types';
import { Save, Check, RotateCcw, AlertTriangle, Sparkles } from 'lucide-react';

export const AdminSettings: React.FC = () => {
  const { settings, updateSettings, seedDatabase, seedingInProgress } = useData();

  const [form, setForm] = useState<Settings>({ ...settings });
  const [saved, setSaved] = useState(false);
  const [saving, setSaving] = useState(false);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setSaved(false);

    try {
      await updateSettings(form);
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    } catch (err) {
      console.error(err);
      alert('Error updating settings.');
    } finally {
      setSaving(false);
    }
  };

  const handleReSeed = async () => {
    if (confirm('This will populate the database with default luxury interior panels, projects, testimonials, and copy. Continue?')) {
      await seedDatabase();
      alert('Showroom database seeded successfully!');
    }
  };

  return (
    <div className="space-y-8">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 bg-[#181818] border border-neutral-800 p-5">
        <div>
          <h2 className="text-xl font-serif font-bold text-white tracking-wide">
            Business Profile & Contact Settings
          </h2>
          <p className="text-xs text-neutral-400">
            Configure phone numbers, WhatsApp link, showroom address, working hours, and SEO metadata.
          </p>
        </div>

        {saved && (
          <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-emerald-950/60 border border-emerald-600 text-emerald-300 text-xs font-semibold">
            <Check className="w-4 h-4" />
            <span>Settings saved successfully!</span>
          </div>
        )}
      </div>

      <form onSubmit={handleSave} className="space-y-6">
        {/* General Business Info */}
        <div className="bg-[#181818] border border-neutral-800 p-6 space-y-4">
          <h3 className="text-base font-serif font-bold text-white border-b border-neutral-800 pb-2">
            General Business Identity
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-neutral-300 mb-1">Business Name *</label>
              <input
                type="text"
                required
                value={form.businessName}
                onChange={(e) => setForm({ ...form, businessName: e.target.value })}
                className="w-full bg-[#121212] border border-neutral-700 px-3 py-2 text-sm text-white focus:outline-none focus:border-[#C9A24B]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-neutral-300 mb-1">Tagline (English)</label>
              <input
                type="text"
                value={form.tagline_en}
                onChange={(e) => setForm({ ...form, tagline_en: e.target.value })}
                className="w-full bg-[#121212] border border-neutral-700 px-3 py-2 text-sm text-white focus:outline-none focus:border-[#C9A24B]"
              />
            </div>
          </div>
        </div>

        {/* Contact Numbers & WhatsApp */}
        <div className="bg-[#181818] border border-neutral-800 p-6 space-y-4">
          <h3 className="text-base font-serif font-bold text-white border-b border-neutral-800 pb-2">
            Customer Contact & WhatsApp Hotline
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-neutral-300 mb-1">
                Display Phone Number *
              </label>
              <input
                type="text"
                required
                value={form.phone}
                onChange={(e) => setForm({ ...form, phone: e.target.value })}
                placeholder="+91 98765 43210"
                className="w-full bg-[#121212] border border-neutral-700 px-3 py-2 text-sm text-white focus:outline-none focus:border-[#C9A24B]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-neutral-300 mb-1">
                WhatsApp Number (with country code, no +) *
              </label>
              <input
                type="text"
                required
                value={form.whatsappNumber}
                onChange={(e) => setForm({ ...form, whatsappNumber: e.target.value })}
                placeholder="919876543210"
                className="w-full bg-[#121212] border border-neutral-700 px-3 py-2 text-sm text-white focus:outline-none focus:border-[#C9A24B]"
              />
              <span className="text-[10px] text-neutral-500 mt-0.5 block">Used for direct 1-click WhatsApp quotes.</span>
            </div>

            <div>
              <label className="block text-xs font-semibold text-neutral-300 mb-1">
                Official Email Address
              </label>
              <input
                type="email"
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                placeholder="contact@akinterior.in"
                className="w-full bg-[#121212] border border-neutral-700 px-3 py-2 text-sm text-white focus:outline-none focus:border-[#C9A24B]"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-neutral-300 mb-1">
                Showroom Address *
              </label>
              <textarea
                rows={2}
                value={form.address}
                onChange={(e) => setForm({ ...form, address: e.target.value })}
                className="w-full bg-[#121212] border border-neutral-700 px-3 py-2 text-sm text-white focus:outline-none focus:border-[#C9A24B]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-neutral-300 mb-1">
                Showroom Visiting Hours
              </label>
              <textarea
                rows={2}
                value={form.workingHours}
                onChange={(e) => setForm({ ...form, workingHours: e.target.value })}
                className="w-full bg-[#121212] border border-neutral-700 px-3 py-2 text-sm text-white focus:outline-none focus:border-[#C9A24B]"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-neutral-300 mb-1">
              Google Maps Embed URL
            </label>
            <input
              type="text"
              value={form.googleMapsEmbedUrl}
              onChange={(e) => setForm({ ...form, googleMapsEmbedUrl: e.target.value })}
              className="w-full bg-[#121212] border border-neutral-700 px-3 py-2 text-xs text-white focus:outline-none focus:border-[#C9A24B]"
            />
          </div>
        </div>

        {/* Social Media Links */}
        <div className="bg-[#181818] border border-neutral-800 p-6 space-y-4">
          <h3 className="text-base font-serif font-bold text-white border-b border-neutral-800 pb-2">
            Social Media Handles
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-neutral-300 mb-1">Instagram URL</label>
              <input
                type="text"
                value={form.instagramUrl}
                onChange={(e) => setForm({ ...form, instagramUrl: e.target.value })}
                className="w-full bg-[#121212] border border-neutral-700 px-3 py-2 text-xs text-white focus:outline-none focus:border-[#C9A24B]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-neutral-300 mb-1">Facebook URL</label>
              <input
                type="text"
                value={form.facebookUrl}
                onChange={(e) => setForm({ ...form, facebookUrl: e.target.value })}
                className="w-full bg-[#121212] border border-neutral-700 px-3 py-2 text-xs text-white focus:outline-none focus:border-[#C9A24B]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-neutral-300 mb-1">YouTube URL</label>
              <input
                type="text"
                value={form.youtubeUrl}
                onChange={(e) => setForm({ ...form, youtubeUrl: e.target.value })}
                className="w-full bg-[#121212] border border-neutral-700 px-3 py-2 text-xs text-white focus:outline-none focus:border-[#C9A24B]"
              />
            </div>
          </div>
        </div>

        {/* Action Button */}
        <div className="flex items-center justify-between pt-4 border-t border-neutral-800">
          <button
            type="button"
            onClick={handleReSeed}
            disabled={seedingInProgress}
            className="px-4 py-2.5 bg-neutral-900 border border-neutral-700 hover:border-amber-500 text-neutral-300 hover:text-amber-300 text-xs font-semibold flex items-center gap-2 transition-colors cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>{seedingInProgress ? 'Seeding...' : 'Reset Default Showroom Catalog'}</span>
          </button>

          <button
            type="submit"
            disabled={saving}
            className="px-8 py-3 bg-[#C9A24B] hover:bg-[#DFC27E] text-[#121212] font-bold text-xs uppercase tracking-wider flex items-center gap-2 shadow-xl cursor-pointer disabled:opacity-50"
          >
            <Save className="w-4 h-4" />
            <span>{saving ? 'Saving...' : 'Save All Settings'}</span>
          </button>
        </div>
      </form>
    </div>
  );
};
