import React, { useState } from 'react';
import { useData } from '../../context/DataContext';
import { Enquiry } from '../../types';
import { 
  Search, 
  Download, 
  MessageCircle, 
  PhoneCall, 
  Trash2, 
  Filter, 
  CheckCircle, 
  Clock, 
  Archive,
  User,
  MapPin,
  Calendar
} from 'lucide-react';

export const AdminEnquiries: React.FC = () => {
  const { enquiries, updateEnquiryStatus, deleteEnquiry } = useData();

  const [statusFilter, setStatusFilter] = useState<'all' | 'new' | 'contacted' | 'closed'>('all');
  const [search, setSearch] = useState('');

  const filteredEnquiries = enquiries.filter((e) => {
    const matchStatus = statusFilter === 'all' || e.status === statusFilter;
    const matchSearch =
      !search ||
      e.name.toLowerCase().includes(search.toLowerCase()) ||
      e.phone.toLowerCase().includes(search.toLowerCase()) ||
      e.city.toLowerCase().includes(search.toLowerCase()) ||
      e.service.toLowerCase().includes(search.toLowerCase());
    return matchStatus && matchSearch;
  });

  const handleStatusChange = async (id: string, status: Enquiry['status']) => {
    try {
      await updateEnquiryStatus(id, status);
    } catch (err) {
      console.error(err);
    }
  };

  const handleDelete = async (id: string, name: string) => {
    if (confirm(`Delete enquiry from "${name}"?`)) {
      try {
        await deleteEnquiry(id);
      } catch (err) {
        console.error(err);
      }
    }
  };

  // Export to CSV
  const handleExportCSV = () => {
    if (enquiries.length === 0) {
      alert('No enquiries to export.');
      return;
    }

    const headers = ['ID', 'Date', 'Customer Name', 'Phone', 'City', 'Service', 'Area SqFt', 'Status', 'Message'];
    const rows = enquiries.map(e => [
      `"${e.id}"`,
      `"${e.createdAt || ''}"`,
      `"${e.name.replace(/"/g, '""')}"`,
      `"${e.phone.replace(/"/g, '""')}"`,
      `"${e.city?.replace(/"/g, '""') || ''}"`,
      `"${e.service?.replace(/"/g, '""') || ''}"`,
      `"${e.approxAreaSqFt || ''}"`,
      `"${e.status}"`,
      `"${(e.message || '').replace(/"/g, '""')}"`
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `ak_interior_leads_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const getWhatsAppLeadUrl = (enq: Enquiry) => {
    const text = encodeURIComponent(
      `Hello ${enq.name}, this is AK Interior. We received your quote request for ${enq.service} (${enq.approxAreaSqFt} sq ft). We would be happy to visit and show you our physical panel catalogs. What time suits you?`
    );
    const cleanPhone = enq.phone.replace(/[^0-9]/g, '');
    const phoneWithCountry = cleanPhone.length === 10 ? `91${cleanPhone}` : cleanPhone;
    return `https://wa.me/${phoneWithCountry}?text=${text}`;
  };

  return (
    <div className="space-y-6">
      {/* Header bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 bg-[#181818] border border-neutral-800 p-5">
        <div>
          <h2 className="text-xl font-serif font-bold text-white tracking-wide">
            Quote Leads & Enquiries Inbox
          </h2>
          <p className="text-xs text-neutral-400">
            Real-time submissions from customer quote requests, cost estimates, and visit bookings.
          </p>
        </div>

        <button
          onClick={handleExportCSV}
          className="px-4 py-2.5 bg-neutral-900 border border-neutral-700 hover:border-[#C9A24B] text-neutral-200 text-xs font-semibold uppercase tracking-wider flex items-center gap-2 cursor-pointer transition-colors"
        >
          <Download className="w-4 h-4 text-[#C9A24B]" />
          <span>Export to CSV</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4">
        {/* Status tabs */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
          <button
            onClick={() => setStatusFilter('all')}
            className={`px-3 py-1.5 text-xs font-semibold uppercase ${
              statusFilter === 'all'
                ? 'bg-[#C9A24B] text-[#121212]'
                : 'bg-[#181818] text-neutral-300 border border-neutral-800'
            }`}
          >
            All Leads ({enquiries.length})
          </button>
          <button
            onClick={() => setStatusFilter('new')}
            className={`px-3 py-1.5 text-xs font-semibold uppercase ${
              statusFilter === 'new'
                ? 'bg-amber-500 text-black'
                : 'bg-[#181818] text-neutral-300 border border-neutral-800'
            }`}
          >
            New ({enquiries.filter(e => e.status === 'new').length})
          </button>
          <button
            onClick={() => setStatusFilter('contacted')}
            className={`px-3 py-1.5 text-xs font-semibold uppercase ${
              statusFilter === 'contacted'
                ? 'bg-blue-500 text-white'
                : 'bg-[#181818] text-neutral-300 border border-neutral-800'
            }`}
          >
            Contacted ({enquiries.filter(e => e.status === 'contacted').length})
          </button>
          <button
            onClick={() => setStatusFilter('closed')}
            className={`px-3 py-1.5 text-xs font-semibold uppercase ${
              statusFilter === 'closed'
                ? 'bg-emerald-500 text-white'
                : 'bg-[#181818] text-neutral-300 border border-neutral-800'
            }`}
          >
            Closed ({enquiries.filter(e => e.status === 'closed').length})
          </button>
        </div>

        {/* Search */}
        <div className="relative max-w-xs w-full">
          <Search className="w-4 h-4 text-neutral-500 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search leads by name/phone/city..."
            className="w-full bg-[#181818] border border-neutral-700 pl-9 pr-3 py-1.5 text-xs text-white focus:outline-none focus:border-[#C9A24B]"
          />
        </div>
      </div>

      {/* Leads Table */}
      <div className="bg-[#181818] border border-neutral-800 overflow-x-auto shadow-xl">
        <table className="w-full text-left text-xs">
          <thead className="bg-[#1F1F1F] text-neutral-400 uppercase font-mono tracking-wider border-b border-neutral-800">
            <tr>
              <th className="py-3.5 px-4">Customer Details</th>
              <th className="py-3.5 px-4">Contact Phone</th>
              <th className="py-3.5 px-4">City / Area</th>
              <th className="py-3.5 px-4">Service & Approx Area</th>
              <th className="py-3.5 px-4">Message / Notes</th>
              <th className="py-3.5 px-4">Status</th>
              <th className="py-3.5 px-4 text-center">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-neutral-800">
            {filteredEnquiries.length === 0 ? (
              <tr>
                <td colSpan={7} className="py-12 text-center text-neutral-500">
                  No enquiries match this filter.
                </td>
              </tr>
            ) : (
              filteredEnquiries.map((enq) => (
                <tr key={enq.id} className="hover:bg-neutral-800/40 transition-colors">
                  <td className="py-4 px-4 font-semibold text-white">
                    <div>{enq.name}</div>
                    <span className="text-[10px] text-neutral-500 font-mono block">
                      {enq.createdAt ? new Date(enq.createdAt).toLocaleString() : 'N/A'}
                    </span>
                  </td>
                  <td className="py-4 px-4 font-mono">
                    <a href={`tel:${enq.phone.replace(/[^0-9+]/g, '')}`} className="text-neutral-200 hover:text-[#DFC27E]">
                      {enq.phone}
                    </a>
                  </td>
                  <td className="py-4 px-4 text-neutral-300">
                    {enq.city || 'Not specified'}
                  </td>
                  <td className="py-4 px-4 text-neutral-300">
                    <div className="font-semibold text-white">{enq.service}</div>
                    <span className="text-[11px] text-[#DFC27E] font-mono">{enq.approxAreaSqFt} sq ft</span>
                  </td>
                  <td className="py-4 px-4 text-neutral-400 max-w-xs truncate" title={enq.message}>
                    {enq.message || '—'}
                  </td>
                  <td className="py-4 px-4">
                    <select
                      value={enq.status}
                      onChange={(e) => handleStatusChange(enq.id, e.target.value as Enquiry['status'])}
                      className={`text-[11px] font-semibold uppercase px-2.5 py-1 rounded-none border focus:outline-none ${
                        enq.status === 'new'
                          ? 'bg-amber-950/60 border-amber-600 text-amber-300'
                          : enq.status === 'contacted'
                          ? 'bg-blue-950/60 border-blue-600 text-blue-300'
                          : 'bg-emerald-950/60 border-emerald-600 text-emerald-300'
                      }`}
                    >
                      <option value="new" className="bg-[#181818] text-white">New Lead</option>
                      <option value="contacted" className="bg-[#181818] text-white">Contacted</option>
                      <option value="closed" className="bg-[#181818] text-white">Closed / Won</option>
                    </select>
                  </td>
                  <td className="py-4 px-4 text-center">
                    <div className="flex items-center justify-center gap-2">
                      <a
                        href={getWhatsAppLeadUrl(enq)}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="p-2 bg-[#25D366]/20 hover:bg-[#25D366]/30 border border-[#25D366]/40 text-[#25D366]"
                        title="Chat on WhatsApp"
                      >
                        <MessageCircle className="w-3.5 h-3.5" />
                      </a>
                      <a
                        href={`tel:${enq.phone.replace(/[^0-9+]/g, '')}`}
                        className="p-2 bg-neutral-800 hover:bg-neutral-700 border border-neutral-700 text-neutral-200"
                        title="Call Customer"
                      >
                        <PhoneCall className="w-3.5 h-3.5" />
                      </a>
                      <button
                        onClick={() => handleDelete(enq.id, enq.name)}
                        className="p-2 text-neutral-500 hover:text-red-400 hover:bg-neutral-800 transition-colors"
                        title="Delete Enquiry"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
