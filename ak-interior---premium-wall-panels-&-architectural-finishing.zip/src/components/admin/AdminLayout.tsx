import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useData } from '../../context/DataContext';
import { 
  LayoutDashboard, 
  Package, 
  Layers, 
  Image as ImageIcon, 
  MessageSquare, 
  Inbox, 
  FileText, 
  Settings as SettingsIcon, 
  LogOut, 
  ExternalLink, 
  Menu, 
  X, 
  Sparkles,
  ShieldCheck,
  RotateCcw
} from 'lucide-react';

import { AdminDashboard } from './AdminDashboard';
import { AdminProducts } from './AdminProducts';
import { AdminCategories } from './AdminCategories';
import { AdminGallery } from './AdminGallery';
import { AdminTestimonials } from './AdminTestimonials';
import { AdminEnquiries } from './AdminEnquiries';
import { AdminContent } from './AdminContent';
import { AdminSettings } from './AdminSettings';

interface AdminLayoutProps {
  onBackToWebsite: () => void;
}

export const AdminLayout: React.FC<AdminLayoutProps> = ({ onBackToWebsite }) => {
  const { currentUser, logout, ownerEmail } = useAuth();
  const { enquiries, seedDatabase, seedingInProgress } = useData();

  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState<boolean>(false);

  const newEnquiriesCount = enquiries.filter(e => e.status === 'new').length;

  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'products', label: 'Panels & Pricing', icon: Package },
    { id: 'categories', label: 'Categories', icon: Layers },
    { id: 'gallery', label: 'Portfolio Gallery', icon: ImageIcon },
    { id: 'testimonials', label: 'Testimonials', icon: MessageSquare },
    { id: 'enquiries', label: 'Quote Enquiries', icon: Inbox, badge: newEnquiriesCount },
    { id: 'content', label: 'Website Content', icon: FileText },
    { id: 'settings', label: 'Business Settings', icon: SettingsIcon },
  ];

  const handleNavClick = (tabId: string) => {
    setActiveTab(tabId);
    setSidebarOpen(false);
  };

  return (
    <div className="min-h-screen bg-[#101010] text-[#F7F3EC] flex flex-col font-sans">
      {/* Top Navbar */}
      <header className="sticky top-0 z-40 bg-[#161616] border-b border-neutral-800 px-4 sm:px-6 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="lg:hidden p-2 text-neutral-400 hover:text-white"
            aria-label="Toggle admin sidebar"
          >
            {sidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>

          {/* Monogram */}
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 border border-[#C9A24B] flex items-center justify-center bg-black text-[#C9A24B] font-serif font-bold text-sm">
              AK
            </div>
            <div>
              <span className="font-serif font-bold text-white text-base tracking-wider uppercase">
                AK Interior
              </span>
              <span className="hidden sm:inline-block text-[10px] text-[#DFC27E] uppercase ml-2 tracking-widest font-mono">
                Admin Control Room
              </span>
            </div>
          </div>
        </div>

        {/* Top Header Actions */}
        <div className="flex items-center gap-3">
          <button
            onClick={onBackToWebsite}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs text-neutral-300 hover:text-white border border-neutral-700 bg-neutral-900 transition-colors"
          >
            <span>Live Website</span>
            <ExternalLink className="w-3.5 h-3.5 text-[#C9A24B]" />
          </button>

          <div className="hidden md:flex items-center gap-2 text-xs text-neutral-400 border-l border-neutral-800 pl-3">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span className="font-mono text-neutral-300">{currentUser?.email || ownerEmail}</span>
          </div>

          <button
            onClick={logout}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs text-red-400 hover:text-red-300 hover:bg-neutral-800 transition-colors border border-neutral-800"
            title="Log Out"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Logout</span>
          </button>
        </div>
      </header>

      {/* Main Container */}
      <div className="flex-1 flex overflow-hidden">
        {/* Sidebar */}
        <aside
          className={`fixed lg:static inset-y-0 left-0 z-30 w-64 bg-[#141414] border-r border-neutral-800 flex flex-col justify-between pt-16 lg:pt-0 transition-transform duration-200 ${
            sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
          }`}
        >
          <div className="p-4 space-y-1 overflow-y-auto">
            <div className="text-[10px] font-mono tracking-widest text-neutral-500 uppercase px-3 py-2">
              Management Suites
            </div>

            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;

              return (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id)}
                  className={`w-full flex items-center justify-between px-3 py-2.5 text-xs font-medium transition-colors cursor-pointer ${
                    isActive
                      ? 'bg-[#C9A24B] text-[#121212] font-bold shadow-md shadow-[#C9A24B]/10'
                      : 'text-neutral-400 hover:text-white hover:bg-neutral-900'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <Icon className="w-4 h-4" />
                    <span>{item.label}</span>
                  </div>

                  {item.badge !== undefined && item.badge > 0 && (
                    <span
                      className={`px-1.5 py-0.5 text-[10px] font-mono font-bold rounded-full ${
                        isActive ? 'bg-black text-[#C9A24B]' : 'bg-[#C9A24B] text-black'
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {/* Sidebar Footer */}
          <div className="p-4 border-t border-neutral-800 text-xs text-neutral-500 space-y-2">
            <button
              onClick={() => {
                if (confirm('Re-seed initial catalog items?')) seedDatabase();
              }}
              disabled={seedingInProgress}
              className="w-full flex items-center justify-center gap-1.5 py-2 bg-neutral-900 border border-neutral-800 hover:border-neutral-700 text-neutral-400 hover:text-[#C9A24B] text-[11px] transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>{seedingInProgress ? 'Seeding...' : 'Quick Re-Seed Catalog'}</span>
            </button>

            <div className="text-[10px] text-center text-neutral-600">
              AK Interior v2.5 • Full Production
            </div>
          </div>
        </aside>

        {/* Content Viewport */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-8 bg-[#101010]">
          <div className="max-w-7xl mx-auto">
            {activeTab === 'dashboard' && (
              <AdminDashboard
                onNavigate={setActiveTab}
                onOpenAddProduct={() => setActiveTab('products')}
                onOpenAddGallery={() => setActiveTab('gallery')}
              />
            )}
            {activeTab === 'products' && <AdminProducts />}
            {activeTab === 'categories' && <AdminCategories />}
            {activeTab === 'gallery' && <AdminGallery />}
            {activeTab === 'testimonials' && <AdminTestimonials />}
            {activeTab === 'enquiries' && <AdminEnquiries />}
            {activeTab === 'content' && <AdminContent />}
            {activeTab === 'settings' && <AdminSettings />}
          </div>
        </main>
      </div>
    </div>
  );
};
