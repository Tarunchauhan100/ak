import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { Lock, Mail, Key, Sparkles, X, ArrowRight, ShieldCheck, UserCheck } from 'lucide-react';

interface AdminLoginProps {
  onClose: () => void;
  onSuccess: () => void;
}

export const AdminLogin: React.FC<AdminLoginProps> = ({ onClose, onSuccess }) => {
  const { loginWithEmail, signUpWithEmail, loginWithGoogle, ownerEmail } = useAuth();
  
  const [email, setEmail] = useState(ownerEmail);
  const [password, setPassword] = useState('Admin@123456');
  const [isSignUp, setIsSignUp] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      if (isSignUp) {
        await signUpWithEmail(email, password);
      } else {
        await loginWithEmail(email, password);
      }
      onSuccess();
    } catch (err: any) {
      console.error(err);
      if (err.code === 'auth/user-not-found' || err.code === 'auth/invalid-credential') {
        // Offer to create account or handle credential
        setError('Invalid credentials or account does not exist yet. You can sign up with this email or use Google Login.');
      } else if (err.code === 'auth/email-already-in-use') {
        setError('This email already has an account. Please sign in instead.');
        setIsSignUp(false);
      } else {
        setError(err.message || 'Login failed. Please verify credentials.');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    setError('');
    setLoading(true);
    try {
      await loginWithGoogle();
      onSuccess();
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Google sign-in failed.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-[#181818] border border-[#C9A24B]/40 rounded-none w-full max-w-md overflow-hidden shadow-2xl relative text-neutral-200">
        {/* Header */}
        <div className="p-6 pb-4 border-b border-neutral-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 border border-[#C9A24B] flex items-center justify-center bg-[#121212] text-[#C9A24B]">
              <Lock className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-lg font-serif font-bold text-white tracking-wide">
                Owner Control Room
              </h3>
              <p className="text-[11px] text-[#DFC27E]">AK Interior Administrative Suite</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-neutral-400 hover:text-white p-1"
            aria-label="Close login modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5">
          <div className="bg-[#131313] border border-neutral-800 p-3 flex items-start gap-2.5 text-xs text-neutral-300">
            <ShieldCheck className="w-4 h-4 text-[#C9A24B] shrink-0 mt-0.5" />
            <p className="leading-relaxed">
              Authorized admin account: <strong className="text-white font-mono">{ownerEmail}</strong>. All catalog prices, projects, and quote enquiries are managed here.
            </p>
          </div>

          {error && (
            <div className="p-3 bg-red-950/70 border border-red-800 text-red-300 text-xs">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-neutral-300 mb-1">
                Admin Email
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-neutral-500 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-[#121212] border border-neutral-700 pl-9 pr-3 py-2 text-sm text-white focus:outline-none focus:border-[#C9A24B]"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-neutral-300 mb-1">
                Password
              </label>
              <div className="relative">
                <Key className="w-4 h-4 text-neutral-500 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full bg-[#121212] border border-neutral-700 pl-9 pr-3 py-2 text-sm text-white focus:outline-none focus:border-[#C9A24B]"
                />
              </div>
            </div>

            <div className="pt-2">
              <button
                type="submit"
                disabled={loading}
                className="w-full py-3 bg-[#C9A24B] hover:bg-[#DFC27E] text-[#121212] font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-colors cursor-pointer disabled:opacity-50"
              >
                {loading ? (
                  <span>Authenticating...</span>
                ) : (
                  <>
                    <Lock className="w-3.5 h-3.5" />
                    <span>{isSignUp ? 'Create Admin Account' : 'Sign In as Owner'}</span>
                  </>
                )}
              </button>
            </div>
          </form>

          {/* Social / Google Sign-in */}
          <div className="relative flex items-center justify-center pt-2">
            <div className="border-t border-neutral-800 w-full" />
            <span className="bg-[#181818] px-3 text-[10px] uppercase text-neutral-500 absolute font-mono">
              OR
            </span>
          </div>

          <button
            type="button"
            onClick={handleGoogleLogin}
            disabled={loading}
            className="w-full py-2.5 bg-neutral-900 border border-neutral-700 hover:border-[#C9A24B] text-neutral-200 text-xs font-semibold flex items-center justify-center gap-2 transition-colors cursor-pointer"
          >
            <svg className="w-4 h-4" viewBox="0 0 24 24">
              <path
                fill="#4285F4"
                d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
              />
              <path
                fill="#34A853"
                d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
              />
              <path
                fill="#FBBC05"
                d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
              />
              <path
                fill="#EA4335"
                d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
              />
            </svg>
            <span>Sign in with Google Account</span>
          </button>

          <div className="flex items-center justify-between text-xs text-neutral-400 pt-1">
            <button
              type="button"
              onClick={() => setIsSignUp(!isSignUp)}
              className="text-[#DFC27E] hover:underline"
            >
              {isSignUp ? 'Already registered? Sign in' : 'First time? Setup password'}
            </button>

            <button
              type="button"
              onClick={onClose}
              className="text-neutral-500 hover:text-white"
            >
              Back to Site
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
