import React from 'react';
import { useLanguage } from '../../context/LanguageContext';
import { useData } from '../../context/DataContext';
import { 
  Phone, 
  Mail, 
  MapPin, 
  Clock, 
  Instagram, 
  Facebook, 
  Youtube, 
  ShieldCheck, 
  ArrowUp,
  SlidersHorizontal
} from 'lucide-react';

interface FooterProps {
  onOpenAdmin: () => void;
  onOpenQuoteModal: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenAdmin, onOpenQuoteModal }) => {
  const { t } = useLanguage();
  const { settings, categories } = useData();

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-[#0B0B0B] text-neutral-400 border-t border-[#C9A24B]/20 relative">
      {/* Subtle gold accent top trim */}
      <div className="h-0.5 bg-gradient-to-r from-transparent via-[#C9A24B]/60 to-transparent" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-16 pb-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 lg:gap-12">
          {/* Col 1: Brand Info */}
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 border border-[#C9A24B] flex items-center justify-center bg-[#151515]">
                <span className="text-[#C9A24B] font-serif font-bold text-lg">AK</span>
              </div>
              <div>
                <h4 className="text-white font-serif tracking-[0.2em] font-bold text-lg uppercase">
                  {settings.businessName}
                </h4>
                <p className="text-[#C9A24B] text-[10px] tracking-widest uppercase">
                  Interior & Surface Specialist
                </p>
              </div>
            </div>

            <p className="text-sm text-neutral-400 leading-relaxed">
              {t(
                'Supplying and installing high-end charcoal louvers, waterproof PVC panels, UV marble slabs, and architectural LED lighting for residential & commercial spaces across India.',
                'उच्च गुणवत्ता वाले चारकोल लवर्स, वाटरप्रूफ पीवीसी पैनल्स, यूवी मार्बल शीट्स और डिजाइनर एलईडी लाइट्स के विश्वसनीय आपूर्तिकर्ता एवं इंस्टॉलेशन एक्सपर्ट।'
              )}
            </p>

            <div className="pt-2 flex items-center gap-3">
              <a
                href={settings.instagramUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-8 h-8 rounded-sm bg-neutral-900 border border-neutral-800 flex items-center justify-center text-neutral-400 hover:text-[#C9A24B] hover:border-[#C9A24B] transition-colors"
                aria-label="Instagram"
              >
                <Instagram className="w-4 h-4" />
              </a>
              <a
                href={settings.facebookUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-8 h-8 rounded-sm bg-neutral-900 border border-neutral-800 flex items-center justify-center text-neutral-400 hover:text-[#C9A24B] hover:border-[#C9A24B] transition-colors"
                aria-label="Facebook"
              >
                <Facebook className="w-4 h-4" />
              </a>
              <a
                href={settings.youtubeUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-8 h-8 rounded-sm bg-neutral-900 border border-neutral-800 flex items-center justify-center text-neutral-400 hover:text-[#C9A24B] hover:border-[#C9A24B] transition-colors"
                aria-label="YouTube"
              >
                <Youtube className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Col 2: Services / Products */}
          <div>
            <h5 className="text-white text-xs font-semibold tracking-widest uppercase mb-4 text-[#DFC27E]">
              {t('Our Solutions', 'हमारे उत्पाद')}
            </h5>
            <ul className="space-y-2 text-sm">
              {categories.slice(0, 6).map((cat) => (
                <li key={cat.id}>
                  <a
                    href="#products"
                    className="hover:text-white transition-colors hover:translate-x-1 inline-block duration-150"
                  >
                    {t(cat.name_en, cat.name_hi)}
                  </a>
                </li>
              ))}
              <li>
                <a
                  href="#calculator"
                  className="text-[#C9A24B] hover:text-[#DFC27E] font-medium transition-colors inline-block"
                >
                  {t('→ Wall Cost Estimator', '→ वॉल कॉस्ट कैलकुलेटर')}
                </a>
              </li>
            </ul>
          </div>

          {/* Col 3: Quick Navigation */}
          <div>
            <h5 className="text-white text-xs font-semibold tracking-widest uppercase mb-4 text-[#DFC27E]">
              {t('Quick Links', 'त्वरित लिंक्स')}
            </h5>
            <ul className="space-y-2 text-sm">
              <li>
                <a href="#home" className="hover:text-white transition-colors">
                  {t('Home & Showcase', 'होम व परिचय')}
                </a>
              </li>
              <li>
                <a href="#gallery" className="hover:text-white transition-colors">
                  {t('Project Portfolio', 'प्रोजेक्ट गैलरी')}
                </a>
              </li>
              <li>
                <a href="#why-us" className="hover:text-white transition-colors">
                  {t('Why Choose AK Interior', 'हमें क्यों चुनें')}
                </a>
              </li>
              <li>
                <a href="#about" className="hover:text-white transition-colors">
                  {t('Our Story & Team', 'हमारी कहानी')}
                </a>
              </li>
              <li>
                <a href="#testimonials" className="hover:text-white transition-colors">
                  {t('Client Testimonials', 'ग्राहकों के विचार')}
                </a>
              </li>
              <li>
                <a href="#faq" className="hover:text-white transition-colors">
                  {t('Frequently Asked Questions', 'पूछे जाने वाले प्रश्न')}
                </a>
              </li>
              <li>
                <button
                  type="button"
                  onClick={onOpenQuoteModal}
                  className="text-[#C9A24B] hover:underline"
                >
                  {t('Request Free Site Visit', 'फ्री ऑन-साइट नाप हेतु आवेदन')}
                </button>
              </li>
            </ul>
          </div>

          {/* Col 4: Contact Details & Hours */}
          <div className="space-y-3.5 text-sm">
            <h5 className="text-white text-xs font-semibold tracking-widest uppercase mb-4 text-[#DFC27E]">
              {t('Contact & Visit', 'संपर्क व पता')}
            </h5>
            <div className="flex items-start gap-3">
              <MapPin className="w-4 h-4 text-[#C9A24B] shrink-0 mt-1" />
              <span>{settings.address}</span>
            </div>
            <div className="flex items-center gap-3">
              <Phone className="w-4 h-4 text-[#C9A24B] shrink-0" />
              <a href={`tel:${settings.phone.replace(/[^0-9+]/g, '')}`} className="hover:text-white transition-colors">
                {settings.phone}
              </a>
            </div>
            <div className="flex items-center gap-3">
              <Mail className="w-4 h-4 text-[#C9A24B] shrink-0" />
              <a href={`mailto:${settings.email}`} className="hover:text-white transition-colors">
                {settings.email}
              </a>
            </div>
            <div className="flex items-start gap-3">
              <Clock className="w-4 h-4 text-[#C9A24B] shrink-0 mt-0.5" />
              <span>{settings.workingHours}</span>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-12 pt-8 border-t border-neutral-900 flex flex-col sm:flex-row items-center justify-between text-xs text-neutral-500 gap-4">
          <p>
            © {currentYear} {settings.businessName}. All rights reserved. Precision architectural panelling & lighting.
          </p>

          <div className="flex items-center gap-6">
            <button
              type="button"
              onClick={onOpenAdmin}
              className="flex items-center gap-1.5 text-neutral-500 hover:text-[#C9A24B] transition-colors"
            >
              <SlidersHorizontal className="w-3.5 h-3.5" />
              <span>Admin Management</span>
            </button>

            <button
              type="button"
              onClick={scrollToTop}
              className="flex items-center gap-1 hover:text-white transition-colors"
            >
              <span>Back to Top</span>
              <ArrowUp className="w-3.5 h-3.5 text-[#C9A24B]" />
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};
