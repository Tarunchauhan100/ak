import React from 'react';
import { useData } from '../../context/DataContext';
import { MessageCircle, Phone } from 'lucide-react';

export const WhatsAppButton: React.FC = () => {
  const { settings } = useData();

  const defaultMsg = encodeURIComponent('Hello AK Interior, I would like to inquire about architectural wall panels and lighting.');
  const whatsappUrl = `https://wa.me/${settings.whatsappNumber}?text=${defaultMsg}`;
  const phoneUrl = `tel:${settings.phone.replace(/[^0-9+]/g, '')}`;

  return (
    <>
      {/* Sleek Floating WhatsApp Button */}
      <div className="fixed bottom-6 right-6 z-40">
        <a
          href={whatsappUrl}
          target="_blank"
          rel="noopener noreferrer"
          aria-label="Direct WhatsApp Concierge"
          className="flex items-center justify-center w-12 h-12 bg-[#141413]/90 hover:bg-[#25D366] text-[#DFC27E] hover:text-[#0E0E0D] border border-[#C9A24B]/40 hover:border-[#25D366] shadow-2xl backdrop-blur-md transition-all duration-300 hover:scale-105 active:scale-95 group"
          title="Direct WhatsApp Concierge"
        >
          <MessageCircle className="w-5 h-5 transition-transform group-hover:rotate-6" />
        </a>
      </div>

      {/* Mobile Sticky Quick Contact Bottom Bar - Clean & Minimal */}
      <div className="sm:hidden fixed bottom-0 left-0 right-0 z-40 bg-[#0E0E0D]/95 backdrop-blur-md border-t border-neutral-800 px-4 py-2.5 flex items-center justify-between gap-3 shadow-2xl">
        <a
          href={phoneUrl}
          className="flex-1 flex items-center justify-center gap-2 py-2.5 bg-neutral-900 border border-neutral-800 text-neutral-300 text-xs font-medium active:bg-neutral-800"
        >
          <Phone className="w-3.5 h-3.5 text-[#C9A24B]" />
          <span>Call Studio</span>
        </a>
        <a
          href={whatsappUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="flex-1 flex items-center justify-center gap-2 py-2.5 bg-[#C9A24B] text-[#0E0E0D] text-xs font-semibold uppercase tracking-wider active:opacity-90"
        >
          <MessageCircle className="w-3.5 h-3.5" />
          <span>WhatsApp</span>
        </a>
      </div>
    </>
  );
};

