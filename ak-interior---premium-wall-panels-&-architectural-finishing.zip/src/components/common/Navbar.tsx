import React, { useState, useEffect } from 'react';
import { useLanguage } from '../../context/LanguageContext';
import { useData } from '../../context/DataContext';
import { useAuth } from '../../context/AuthContext';
import { 
  Menu, 
  X, 
  Phone, 
  MessageCircle, 
  SlidersHorizontal,
  ArrowRight
} from 'lucide-react';

interface NavbarProps {
  onOpenQuoteModal: (productName?: string) => void;
  onOpenAdmin: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenQuoteModal, onOpenAdmin }) => {
  const { language, setLanguage, t } = useLanguage();
  const { settings } = useData();
  const { isAdmin } = useAuth();
  
  const [isScrolled, setIsScrolled] = useState<boolean>(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState<boolean>(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 30);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { href: '#products', label_en: 'Collections & Pricing', label_hi: 'कलेक्शन व रेट' },
    { href: '#calculator', label_en: 'Cost Estimator', label_hi: 'लागत कैलकुलेटर' },
    { href: '#gallery', label_en: 'Portfolio', label_hi: 'प्रोजेक्ट्स' },
    { href: '#about', label_en: 'About Studio', label_hi: 'हमारे बारे में' },
    { href: '#contact', label_en: 'Contact', label_hi: 'संपर्क' },
  ];

  const handleLinkClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    setMobileMenuOpen(false);
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
          isScrolled
            ? 'bg-[#0E0E0D]/90 backdrop-blur-xl border-b border-[#C9A24B]/15 py-3.5 shadow-2xl shadow-black/40'
            : 'bg-gradient-to-b from-black/80 via-black/30 to-transparent py-6'
        }`}
      >
        <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12">
          <div className="flex items-center justify-between">
            {/* Minimalist Architectural Monogram Logo */}
            <a 
              href="#home" 
              onClick={(e) => handleLinkClick(e, '#home')}
              className="flex items-center gap-3.5 group focus:outline-none"
            >
              <div className="flex flex-col">
                <span className="text-[#DFC27E] font-serif text-2xl font-normal tracking-[0.22em] leading-none uppercase group-hover:text-white transition-colors">
                  AK
                </span>
                <span className="text-[#C9A24B] text-[9px] tracking-[0.38em] font-sans font-medium uppercase mt-1">
                  INTERIOR
                </span>
              </div>
              <div className="h-6 w-px bg-neutral-800 hidden sm:block" />
              <span className="text-[10px] tracking-[0.25em] text-neutral-400 font-light uppercase hidden sm:block">
                {language === 'hi' ? 'आर्किटेक्चरल पैनल्स' : 'ARCHITECTURAL SURFACES'}
              </span>
            </a>

            {/* Desktop Navigation Links - Refined, Spacious, Elegant */}
            <nav className="hidden lg:flex items-center gap-9 text-[11px] font-medium tracking-[0.2em] uppercase text-neutral-300">
              {navLinks.map((link) => (
                <a
                  key={link.href}
                  href={link.href}
                  onClick={(e) => handleLinkClick(e, link.href)}
                  className="hover:text-[#DFC27E] transition-colors relative py-1 text-neutral-300 hover:text-white transition-all duration-200"
                >
                  {t(link.label_en, link.label_hi)}
                </a>
              ))}
            </nav>

            {/* Right Controls: Minimalist Language Switch & Subtle Gold CTA */}
            <div className="flex items-center gap-4 sm:gap-6">
              {/* Clean Language Selector */}
              <div className="flex items-center text-[11px] tracking-wider font-medium text-neutral-400">
                <button
                  type="button"
                  onClick={() => setLanguage('en')}
                  className={`transition-colors cursor-pointer ${language === 'en' ? 'text-[#DFC27E] font-semibold' : 'hover:text-neutral-200'}`}
                >
                  EN
                </button>
                <span className="mx-1.5 text-neutral-600">/</span>
                <button
                  type="button"
                  onClick={() => setLanguage('hi')}
                  className={`transition-colors cursor-pointer ${language === 'hi' ? 'text-[#DFC27E] font-semibold font-hindi' : 'hover:text-neutral-200'}`}
                >
                  हिंदी
                </button>
              </div>

              {/* Discreet Owner Login Icon */}
              <button
                type="button"
                onClick={onOpenAdmin}
                className="text-neutral-500 hover:text-[#DFC27E] transition-colors p-1"
                title={isAdmin ? 'Admin Dashboard' : 'Owner Access'}
                aria-label="Admin Control"
              >
                <SlidersHorizontal className="w-3.5 h-3.5" />
              </button>

              {/* Single Refined Luxury CTA */}
              <button
                type="button"
                onClick={() => onOpenQuoteModal()}
                className="hidden sm:inline-flex items-center gap-2 px-5 py-2.5 border border-[#C9A24B]/60 hover:border-[#DFC27E] hover:bg-[#C9A24B] hover:text-[#0E0E0D] text-[#DFC27E] font-medium text-[11px] tracking-[0.2em] uppercase transition-all duration-300 cursor-pointer"
              >
                <span>{t('Request Quote', 'कोटेशन प्राप्त करें')}</span>
              </button>

              {/* Mobile Hamburger Button */}
              <button
                type="button"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="lg:hidden p-2 text-neutral-300 hover:text-white transition-colors"
                aria-label="Toggle mobile menu"
              >
                {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Slide-down Fullscreen Drawer */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-40 bg-[#0E0E0D]/98 backdrop-blur-2xl flex flex-col pt-24 px-8 pb-10 overflow-y-auto lg:hidden animate-in fade-in duration-300">
          <div className="flex flex-col space-y-6 my-auto text-left">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={(e) => handleLinkClick(e, link.href)}
                className="text-2xl font-serif tracking-wider text-neutral-200 hover:text-[#DFC27E] transition-colors py-2 border-b border-neutral-900"
              >
                {t(link.label_en, link.label_hi)}
              </a>
            ))}
          </div>

          <div className="pt-8 space-y-4 mt-auto border-t border-neutral-800">
            <button
              type="button"
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenQuoteModal();
              }}
              className="w-full py-4 bg-[#C9A24B] text-[#0E0E0D] font-medium text-xs tracking-[0.2em] uppercase transition-all"
            >
              {t('Book Free Site Consultation', 'फ्री साइट विजिट बुक करें')}
            </button>

            <div className="grid grid-cols-2 gap-3 pt-2 text-xs">
              <a
                href={`tel:${settings.phone.replace(/[^0-9+]/g, '')}`}
                className="flex items-center justify-center gap-2 py-3 border border-neutral-800 text-neutral-300 hover:text-white"
              >
                <Phone className="w-3.5 h-3.5 text-[#C9A24B]" />
                <span>Direct Call</span>
              </a>

              <a
                href={`https://wa.me/${settings.whatsappNumber}?text=${encodeURIComponent('Hello AK Interior, I would like to get a quote for wall panels.')}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-2 py-3 border border-neutral-800 text-[#DFC27E]"
              >
                <MessageCircle className="w-3.5 h-3.5" />
                <span>WhatsApp</span>
              </a>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

