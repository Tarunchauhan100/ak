import React, { useState } from 'react';
import { useLanguage } from '../../context/LanguageContext';
import { useData } from '../../context/DataContext';
import { 
  Phone, 
  Mail, 
  MapPin, 
  Clock, 
  Send, 
  Sparkles, 
  CheckCircle, 
  MessageCircle, 
  Instagram, 
  Facebook, 
  Youtube 
} from 'lucide-react';

export const ContactSection: React.FC = () => {
  const { t } = useLanguage();
  const { settings, submitEnquiry, categories } = useData();

  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    city: 'Jaipur',
    service: 'Charcoal Louvers & TV Wall',
    approxAreaSqFt: '100',
    message: '',
  });

  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim() || !formData.phone.trim()) {
      setErrorMsg(t('Please enter your name and contact phone.', 'कृपया नाम और मोबाइल नंबर दर्ज करें।'));
      return;
    }

    setSubmitting(true);
    setErrorMsg('');

    try {
      await submitEnquiry({
        name: formData.name.trim(),
        phone: formData.phone.trim(),
        city: formData.city.trim(),
        service: formData.service,
        approxAreaSqFt: formData.approxAreaSqFt,
        message: formData.message.trim(),
      });
      setSuccess(true);
      setFormData({
        name: '',
        phone: '',
        city: 'Jaipur',
        service: 'Charcoal Louvers & TV Wall',
        approxAreaSqFt: '100',
        message: '',
      });
    } catch (err) {
      console.error(err);
      setErrorMsg(t('Failed to submit enquiry. Please call or WhatsApp us directly.', 'फॉर्म जमा करने में त्रुटि। कृपया सीधे कॉल या व्हाट्सएप करें।'));
    } finally {
      setSubmitting(false);
    }
  };

  const whatsappDirectUrl = `https://wa.me/${settings.whatsappNumber}?text=${encodeURIComponent('Hello AK Interior, I would like to schedule a free site visit / get a quote for wall panels.')}`;

  return (
    <section id="contact" className="py-24 bg-[#121212] text-[#F7F3EC] relative border-t border-neutral-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-[#DFC27E] text-[10px] font-mono tracking-[0.3em] uppercase block mb-3">
            {t('CONCIERGE & VISITS', 'संपर्क व साइट विजिट')}
          </span>
          <h2 className="text-3xl sm:text-5xl font-serif text-white tracking-tight mb-4">
            {t('Schedule Your Free Site Visit & Quote', 'फ्री साइट विजिट व कोटेशन बुक करें')}
          </h2>
          <p className="text-xs sm:text-sm text-neutral-400 font-light leading-relaxed">
            {t(
              'Our interior specialists will visit with full catalog folders and physical panel swatches to take laser measurements.',
              'हमारे विशेषज्ञ आपके घर आकर लेज़र से सटीक नाप लेंगे और ओरिजिनल सैंपल दिखाएंगे।'
            )}
          </p>
        </div>

        {/* 2-Column Layout: Form & Showroom Details */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16">
          {/* Form Column (7 Cols) */}
          <div className="lg:col-span-7 bg-[#181818] border border-[#C9A24B]/30 p-8 sm:p-10 shadow-2xl">
            <h3 className="text-xl font-serif font-bold text-white mb-2">
              {t('Send Your Requirement', 'अपनी आवश्यकताएं भेजें')}
            </h3>
            <p className="text-xs text-neutral-400 mb-8">
              {t('We typically respond within 15–30 minutes during showroom hours.', 'हम 15-30 मिनट के भीतर आपसे संपर्क करेंगे।')}
            </p>

            {success ? (
              <div className="py-12 text-center space-y-4">
                <div className="w-16 h-16 bg-green-500/10 border border-green-500/30 rounded-full flex items-center justify-center mx-auto text-green-400">
                  <CheckCircle className="w-9 h-9" />
                </div>
                <h4 className="text-2xl font-serif text-white font-bold">
                  {t('Thank You! Enquiry Recorded.', 'धन्यवाद! आपकी रिक्वेस्ट दर्ज हो गई है।')}
                </h4>
                <p className="text-xs text-neutral-300 max-w-sm mx-auto leading-relaxed">
                  {t(
                    'Our senior interior executive will call you to confirm your convenient appointment time for site measurement.',
                    'हमारे प्रतिनिधि आपसे शीघ्र कॉल कर नाप व विजिट का समय सुनिश्चित करेंगे।'
                  )}
                </p>

                <div className="pt-4 flex flex-col sm:flex-row justify-center gap-3">
                  <a
                    href={whatsappDirectUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center justify-center gap-2 px-6 py-3 bg-[#25D366] hover:bg-[#20ba59] text-white font-bold text-xs uppercase tracking-wider"
                  >
                    <MessageCircle className="w-4 h-4 fill-white/20" />
                    <span>Chat on WhatsApp Now</span>
                  </a>

                  <button
                    onClick={() => setSuccess(false)}
                    className="px-5 py-3 border border-neutral-700 text-xs text-neutral-300 hover:text-white"
                  >
                    Submit Another Inquiry
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                {errorMsg && (
                  <div className="p-3 bg-red-950/70 border border-red-800 text-red-300 text-xs">
                    {errorMsg}
                  </div>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-neutral-300 mb-1">
                      {t('Full Name *', 'पूरा नाम *')}
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      placeholder="e.g. Tarun Sharma"
                      className="w-full bg-[#121212] border border-neutral-700 px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-[#C9A24B]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-neutral-300 mb-1">
                      {t('WhatsApp / Mobile *', 'मोबाइल नंबर *')}
                    </label>
                    <input
                      type="tel"
                      required
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      placeholder="e.g. +91 98765 43210"
                      className="w-full bg-[#121212] border border-neutral-700 px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-[#C9A24B]"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-neutral-300 mb-1">
                      {t('City / Area', 'शहर / इलाका')}
                    </label>
                    <input
                      type="text"
                      value={formData.city}
                      onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                      placeholder="e.g. Jaipur (Mansarovar / Vaishali)"
                      className="w-full bg-[#121212] border border-neutral-700 px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-[#C9A24B]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-neutral-300 mb-1">
                      {t('Approx Wall Area (Sq Ft)', 'दीवार का क्षेत्रफल (वर्ग फुट)')}
                    </label>
                    <input
                      type="text"
                      value={formData.approxAreaSqFt}
                      onChange={(e) => setFormData({ ...formData, approxAreaSqFt: e.target.value })}
                      placeholder="e.g. 100 sq ft or 1 Wall"
                      className="w-full bg-[#121212] border border-neutral-700 px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-[#C9A24B]"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-neutral-300 mb-1">
                    {t('Service / Panel Category of Interest', 'उत्पाद या कार्य का प्रकार')}
                  </label>
                  <select
                    value={formData.service}
                    onChange={(e) => setFormData({ ...formData, service: e.target.value })}
                    className="w-full bg-[#121212] border border-neutral-700 px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-[#C9A24B]"
                  >
                    <option value="Signature TV Media Wall Package">Signature TV Media Wall Package</option>
                    <option value="Royal Charcoal Louvers & Fluted Panels">Royal Charcoal Louvers & Fluted Panels</option>
                    <option value="Statuario UV Marble Sheets (8x4 ft)">Statuario UV Marble Sheets (8x4 ft)</option>
                    <option value="100% Waterproof PVC Wall Panels (Anti-Seelan)">100% Waterproof PVC Wall Panels (Anti-Seelan)</option>
                    <option value="WPC Exterior & Interior Fluted Slats">WPC Exterior & Interior Fluted Slats</option>
                    <option value="Magnetic Profile Lights & Cove Lighting">Magnetic Profile Lights & Cove Lighting</option>
                    <option value="PVC Ceiling & Designer False Ceiling">PVC Ceiling & Designer False Ceiling</option>
                    <option value="Full House Turnkey Interior Finishing">Full House Turnkey Interior Finishing</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-neutral-300 mb-1">
                    {t('Message / Specific Instructions', 'अतिरिक्त विवरण या कमरे का विवरण')}
                  </label>
                  <textarea
                    rows={3}
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    placeholder={t('Tell us about your wall surface (e.g. dampness, bare wall, new construction) or convenient visit timing.', 'दीवार की स्थिति (जैसे सीलन, नई दीवार) या अपने सुविधाजनक समय के बारे में बताएं।')}
                    className="w-full bg-[#121212] border border-neutral-700 px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-[#C9A24B]"
                  />
                </div>

                <div className="pt-2">
                  <button
                    type="submit"
                    disabled={submitting}
                    className="w-full py-4 bg-gradient-to-r from-[#C9A24B] to-[#B38B36] hover:from-[#DFC27E] hover:to-[#C9A24B] text-[#121212] font-bold text-xs uppercase tracking-[0.2em] shadow-xl shadow-[#C9A24B]/20 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                  >
                    {submitting ? (
                      <span>Submitting...</span>
                    ) : (
                      <>
                        <Send className="w-4 h-4" />
                        <span>{t('Confirm Free Site Visit Booking', 'फ्री साइट विजिट बुक करें')}</span>
                      </>
                    )}
                  </button>
                </div>
              </form>
            )}
          </div>

          {/* Right Column: Contact Cards & Google Maps (5 Cols) */}
          <div className="lg:col-span-5 space-y-6 flex flex-col justify-between">
            {/* Direct Contact Cards */}
            <div className="bg-[#181818] border border-neutral-800 p-6 space-y-5">
              <h3 className="text-lg font-serif font-bold text-white border-b border-neutral-800 pb-3">
                {t('Showroom & Contact Points', 'कार्यालय व संपर्क')}
              </h3>

              <div className="flex items-start gap-3.5">
                <div className="w-9 h-9 border border-[#C9A24B]/40 bg-[#121212] flex items-center justify-center text-[#C9A24B] shrink-0 mt-0.5">
                  <MapPin className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-semibold uppercase tracking-wider text-neutral-400">
                    {t('Showroom Address', 'शोरूम का पता')}
                  </h4>
                  <p className="text-xs text-white mt-1 leading-relaxed">{settings.address}</p>
                </div>
              </div>

              <div className="flex items-start gap-3.5">
                <div className="w-9 h-9 border border-[#C9A24B]/40 bg-[#121212] flex items-center justify-center text-[#C9A24B] shrink-0 mt-0.5">
                  <Phone className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-semibold uppercase tracking-wider text-neutral-400">
                    {t('Phone & Helpline', 'हेल्पलाइन नंबर')}
                  </h4>
                  <p className="text-xs text-white mt-1">
                    <a href={`tel:${settings.phone.replace(/[^0-9+]/g, '')}`} className="hover:text-[#DFC27E]">
                      {settings.phone}
                    </a>
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3.5">
                <div className="w-9 h-9 border border-[#C9A24B]/40 bg-[#121212] flex items-center justify-center text-[#C9A24B] shrink-0 mt-0.5">
                  <MessageCircle className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-semibold uppercase tracking-wider text-neutral-400">
                    {t('WhatsApp Inquiries', 'व्हाट्सएप पूछताछ')}
                  </h4>
                  <p className="text-xs text-[#25D366] mt-1 font-semibold">
                    <a href={whatsappDirectUrl} target="_blank" rel="noopener noreferrer" className="hover:underline">
                      +{settings.whatsappNumber} (Instant Reply)
                    </a>
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3.5">
                <div className="w-9 h-9 border border-[#C9A24B]/40 bg-[#121212] flex items-center justify-center text-[#C9A24B] shrink-0 mt-0.5">
                  <Clock className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-semibold uppercase tracking-wider text-neutral-400">
                    {t('Visiting Hours', 'कार्य समय')}
                  </h4>
                  <p className="text-xs text-neutral-300 mt-1">{settings.workingHours}</p>
                </div>
              </div>
            </div>

            {/* Google Maps Embed */}
            <div className="bg-[#181818] border border-neutral-800 p-2 overflow-hidden aspect-[16/9] shadow-xl">
              <iframe
                title="AK Interior Showroom Location"
                src={settings.googleMapsEmbedUrl || 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d113911.36531398864!2d75.71448883641214!3d26.885141673891054!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x396c4adf4c57e281%3A0xce1c63a0cf22e09!2sJaipur%2C%20Rajasthan!5e0!3m2!1sen!2sin!4v1700000000000!5m2!1sen!2sin'}
                width="100%"
                height="100%"
                style={{ border: 0, filter: 'grayscale(60%) invert(92%) contrast(83%)' }}
                allowFullScreen={false}
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
