import React, { useState, useEffect } from 'react';
import { useLanguage } from '../../context/LanguageContext';
import { useData } from '../../context/DataContext';
import { X, Send, Sparkles, CheckCircle, MessageCircle, Phone } from 'lucide-react';

interface QuoteModalProps {
  isOpen: boolean;
  onClose: () => void;
  prefilledProduct?: string;
}

export const QuoteModal: React.FC<QuoteModalProps> = ({
  isOpen,
  onClose,
  prefilledProduct = '',
}) => {
  const { t, language } = useLanguage();
  const { submitEnquiry, settings, categories } = useData();

  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    city: 'Jaipur',
    service: prefilledProduct || 'Charcoal Louvers & TV Wall',
    approxAreaSqFt: '120',
    message: '',
  });

  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  useEffect(() => {
    if (prefilledProduct) {
      setFormData(prev => ({ ...prev, service: prefilledProduct }));
    }
  }, [prefilledProduct]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim() || !formData.phone.trim()) {
      setErrorMsg(t('Please enter your name and phone number.', 'कृपया अपना नाम और मोबाइल नंबर दर्ज करें।'));
      return;
    }

    setSubmitting(true);
    setErrorMsg('');

    try {
      await submitEnquiry({
        name: formData.name.trim(),
        phone: formData.phone.trim(),
        city: formData.city.trim(),
        service: formData.service,
        approxAreaSqFt: formData.approxAreaSqFt,
        message: formData.message.trim(),
      });
      setSuccess(true);
    } catch (err) {
      console.error(err);
      setErrorMsg(t('Failed to submit quote request. Please call or WhatsApp us directly.', 'फॉर्म जमा करने में त्रुटि। कृपया सीधे कॉल या व्हाट्सएप करें।'));
    } finally {
      setSubmitting(false);
    }
  };

  const whatsappMessage = encodeURIComponent(
    `Hello AK Interior, I want to book a Free Site Visit / Quote:\n• Name: ${formData.name}\n• Phone: ${formData.phone}\n• City: ${formData.city}\n• Service: ${formData.service}\n• Approx Area: ${formData.approxAreaSqFt} sq ft\n• Message: ${formData.message}`
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-[#181818] border border-[#C9A24B]/40 rounded-none w-full max-w-lg overflow-hidden shadow-2xl relative text-neutral-200">
        {/* Header bar */}
        <div className="flex items-center justify-between p-6 pb-4 border-b border-neutral-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-none bg-[#C9A24B]/10 border border-[#C9A24B]/40 flex items-center justify-center">
              <Sparkles className="w-4 h-4 text-[#C9A24B]" />
            </div>
            <div>
              <h3 className="text-lg font-serif font-bold text-white tracking-wide">
                {t('Request Free Site Visit & Quote', 'फ्री साइट विजिट व कोटेशन')}
              </h3>
              <p className="text-xs text-neutral-400">
                {t('Get laser measurement & sample catalog at your doorstep', 'घर बैठे लेज़र नाप व असली सैंपल्स देखें')}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-neutral-400 hover:text-white p-1 rounded-sm transition-colors"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6">
          {success ? (
            <div className="text-center py-6 space-y-4">
              <div className="w-14 h-14 bg-green-500/10 border border-green-500/30 rounded-full flex items-center justify-center mx-auto text-green-400">
                <CheckCircle className="w-8 h-8" />
              </div>
              <h4 className="text-xl font-serif text-white font-semibold">
                {t('Quote Request Received!', 'आपकी रिक्वेस्ट प्राप्त हो गई है!')}
              </h4>
              <p className="text-xs text-neutral-400 max-w-sm mx-auto leading-relaxed">
                {t(
                  'Our interior expert will call you shortly to confirm your convenient time for the site visit and catalog presentation.',
                  'हमारे प्रतिनिधि आपसे शीघ्र संपर्क कर साइट विजिट और सैंपल्स दिखाने के समय की पुष्टि करेंगे।'
                )}
              </p>

              <div className="pt-4 flex flex-col sm:flex-row gap-3">
                <a
                  href={`https://wa.me/${settings.whatsappNumber}?text=${whatsappMessage}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 py-3 bg-[#25D366] hover:bg-[#20ba59] text-white text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg"
                >
                  <MessageCircle className="w-4 h-4 fill-white/20" />
                  <span>Send Direct on WhatsApp</span>
                </a>

                <button
                  onClick={() => {
                    setSuccess(false);
                    onClose();
                  }}
                  className="px-5 py-3 border border-neutral-700 hover:border-neutral-500 text-xs text-neutral-300 font-semibold uppercase"
                >
                  Done
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              {errorMsg && (
                <div className="p-3 bg-red-950/60 border border-red-800 text-red-300 text-xs">
                  {errorMsg}
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-neutral-300 mb-1">
                    {t('Your Name *', 'आपका नाम *')}
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="e.g. Ramesh Sharma"
                    className="w-full bg-[#121212] border border-neutral-700 px-3 py-2 text-sm text-white focus:outline-none focus:border-[#C9A24B]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-neutral-300 mb-1">
                    {t('Mobile Number *', 'मोबाइल नंबर *')}
                  </label>
                  <input
                    type="tel"
                    required
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    placeholder="e.g. 98765 43210"
                    className="w-full bg-[#121212] border border-neutral-700 px-3 py-2 text-sm text-white focus:outline-none focus:border-[#C9A24B]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-neutral-300 mb-1">
                    {t('City / Location', 'शहर / इलाका')}
                  </label>
                  <input
                    type="text"
                    value={formData.city}
                    onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                    placeholder="e.g. Jaipur, Gurugram, Delhi"
                    className="w-full bg-[#121212] border border-neutral-700 px-3 py-2 text-sm text-white focus:outline-none focus:border-[#C9A24B]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-neutral-300 mb-1">
                    {t('Approx Wall Area (Sq Ft)', 'अनुमानित क्षेत्रफल (वर्ग फुट)')}
                  </label>
                  <input
                    type="text"
                    value={formData.approxAreaSqFt}
                    onChange={(e) => setFormData({ ...formData, approxAreaSqFt: e.target.value })}
                    placeholder="e.g. 100 sq ft, 2 Rooms"
                    className="w-full bg-[#121212] border border-neutral-700 px-3 py-2 text-sm text-white focus:outline-none focus:border-[#C9A24B]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-neutral-300 mb-1">
                  {t('Service / Panel Interested In', 'पसंदीदा उत्पाद या सेवा')}
                </label>
                <select
                  value={formData.service}
                  onChange={(e) => setFormData({ ...formData, service: e.target.value })}
                  className="w-full bg-[#121212] border border-neutral-700 px-3 py-2 text-sm text-white focus:outline-none focus:border-[#C9A24B]"
                >
                  <option value="Signature TV Media Wall Package">Signature TV Media Wall Package</option>
                  <option value="Charcoal Louvers & Fluted Panels">Charcoal Louvers & Fluted Panels</option>
                  <option value="Statuario UV Marble Sheets">Statuario UV Marble Sheets</option>
                  <option value="PVC Wall Paneling (Waterproof / Anti-Seelan)">PVC Wall Paneling (Anti-Seelan)</option>
                  <option value="WPC Exterior & Interior Louvers">WPC Exterior & Interior Louvers</option>
                  <option value="Magnetic Profile & Concealed Cove Lights">Magnetic Profile & Cove Lights</option>
                  <option value="False Ceiling & Wooden Grid Ceiling">False Ceiling & Wooden Grid Ceiling</option>
                  <option value="Full House Turnkey Interior">Full House Turnkey Interior</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-neutral-300 mb-1">
                  {t('Any Specific Requirement or Room Details', 'अन्य कोई जानकारी या आवश्यकता')}
                </label>
                <textarea
                  rows={2}
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  placeholder={t('e.g. Living room TV wall 10x8 ft, dampness on lower wall, need warm lights', 'जैसे: 10x8 फीट की टीवी वॉल, सीलन का समाधान और वार्म लाइट्स चाहिए')}
                  className="w-full bg-[#121212] border border-neutral-700 px-3 py-2 text-sm text-white focus:outline-none focus:border-[#C9A24B]"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2.5 text-xs text-neutral-400 hover:text-white"
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  disabled={submitting}
                  className="px-6 py-2.5 bg-gradient-to-r from-[#C9A24B] to-[#B38B36] hover:from-[#DFC27E] hover:to-[#C9A24B] text-[#121212] font-bold text-xs uppercase tracking-wider flex items-center gap-2 shadow-lg shadow-[#C9A24B]/20 disabled:opacity-50 cursor-pointer"
                >
                  {submitting ? (
                    <span>Submitting...</span>
                  ) : (
                    <>
                      <Send className="w-3.5 h-3.5" />
                      <span>{t('Book Free Visit', 'फ्री विजिट बुक करें')}</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
