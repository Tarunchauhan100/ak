import React, { useState } from 'react';
import { useLanguage } from '../../context/LanguageContext';
import { useData } from '../../context/DataContext';
import { Sparkles, ChevronDown, MessageCircle, HelpCircle } from 'lucide-react';

export const FAQSection: React.FC = () => {
  const { t } = useLanguage();
  const { siteContent, settings } = useData();

  const [openId, setOpenId] = useState<string | null>('faq-01');

  const toggleFAQ = (id: string) => {
    setOpenId((prev) => (prev === id ? null : id));
  };

  const whatsappAskUrl = `https://wa.me/${settings.whatsappNumber}?text=${encodeURIComponent('Hello AK Interior, I have a question regarding wall panels/pricing:')}`;

  return (
    <section id="faq" className="py-24 bg-[#151515] text-[#F7F3EC] relative border-t border-neutral-900">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-[#DFC27E] text-[10px] font-mono tracking-[0.3em] uppercase block mb-3">
            {t('KNOWLEDGE BASE', 'प्रश्नोत्तरी')}
          </span>
          <h2 className="text-3xl sm:text-5xl font-serif text-white tracking-tight mb-4">
            {t('Frequently Asked Questions', 'अक्सर पूछे जाने वाले प्रश्न')}
          </h2>
          <p className="text-xs sm:text-sm text-neutral-400 font-light leading-relaxed">
            {t(
              'Key details about water resistance, damp wall treatment, timelines, and warranties.',
              'सीलन से बचाव, इंस्टॉलेशन का समय और 10 साल की वारंटी से जुड़ी सभी जरूरी जानकारियां।'
            )}
          </p>
        </div>

        {/* Accordion list */}
        <div className="space-y-4">
          {siteContent.faqs?.map((faq) => {
            const isOpen = openId === faq.id;

            return (
              <div
                key={faq.id}
                className="bg-[#1A1A1A] border border-neutral-800 hover:border-neutral-700 transition-colors"
              >
                <button
                  type="button"
                  onClick={() => toggleFAQ(faq.id)}
                  className="w-full text-left p-6 flex items-center justify-between gap-4 cursor-pointer focus:outline-none"
                >
                  <span className="text-base sm:text-lg font-serif font-semibold text-white tracking-wide">
                    {t(faq.q_en, faq.q_hi)}
                  </span>
                  <div
                    className={`w-8 h-8 rounded-full border border-neutral-700 flex items-center justify-center shrink-0 transition-transform duration-200 ${
                      isOpen ? 'rotate-180 border-[#C9A24B] text-[#C9A24B]' : 'text-neutral-400'
                    }`}
                  >
                    <ChevronDown className="w-4 h-4" />
                  </div>
                </button>

                {isOpen && (
                  <div className="px-6 pb-6 pt-1 text-xs sm:text-sm text-neutral-300 font-light leading-relaxed border-t border-neutral-800/60 animate-in fade-in duration-200">
                    {t(faq.a_en, faq.a_hi)}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Still have questions banner */}
        <div className="mt-12 text-center p-6 bg-[#181818] border border-[#C9A24B]/30 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="text-left">
            <h4 className="text-sm font-semibold text-white">
              {t('Have another question about your specific site?', 'क्या आपके कमरे के बारे में कोई अन्य सवाल है?')}
            </h4>
            <p className="text-xs text-neutral-400">
              {t('Ask our technical master craftsman directly on WhatsApp.', 'व्हाट्सएप पर तुरंत पूछें और समाधान पाएं।')}
            </p>
          </div>

          <a
            href={whatsappAskUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-5 py-2.5 bg-[#25D366] hover:bg-[#20ba59] text-white font-bold text-xs uppercase tracking-wider transition-colors whitespace-nowrap shadow-md"
          >
            <MessageCircle className="w-4 h-4 fill-white/20" />
            <span>{t('Ask on WhatsApp', 'व्हाट्सएप पर पूछें')}</span>
          </a>
        </div>
      </div>
    </section>
  );
};
