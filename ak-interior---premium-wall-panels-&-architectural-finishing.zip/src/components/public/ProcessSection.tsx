import React from 'react';
import { useLanguage } from '../../context/LanguageContext';
import { useData } from '../../context/DataContext';
import { Sparkles, ArrowRight } from 'lucide-react';

interface ProcessSectionProps {
  onOpenQuoteModal: () => void;
}

export const ProcessSection: React.FC<ProcessSectionProps> = ({ onOpenQuoteModal }) => {
  const { t } = useLanguage();
  const { siteContent } = useData();

  return (
    <section className="py-24 bg-[#121212] text-[#F7F3EC] relative border-t border-neutral-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-[#DFC27E] text-[10px] font-mono tracking-[0.3em] uppercase block mb-3">
            {t('SEAMLESS WORKFLOW', 'हमारी कार्यप्रणाली')}
          </span>
          <h2 className="text-3xl sm:text-5xl font-serif text-white tracking-tight mb-4">
            {t('From Concept To Handover in 5 Steps', '5 आसान चरणों में परफेक्ट वॉल फिनिशिंग')}
          </h2>
          <p className="text-xs sm:text-sm text-neutral-400 font-light leading-relaxed">
            {t(
              'A streamlined, hassle-free turnkey workflow engineered to save time and guarantee millimeter precision.',
              'बिना किसी परेशानी के सुचारू कार्यप्रणाली जिससे आपका समय बचे और दीवारों को मिले शानदार फिनिशिंग।'
            )}
          </p>
        </div>

        {/* Steps Horizontal / Grid Timeline */}
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-6 relative">
          {siteContent.processSteps?.map((step, idx) => (
            <div
              key={step.step || idx}
              className="bg-[#181818] border border-neutral-800 hover:border-[#C9A24B]/50 p-6 flex flex-col justify-between group transition-all relative"
            >
              <div>
                {/* Step number badge */}
                <div className="flex items-center justify-between mb-4">
                  <span className="text-3xl font-serif font-bold text-[#DFC27E] opacity-70 group-hover:opacity-100 group-hover:scale-110 transition-all font-mono">
                    {step.step}
                  </span>
                  {idx < (siteContent.processSteps.length - 1) && (
                    <span className="hidden lg:block text-neutral-700 text-xs font-mono">
                      →
                    </span>
                  )}
                </div>

                <h3 className="text-base font-serif font-bold text-white mb-2 leading-snug group-hover:text-gold-gradient transition-colors">
                  {t(step.title_en, step.title_hi)}
                </h3>

                <p className="text-xs text-neutral-400 leading-relaxed font-light">
                  {t(step.desc_en, step.desc_hi)}
                </p>
              </div>

              <div className="pt-4 mt-4 border-t border-neutral-800/60 text-[10px] uppercase font-mono tracking-wider text-neutral-500 group-hover:text-[#DFC27E]">
                Phase 0{idx + 1}
              </div>
            </div>
          ))}
        </div>

        {/* Call to Action bar */}
        <div className="mt-12 text-center">
          <button
            type="button"
            onClick={onOpenQuoteModal}
            className="inline-flex items-center gap-2 px-8 py-3.5 bg-gradient-to-r from-[#C9A24B] to-[#B38B36] hover:from-[#DFC27E] hover:to-[#C9A24B] text-[#121212] font-bold text-xs uppercase tracking-[0.2em] shadow-xl shadow-[#C9A24B]/20 cursor-pointer"
          >
            <span>{t('Start Step 1: Request Free Consultation', 'चरण 1 शुरू करें: फ्री संपर्क करें')}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </section>
  );
};
