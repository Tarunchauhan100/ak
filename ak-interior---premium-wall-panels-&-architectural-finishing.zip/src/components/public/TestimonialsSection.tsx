import React, { useState, useEffect } from 'react';
import { useLanguage } from '../../context/LanguageContext';
import { useData } from '../../context/DataContext';
import { Sparkles, Star, ChevronLeft, ChevronRight, Quote, CheckCircle2 } from 'lucide-react';

export const TestimonialsSection: React.FC = () => {
  const { t } = useLanguage();
  const { testimonials } = useData();

  const approvedReviews = testimonials.filter(t => t.approved !== false);
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [isPaused, setIsPaused] = useState<boolean>(false);

  // Auto slide
  useEffect(() => {
    if (isPaused || approvedReviews.length <= 1) return;
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % approvedReviews.length);
    }, 5500);
    return () => clearInterval(interval);
  }, [isPaused, approvedReviews.length]);

  if (approvedReviews.length === 0) return null;

  const current = approvedReviews[currentIndex];

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev - 1 + approvedReviews.length) % approvedReviews.length);
  };

  const handleNext = () => {
    setCurrentIndex((prev) => (prev + 1) % approvedReviews.length);
  };

  return (
    <section id="testimonials" className="py-24 bg-[#121212] text-[#F7F3EC] relative border-t border-neutral-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-[#DFC27E] text-[10px] font-mono tracking-[0.3em] uppercase block mb-3">
            {t('VERIFIED TESTIMONIALS', 'ग्राहकों के अनुभव')}
          </span>
          <h2 className="text-3xl sm:text-5xl font-serif text-white tracking-tight mb-4">
            {t('Words of Appreciation from Real Clients', 'संतुष्ट ग्राहकों की राय')}
          </h2>
          <p className="text-xs sm:text-sm text-neutral-400 font-light leading-relaxed">
            {t(
              'Verified feedback from homeowners and architects across India.',
              'जानिए हमारे ग्राहकों ने काम की गुणवत्ता और फिनिशिंग के बारे में क्या कहा।'
            )}
          </p>
        </div>

        {/* Carousel Showcase Card */}
        <div
          onMouseEnter={() => setIsPaused(true)}
          onMouseLeave={() => setIsPaused(false)}
          className="max-w-4xl mx-auto bg-[#181818] border border-[#C9A24B]/30 p-8 sm:p-14 relative shadow-2xl transition-all"
        >
          {/* Subtle gold quote icon */}
          <div className="absolute top-6 right-8 text-[#C9A24B]/20 pointer-events-none">
            <Quote className="w-16 h-16" />
          </div>

          <div className="relative z-10 flex flex-col md:flex-row items-center md:items-start gap-8">
            {/* Customer Photo */}
            <div className="relative shrink-0">
              <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-full border-2 border-[#C9A24B] overflow-hidden shadow-xl bg-neutral-900">
                <img
                  src={current.photo || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80'}
                  alt={current.name}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="absolute -bottom-1 -right-1 w-7 h-7 bg-[#C9A24B] rounded-full flex items-center justify-center text-[#121212] shadow-md" title="Verified Customer">
                <CheckCircle2 className="w-4 h-4" />
              </div>
            </div>

            {/* Testimonial Text & Details */}
            <div className="flex-1 text-center md:text-left space-y-4">
              {/* Star Rating */}
              <div className="flex items-center justify-center md:justify-start gap-1 text-[#C9A24B]">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`w-4 h-4 ${i < current.rating ? 'fill-[#C9A24B]' : 'text-neutral-700'}`}
                  />
                ))}
                <span className="text-xs text-neutral-400 font-mono ml-2">
                  {current.rating}.0 / 5.0
                </span>
              </div>

              {/* Review Quote */}
              <p className="text-base sm:text-lg text-neutral-200 font-serif-luxury italic leading-relaxed">
                "{t(current.review_en, current.review_hi)}"
              </p>

              {/* Customer Meta */}
              <div className="pt-2 border-t border-neutral-800/80">
                <h4 className="text-base font-serif font-bold text-white tracking-wide">
                  {current.name}
                </h4>
                <div className="flex flex-wrap items-center justify-center md:justify-start gap-2 text-xs text-neutral-400 mt-0.5">
                  <span className="text-[#DFC27E]">{current.city}</span>
                  <span>•</span>
                  <span className="font-light">{current.projectType}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Carousel Arrows & Dots */}
          <div className="mt-10 pt-6 border-t border-neutral-800 flex items-center justify-between">
            <div className="flex items-center gap-1.5">
              {approvedReviews.map((_, i) => (
                <button
                  key={i}
                  onClick={() => setCurrentIndex(i)}
                  aria-label={`Go to testimonial ${i + 1}`}
                  className={`h-1.5 transition-all rounded-full ${
                    i === currentIndex ? 'w-8 bg-[#C9A24B]' : 'w-2 bg-neutral-700 hover:bg-neutral-500'
                  }`}
                />
              ))}
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handlePrev}
                className="w-9 h-9 border border-neutral-700 hover:border-[#C9A24B] bg-neutral-900 text-neutral-300 hover:text-white flex items-center justify-center transition-colors"
                aria-label="Previous review"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={handleNext}
                className="w-9 h-9 border border-neutral-700 hover:border-[#C9A24B] bg-neutral-900 text-neutral-300 hover:text-white flex items-center justify-center transition-colors"
                aria-label="Next review"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
