import React, { useState } from 'react';
import { useLanguage } from '../../context/LanguageContext';
import { useData } from '../../context/DataContext';
import { Calculator, Sparkles, MessageCircle, ArrowRight, Check } from 'lucide-react';

interface CostCalculatorProps {
  onOpenQuoteModal: (productName?: string) => void;
}

export const CostCalculator: React.FC<CostCalculatorProps> = ({ onOpenQuoteModal }) => {
  const { t } = useLanguage();
  const { settings } = useData();

  // Inputs
  const [wallWidthFt, setWallWidthFt] = useState<number>(10);
  const [wallHeightFt, setWallHeightFt] = useState<number>(8);
  const [materialType, setMaterialType] = useState<string>('charcoal_marble');
  const [includeLighting, setIncludeLighting] = useState<boolean>(true);
  const [includeInstallation, setIncludeInstallation] = useState<boolean>(true);

  // Calculations
  const totalSqFt = Math.max(10, Math.round(wallWidthFt * wallHeightFt));

  // Material rates per sq ft (approx)
  const materialRates: Record<string, { label_en: string; label_hi: string; rate: number; desc: string }> = {
    pvc_standard: {
      label_en: 'Heavy-Duty Waterproof PVC Panels',
      label_hi: 'वाटरप्रूफ पीवीसी पैनल्स (सीलन रोधी)',
      rate: 85,
      desc: '100% moisture proof, budget-friendly tongue & groove.',
    },
    charcoal_louver: {
      label_en: 'Royal Charcoal Fluted Louvers',
      label_hi: 'रॉयल चारकोल फ्लूटेड लवर्स',
      rate: 185,
      desc: 'Deep 3D matte or metallic flutes for luxury accents.',
    },
    charcoal_marble: {
      label_en: 'Combo: Charcoal Louvers + Statuario UV Marble',
      label_hi: 'कॉम्बो: चारकोल लवर + यूवी मार्बल शीट',
      rate: 220,
      desc: 'Our bestselling signature living room TV wall layout.',
    },
    wpc_fluted: {
      label_en: 'Architectural WPC Exterior & Interior Slats',
      label_hi: 'WPC वुडन फ्लूटेड पैनल्स',
      rate: 195,
      desc: 'Heavy duty wood composite with authentic teak textures.',
    },
    ceiling_pvc: {
      label_en: 'Designer False Ceiling with GI Framing',
      label_hi: 'पीवीसी फॉल्स सीलिंग विद जीआई चैनल',
      rate: 110,
      desc: 'Moisture resistant false ceiling grid with batten trims.',
    },
  };

  const selectedMat = materialRates[materialType] || materialRates.charcoal_marble;
  const materialCost = Math.round(totalSqFt * selectedMat.rate);
  const lightingCost = includeLighting ? Math.round(totalSqFt * 45) : 0;
  const installationCost = includeInstallation ? Math.round(totalSqFt * 25) : 0;
  const totalEstimatedCost = materialCost + lightingCost + installationCost;

  const handleWhatsAppEstimate = () => {
    const text = encodeURIComponent(
      `Hello AK Interior, I calculated an estimate on your website:\n• Area: ${wallWidthFt}ft × ${wallHeightFt}ft (${totalSqFt} sq ft)\n• Material: ${selectedMat.label_en}\n• Lighting: ${includeLighting ? 'Yes (LED Profile)' : 'No'}\n• Installation: ${includeInstallation ? 'Yes' : 'No'}\n• Total Estimated: ₹${totalEstimatedCost.toLocaleString('en-IN')}\nCould you arrange a free site visit to verify?`
    );
    window.open(`https://wa.me/${settings.whatsappNumber}?text=${text}`, '_blank');
  };

  return (
    <section id="calculator" className="py-24 bg-[#151515] text-[#F7F3EC] relative border-t border-neutral-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-14">
          <span className="text-[#DFC27E] text-[10px] font-mono tracking-[0.3em] uppercase block mb-3">
            {t('BUDGET ESTIMATION', 'लागत अनुमान')}
          </span>
          <h2 className="text-3xl sm:text-5xl font-serif text-white tracking-tight mb-4">
            {t('Wall & Ceiling Cost Estimator', 'वॉल पैनल्स व सीलिंग लागत कैलकुलेटर')}
          </h2>
          <p className="text-xs sm:text-sm text-neutral-400 font-light leading-relaxed">
            {t(
              'Calculate real-time estimates for your room dimensions with materials, lighting, and installation.',
              'अपनी दीवार के नाप के अनुसार तुरंत अनुमानित बजट निकालें।'
            )}
          </p>
        </div>

        {/* Calculator Card */}
        <div className="bg-[#1A1A1A] border border-[#C9A24B]/30 shadow-2xl p-6 sm:p-10 max-w-5xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-10">
          {/* Left: Configuration Controls (7 Cols) */}
          <div className="lg:col-span-7 space-y-6">
            <h3 className="text-lg font-serif font-bold text-white border-b border-neutral-800 pb-3 flex items-center justify-between">
              <span>{t('1. Enter Wall Dimensions', '1. दीवार का नाप दर्ज करें')}</span>
              <span className="text-xs font-mono text-[#DFC27E] uppercase">{totalSqFt} SQ FT TOTAL</span>
            </h3>

            {/* Sliders for Width and Height */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div>
                <div className="flex justify-between text-xs font-medium text-neutral-300 mb-2">
                  <span>{t('Wall Width / Length', 'दीवार की चौड़ाई')}</span>
                  <span className="font-mono text-[#C9A24B] font-bold">{wallWidthFt} Feet</span>
                </div>
                <input
                  type="range"
                  min="4"
                  max="35"
                  step="1"
                  value={wallWidthFt}
                  onChange={(e) => setWallWidthFt(Number(e.target.value))}
                  className="w-full accent-[#C9A24B] bg-neutral-800 h-1.5 rounded-none cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-neutral-500 mt-1 font-mono">
                  <span>4 ft</span>
                  <span>35 ft</span>
                </div>
              </div>

              <div>
                <div className="flex justify-between text-xs font-medium text-neutral-300 mb-2">
                  <span>{t('Wall Height', 'दीवार की ऊंचाई')}</span>
                  <span className="font-mono text-[#C9A24B] font-bold">{wallHeightFt} Feet</span>
                </div>
                <input
                  type="range"
                  min="4"
                  max="20"
                  step="1"
                  value={wallHeightFt}
                  onChange={(e) => setWallHeightFt(Number(e.target.value))}
                  className="w-full accent-[#C9A24B] bg-neutral-800 h-1.5 rounded-none cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-neutral-500 mt-1 font-mono">
                  <span>4 ft</span>
                  <span>20 ft</span>
                </div>
              </div>
            </div>

            {/* Material Choice */}
            <div className="space-y-3 pt-2">
              <h4 className="text-xs font-semibold text-neutral-300 uppercase tracking-wider">
                {t('2. Select Surface Finish', '2. मटीरियल व फिनिश चुनें')}
              </h4>
              <div className="grid grid-cols-1 gap-2.5">
                {Object.entries(materialRates).map(([key, opt]) => (
                  <label
                    key={key}
                    className={`flex items-start gap-3 p-3 border cursor-pointer transition-all ${
                      materialType === key
                        ? 'border-[#C9A24B] bg-[#C9A24B]/10 text-white'
                        : 'border-neutral-800 bg-[#141414] text-neutral-400 hover:border-neutral-700'
                    }`}
                  >
                    <input
                      type="radio"
                      name="material"
                      value={key}
                      checked={materialType === key}
                      onChange={() => setMaterialType(key)}
                      className="mt-1 accent-[#C9A24B]"
                    />
                    <div className="flex-1 text-xs">
                      <div className="flex items-center justify-between font-semibold text-neutral-200">
                        <span>{t(opt.label_en, opt.label_hi)}</span>
                        <span className="font-mono text-[#DFC27E]">~₹{opt.rate}/sq ft</span>
                      </div>
                      <p className="text-[11px] text-neutral-400 mt-0.5">{opt.desc}</p>
                    </div>
                  </label>
                ))}
              </div>
            </div>

            {/* Optional Add-ons */}
            <div className="space-y-3 pt-2">
              <h4 className="text-xs font-semibold text-neutral-300 uppercase tracking-wider">
                {t('3. Lighting & Installation Add-ons', '3. लाइटिंग व इंस्टॉलेशन विकल्प')}
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <label className="flex items-center gap-3 p-3 bg-[#141414] border border-neutral-800 hover:border-neutral-700 cursor-pointer text-xs">
                  <input
                    type="checkbox"
                    checked={includeLighting}
                    onChange={(e) => setIncludeLighting(e.target.checked)}
                    className="accent-[#C9A24B] w-4 h-4"
                  />
                  <div>
                    <span className="font-medium text-neutral-200 block">
                      {t('Warm LED Profile Lights', 'वार्म एलईडी प्रोफाइल लाइट्स')}
                    </span>
                    <span className="text-[10px] text-neutral-400">+₹45/sq ft</span>
                  </div>
                </label>

                <label className="flex items-center gap-3 p-3 bg-[#141414] border border-neutral-800 hover:border-neutral-700 cursor-pointer text-xs">
                  <input
                    type="checkbox"
                    checked={includeInstallation}
                    onChange={(e) => setIncludeInstallation(e.target.checked)}
                    className="accent-[#C9A24B] w-4 h-4"
                  />
                  <div>
                    <span className="font-medium text-neutral-200 block">
                      {t('Master Installation & Hardware', 'कुशल कारीगर इंस्टॉलेशन')}
                    </span>
                    <span className="text-[10px] text-neutral-400">+₹25/sq ft</span>
                  </div>
                </label>
              </div>
            </div>
          </div>

          {/* Right: Calculated Summary & Actions (5 Cols) */}
          <div className="lg:col-span-5 bg-[#121212] border border-[#C9A24B]/30 p-6 sm:p-8 flex flex-col justify-between">
            <div>
              <div className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-[#C9A24B] mb-2">
                <Sparkles className="w-3.5 h-3.5" />
                <span>{t('Estimate Summary', 'लागत विवरण')}</span>
              </div>
              <h3 className="text-xl font-serif font-bold text-white mb-6">
                {t('Turnkey Estimation', 'अनुमानित कुल लागत')}
              </h3>

              {/* Itemized list */}
              <div className="space-y-3.5 text-xs border-b border-neutral-800 pb-6 mb-6">
                <div className="flex justify-between text-neutral-400">
                  <span>{t('Total Surface Area:', 'कुल क्षेत्रफल:')}</span>
                  <span className="font-mono text-white font-bold">{totalSqFt} sq ft</span>
                </div>
                <div className="flex justify-between text-neutral-400">
                  <span>{t('Engineered Panels Material:', 'मटीरियल लागत:')}</span>
                  <span className="font-mono text-white">₹{materialCost.toLocaleString('en-IN')}</span>
                </div>
                <div className="flex justify-between text-neutral-400">
                  <span>{t('Architectural Lighting:', 'एलईडी लाइट्स:')}</span>
                  <span className="font-mono text-white">
                    {includeLighting ? `₹${lightingCost.toLocaleString('en-IN')}` : '₹0'}
                  </span>
                </div>
                <div className="flex justify-between text-neutral-400">
                  <span>{t('Labour, Fasteners & Fitting:', 'इंस्टॉलेशन व फिटिंग:')}</span>
                  <span className="font-mono text-white">
                    {includeInstallation ? `₹${installationCost.toLocaleString('en-IN')}` : '₹0'}
                  </span>
                </div>
              </div>

              {/* Grand Total */}
              <div className="mb-6">
                <span className="text-[10px] text-neutral-400 uppercase tracking-widest block mb-1">
                  {t('Estimated Project Cost', 'अनुमानित कुल मूल्य')}
                </span>
                <div className="text-3xl sm:text-4xl font-serif font-bold text-white text-gold-gradient">
                  ₹{totalEstimatedCost.toLocaleString('en-IN')}*
                </div>
                <p className="text-[10px] text-neutral-500 mt-1">
                  *{t('Subject to actual site laser measurement & final selection.', 'सटीक नाप व कलर चयन के आधार पर अंतिम बिल बनेगा।')}
                </p>
              </div>
            </div>

            {/* Action buttons */}
            <div className="space-y-3 pt-4">
              <button
                type="button"
                onClick={handleWhatsAppEstimate}
                className="w-full py-3.5 bg-[#25D366] hover:bg-[#20ba59] text-white font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg transition-colors cursor-pointer"
              >
                <MessageCircle className="w-4 h-4 fill-white/20" />
                <span>{t('Send Estimate on WhatsApp', 'व्हाट्सएप पर यह एस्टीमेट भेजें')}</span>
              </button>

              <button
                type="button"
                onClick={() => onOpenQuoteModal(`Calculated Estimate: ${selectedMat.label_en} (${totalSqFt} sq ft)`)}
                className="w-full py-3.5 bg-[#C9A24B] hover:bg-[#DFC27E] text-[#121212] font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg transition-colors cursor-pointer"
              >
                <span>{t('Book Free On-Site Verification', 'फ्री साइट विजिट व नाप बुक करें')}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
