import React, { useState } from 'react';
import { useLanguage } from '../../context/LanguageContext';
import { useData } from '../../context/DataContext';
import { Product } from '../../types';
import { 
  Search, 
  LayoutGrid, 
  Table as TableIcon, 
  MessageCircle, 
  Check, 
  Sparkles, 
  Info,
  Calendar,
  Layers,
  CheckCircle2
} from 'lucide-react';

interface ProductsPricingProps {
  selectedCategoryId: string;
  onSelectCategory: (catId: string) => void;
  onOpenQuoteModal: (productName?: string) => void;
}

export const ProductsPricing: React.FC<ProductsPricingProps> = ({
  selectedCategoryId,
  onSelectCategory,
  onOpenQuoteModal,
}) => {
  const { t, language } = useLanguage();
  const { products, categories, settings } = useData();

  const [searchQuery, setSearchQuery] = useState('');
  const [viewMode, setViewMode] = useState<'grid' | 'table'>('grid');

  // Filtered products
  const filteredProducts = products.filter((prod) => {
    const matchesCategory =
      !selectedCategoryId ||
      selectedCategoryId === 'all' ||
      prod.categoryId === selectedCategoryId ||
      prod.categorySlug === selectedCategoryId;

    const matchesSearch =
      searchQuery === '' ||
      prod.name_en.toLowerCase().includes(searchQuery.toLowerCase()) ||
      prod.name_hi.toLowerCase().includes(searchQuery.toLowerCase()) ||
      prod.finish_colors.toLowerCase().includes(searchQuery.toLowerCase()) ||
      prod.size.toLowerCase().includes(searchQuery.toLowerCase()) ||
      prod.thickness.toLowerCase().includes(searchQuery.toLowerCase());

    return matchesCategory && matchesSearch;
  });

  const getWhatsAppProductUrl = (product: Product) => {
    const text = encodeURIComponent(
      `Hello AK Interior, I am interested in ${product.name_en} (${product.size}, ₹${product.price}/${product.priceUnit}). Could you please share catalog photos and installation quote?`
    );
    return `https://wa.me/${settings.whatsappNumber}?text=${text}`;
  };

  return (
    <section id="products" className="py-24 bg-[#121212] text-[#F7F3EC] relative border-t border-neutral-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Title */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <span className="text-[#DFC27E] text-[10px] font-mono tracking-[0.3em] uppercase block mb-3">
            {t('TRANSPARENT SPECIFICATIONS & PRICING', 'पारदर्शी मूल्य व स्पेसिफिकेशन्स')}
          </span>
          <h2 className="text-3xl sm:text-5xl font-serif text-white tracking-tight mb-4">
            {t('Panels, Lighting & Showroom Pricing', 'वॉल पैनल्स, लाइट्स व रेट लिस्ट')}
          </h2>
          <p className="text-xs sm:text-sm text-neutral-400 font-light leading-relaxed">
            {t(
              'Explore genuine per-sq-ft and per-piece rates for luxury charcoal louvers, waterproof PVC sheets, and lighting.',
              'चारकोल लाउवर, वाटरप्रूफ पीवीसी शीट्स और लाइट्स की वास्तविक फैक्टरी दरें।'
            )}
          </p>
        </div>

        {/* Controls Bar: Categories Tabs, Search & View Switcher */}
        <div className="space-y-6 mb-12">
          {/* Category Filter Tabs */}
          <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
            <button
              onClick={() => onSelectCategory('all')}
              className={`px-4 py-2.5 text-xs font-semibold uppercase tracking-wider whitespace-nowrap transition-all border ${
                !selectedCategoryId || selectedCategoryId === 'all'
                  ? 'bg-[#C9A24B] text-[#121212] border-[#C9A24B] shadow-md shadow-[#C9A24B]/20'
                  : 'bg-[#181818] text-neutral-300 border-neutral-800 hover:border-neutral-600'
              }`}
            >
              {t('All Products', 'सभी उत्पाद')} ({products.length})
            </button>
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => onSelectCategory(cat.id)}
                className={`px-4 py-2.5 text-xs font-semibold uppercase tracking-wider whitespace-nowrap transition-all border ${
                  selectedCategoryId === cat.id
                    ? 'bg-[#C9A24B] text-[#121212] border-[#C9A24B] shadow-md shadow-[#C9A24B]/20'
                    : 'bg-[#181818] text-neutral-300 border-neutral-800 hover:border-neutral-600'
                }`}
              >
                {t(cat.name_en, cat.name_hi)}
              </button>
            ))}
          </div>

          {/* Search Bar & Grid/Table Toggle */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 pt-2 border-t border-neutral-800/80">
            <div className="relative flex-1 max-w-md">
              <Search className="w-4 h-4 text-neutral-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={t('Search by panel, finish, thickness or size...', 'मॉडल, साइज या कलर के अनुसार खोजें...')}
                className="w-full bg-[#181818] border border-neutral-700 pl-10 pr-4 py-2.5 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-[#C9A24B]"
              />
            </div>

            <div className="flex items-center justify-end gap-3">
              <span className="text-xs text-neutral-400 font-mono">
                {filteredProducts.length} {t('items found', 'उत्पाद उपलब्ध')}
              </span>

              {/* View Mode Toggle */}
              <div className="flex items-center border border-neutral-700 bg-[#181818] p-0.5">
                <button
                  onClick={() => setViewMode('grid')}
                  title="Grid Cards View"
                  className={`p-1.5 transition-colors ${
                    viewMode === 'grid' ? 'bg-[#C9A24B] text-[#121212]' : 'text-neutral-400 hover:text-white'
                  }`}
                >
                  <LayoutGrid className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setViewMode('table')}
                  title="Price List Table View"
                  className={`p-1.5 transition-colors ${
                    viewMode === 'table' ? 'bg-[#C9A24B] text-[#121212]' : 'text-neutral-400 hover:text-white'
                  }`}
                >
                  <TableIcon className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Products Display: GRID VIEW */}
        {viewMode === 'grid' ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredProducts.map((product) => {
              const primaryImage = product.images?.[0] || 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=800&q=80';
              const catObj = categories.find(c => c.id === product.categoryId || c.slug === product.categorySlug);

              return (
                <div
                  key={product.id}
                  className="bg-[#181818] border border-neutral-800 hover:border-[#C9A24B]/50 transition-all duration-300 flex flex-col group relative"
                >
                  {/* Image Container */}
                  <div className="relative aspect-[4/3] overflow-hidden bg-neutral-900">
                    <img
                      src={primaryImage}
                      alt={product.name_en}
                      className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500 brightness-90 group-hover:brightness-100"
                      loading="lazy"
                    />

                    {/* Installation Tag */}
                    <div className="absolute top-3 left-3">
                      {product.installationIncluded ? (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-emerald-950/90 border border-emerald-600/50 text-emerald-300 text-[10px] font-semibold uppercase tracking-wider backdrop-blur-sm">
                          <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                          <span>{t('Fitting Included', 'फिटिंग शामिल')}</span>
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-neutral-900/90 border border-neutral-700 text-neutral-300 text-[10px] font-medium uppercase tracking-wider backdrop-blur-sm">
                          <span>{t('Material Only', 'मटीरियल रेट')}</span>
                        </span>
                      )}
                    </div>

                    {/* In Stock Badge */}
                    <div className="absolute top-3 right-3">
                      <span className="px-2 py-0.5 bg-black/75 border border-neutral-700 text-[10px] text-[#DFC27E] uppercase font-mono">
                        {product.inStock !== false ? t('In Stock', 'स्टॉक में') : t('On Order', 'ऑर्डर पर')}
                      </span>
                    </div>

                    {/* Category Label */}
                    <div className="absolute bottom-3 left-3">
                      <span className="text-[11px] font-semibold text-white/90 bg-black/70 px-2 py-0.5 backdrop-blur-sm uppercase tracking-wider">
                        {catObj ? t(catObj.name_en, catObj.name_hi) : product.categorySlug}
                      </span>
                    </div>
                  </div>

                  {/* Body Content */}
                  <div className="p-6 flex-1 flex flex-col justify-between">
                    <div>
                      <h3 className="text-lg font-serif font-bold text-white group-hover:text-gold-gradient transition-colors mb-2 leading-snug">
                        {t(product.name_en, product.name_hi)}
                      </h3>

                      <p className="text-xs text-neutral-400 line-clamp-2 leading-relaxed mb-4">
                        {t(product.description_en, product.description_hi)}
                      </p>

                      {/* Specifications Grid */}
                      <div className="space-y-1.5 text-xs text-neutral-300 py-3 border-y border-neutral-800/80 mb-5">
                        <div className="flex justify-between">
                          <span className="text-neutral-500 font-medium">{t('Dimensions:', 'साइज:')}</span>
                          <span className="font-mono text-neutral-200">{product.size}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-neutral-500 font-medium">{t('Thickness:', 'मोटाई:')}</span>
                          <span className="font-mono text-neutral-200">{product.thickness}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-neutral-500 font-medium">{t('Finishes:', 'कलर विकल्प:')}</span>
                          <span className="text-right text-neutral-300 truncate max-w-[180px]">{product.finish_colors}</span>
                        </div>
                      </div>
                    </div>

                    {/* Price & Action Row */}
                    <div>
                      <div className="flex items-baseline justify-between mb-4">
                        <div>
                          <span className="text-[10px] text-neutral-400 uppercase tracking-widest block">
                            {t('Showroom Price', 'शोरूम रेट')}
                          </span>
                          <div className="flex items-baseline gap-1">
                            <span className="text-2xl font-serif font-bold text-white text-gold-gradient">
                              ₹{product.price.toLocaleString('en-IN')}
                            </span>
                            <span className="text-xs text-neutral-400 font-mono">
                              / {product.priceUnit}
                            </span>
                          </div>
                        </div>

                        <button
                          type="button"
                          onClick={() => onOpenQuoteModal(product.name_en)}
                          className="text-xs text-[#DFC27E] hover:underline font-medium cursor-pointer"
                        >
                          {t('Request Sample', 'सैंपल देखें')}
                        </button>
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        <a
                          href={getWhatsAppProductUrl(product)}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="py-2.5 bg-[#25D366]/15 hover:bg-[#25D366]/25 border border-[#25D366]/40 text-[#25D366] text-xs font-semibold uppercase tracking-wider flex items-center justify-center gap-1.5 transition-colors"
                        >
                          <MessageCircle className="w-3.5 h-3.5 fill-[#25D366]/20" />
                          <span>WhatsApp</span>
                        </a>

                        <button
                          type="button"
                          onClick={() => onOpenQuoteModal(product.name_en)}
                          className="py-2.5 bg-[#C9A24B] hover:bg-[#DFC27E] text-[#121212] text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-1 transition-colors cursor-pointer"
                        >
                          <span>{t('Get Quote', 'कोटेशन लें')}</span>
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          /* Products Display: PRICE-LIST TABLE VIEW */
          <div className="overflow-x-auto border border-neutral-800 bg-[#161616]">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#1F1F1F] text-neutral-400 uppercase font-mono tracking-wider border-b border-neutral-800">
                <tr>
                  <th className="py-4 px-4">{t('Product & Model', 'उत्पाद / मॉडल')}</th>
                  <th className="py-4 px-4">{t('Category', 'कैटेगरी')}</th>
                  <th className="py-4 px-4">{t('Dimensions & Thickness', 'साइज व मोटाई')}</th>
                  <th className="py-4 px-4">{t('Finishes / Colors', 'कलर विकल्प')}</th>
                  <th className="py-4 px-4">{t('Fitting Included?', 'फिटिंग शामिल?')}</th>
                  <th className="py-4 px-4 text-right">{t('Price (INR)', 'मूल्य (रु)')}</th>
                  <th className="py-4 px-4 text-center">{t('Action', 'संपर्क')}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-800/80">
                {filteredProducts.map((prod) => {
                  const catObj = categories.find(c => c.id === prod.categoryId || c.slug === prod.categorySlug);
                  return (
                    <tr key={prod.id} className="hover:bg-neutral-800/40 transition-colors">
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-3">
                          <img
                            src={prod.images?.[0] || 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=100&q=80'}
                            alt={prod.name_en}
                            className="w-10 h-10 object-cover shrink-0 border border-neutral-700"
                          />
                          <div>
                            <p className="font-serif font-bold text-sm text-white">{t(prod.name_en, prod.name_hi)}</p>
                            <span className="text-[10px] text-neutral-400 font-mono">SKU: {prod.id}</span>
                          </div>
                        </div>
                      </td>
                      <td className="py-3.5 px-4 text-neutral-300">
                        {catObj ? t(catObj.name_en, catObj.name_hi) : prod.categorySlug}
                      </td>
                      <td className="py-3.5 px-4 font-mono text-neutral-300">
                        <div>{prod.size}</div>
                        <div className="text-[10px] text-neutral-500">{prod.thickness}</div>
                      </td>
                      <td className="py-3.5 px-4 text-neutral-400 max-w-[200px] truncate">
                        {prod.finish_colors}
                      </td>
                      <td className="py-3.5 px-4">
                        {prod.installationIncluded ? (
                          <span className="text-emerald-400 inline-flex items-center gap-1 font-medium">
                            <Check className="w-3.5 h-3.5" />
                            <span>Included</span>
                          </span>
                        ) : (
                          <span className="text-neutral-500">Material Only</span>
                        )}
                      </td>
                      <td className="py-3.5 px-4 text-right">
                        <span className="font-serif font-bold text-base text-gold-gradient">
                          ₹{prod.price.toLocaleString('en-IN')}
                        </span>
                        <span className="text-[10px] text-neutral-400 font-mono block">
                          / {prod.priceUnit}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-center">
                        <a
                          href={getWhatsAppProductUrl(prod)}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1 px-3 py-1.5 bg-[#25D366]/20 hover:bg-[#25D366]/30 text-[#25D366] border border-[#25D366]/40 text-xs font-semibold"
                        >
                          <MessageCircle className="w-3.5 h-3.5" />
                          <span>WhatsApp</span>
                        </a>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {/* Footnote on Pricing & Measurements */}
        <div className="mt-10 p-5 bg-[#171717] border border-neutral-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-start gap-3">
            <Info className="w-5 h-5 text-[#C9A24B] shrink-0 mt-0.5" />
            <p className="text-xs text-neutral-300 leading-relaxed max-w-3xl">
              {t(
                'Note: Final project billing is calculated based on exact on-site laser measurements. Installation charges are included where specified or charged nominally per square foot. We bring physical sample kits to your premises for color matching.',
                'नोट: अंतिम मूल्य दीवार के वास्तविक लेज़र नाप पर निर्भर करता है। जहां उल्लेख है वहां इंस्टॉलेशन चार्ज शामिल है अन्यथा नाममात्र अतिरिक्त दर पर लगाया जाता है। हम आपके घर पर कलर मैचिंग के लिए ओरिजिनल सैंपल्स लेकर आते हैं।'
              )}
            </p>
          </div>

          <button
            type="button"
            onClick={() => onOpenQuoteModal()}
            className="px-5 py-2.5 bg-[#C9A24B] hover:bg-[#DFC27E] text-[#121212] font-bold text-xs uppercase tracking-wider whitespace-nowrap shrink-0 cursor-pointer"
          >
            {t('Book Free Site Visit', 'फ्री साइट विजिट बुक करें')}
          </button>
        </div>
      </div>
    </section>
  );
};
