import React from 'react';
import { useLanguage } from '../../context/LanguageContext';
import { useData } from '../../context/DataContext';
import { 
  ShieldCheck, 
  Users, 
  FileText, 
  Clock, 
  Award, 
  MapPin, 
  Sparkles,
  Check
} from 'lucide-react';

interface WhyChooseUsProps {
  onOpenQuoteModal: () => void;
}

export const WhyChooseUs: React.FC<WhyChooseUsProps> = ({ onOpenQuoteModal }) => {
  const { t } = useLanguage();
  const { siteContent } = useData();

  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'ShieldCheck': return <ShieldCheck className="w-6 h-6 text-[#C9A24B]" />;
      case 'Users': return <Users className="w-6 h-6 text-[#C9A24B]" />;
      case 'FileText': return <FileText className="w-6 h-6 text-[#C9A24B]" />;
      case 'Clock': return <Clock className="w-6 h-6 text-[#C9A24B]" />;
      case 'Award': return <Award className="w-6 h-6 text-[#C9A24B]" />;
      case 'MapPin': return <MapPin className="w-6 h-6 text-[#C9A24B]" />;
      default: return <Sparkles className="w-6 h-6 text-[#C9A24B]" />;
    }
  };

  return (
    <section id="why-us" className="py-24 bg-[#151515] text-[#F7F3EC] relative border-t border-neutral-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-[#DFC27E] text-[10px] font-mono tracking-[0.3em] uppercase block mb-3">
            {t('ARCHITECTURAL STANDARDS', 'हमारी विशेषताएं')}
          </span>
          <h2 className="text-3xl sm:text-5xl font-serif text-white tracking-tight mb-4">
            {t('Why Homeowners & Architects Choose Us', 'एके इंटीरियर को क्यों चुनें?')}
          </h2>
          <p className="text-xs sm:text-sm text-neutral-400 font-light leading-relaxed">
            {t(
              'Engineered moisture barriers, laser-aligned flutes, and zero-mess swift handover in 24 to 48 hours.',
              'सीलन से पूर्ण सुरक्षा, सटीक फिटिंग और मात्र 24-48 घंटे में काम पूरा।'
            )}
          </p>
        </div>

        {/* 6 Feature Pillars */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {siteContent.whyChooseUs?.map((item, idx) => (
            <div
              key={item.id || idx}
              className="bg-[#1A1A1A] border border-neutral-800 hover:border-[#C9A24B]/50 p-8 transition-all duration-300 relative group flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-6">
                  <div className="w-12 h-12 border border-[#C9A24B]/40 bg-[#121212] flex items-center justify-center group-hover:scale-105 transition-transform">
                    {getIcon(item.icon)}
                  </div>
                  <span className="text-xs font-mono text-neutral-600 group-hover:text-[#DFC27E] transition-colors">
                    0{idx + 1}
                  </span>
                </div>

                <h3 className="text-xl font-serif font-bold text-white group-hover:text-gold-gradient transition-colors mb-3">
                  {t(item.title_en, item.title_hi)}
                </h3>

                <p className="text-xs text-neutral-400 leading-relaxed font-light">
                  {t(item.desc_en, item.desc_hi)}
                </p>
              </div>

              <div className="pt-6 mt-6 border-t border-neutral-800/60 flex items-center gap-2 text-[11px] text-[#DFC27E]">
                <Check className="w-3.5 h-3.5" />
                <span className="uppercase tracking-wider font-semibold">
                  {t('Verified Guarantee', 'प्रमाणित गुणवत्ता')}
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Bottom Banner */}
        <div className="mt-16 p-8 bg-gradient-to-r from-[#1B1811] via-[#241E14] to-[#1B1811] border border-[#C9A24B]/40 flex flex-col md:flex-row items-center justify-between gap-6 shadow-2xl">
          <div>
            <h3 className="text-2xl font-serif font-bold text-white mb-2">
              {t('Have a specific wall size or photo in mind?', 'क्या आपके पास कोई दीवार का फोटो या नाप है?')}
            </h3>
            <p className="text-xs text-neutral-300">
              {t(
                'Send it to our WhatsApp or book a free on-site measurement visit. We bring complete physical sample kits.',
                'व्हाट्सएप पर फोटो भेजें या फ्री साइट विजिट बुक करें। हमारे एक्सपर्ट असली सैंपल बॉक्स साथ लेकर आते हैं।'
              )}
            </p>
          </div>

          <button
            type="button"
            onClick={onOpenQuoteModal}
            className="px-7 py-3.5 bg-[#C9A24B] hover:bg-[#DFC27E] text-[#121212] font-bold text-xs uppercase tracking-wider whitespace-nowrap shadow-lg cursor-pointer"
          >
            {t('Schedule Free Measurement', 'फ्री नाप बुक करें')}
          </button>
        </div>
      </div>
    </section>
  );
};
