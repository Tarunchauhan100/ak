import React from 'react';
import { useLanguage } from '../../context/LanguageContext';
import { useData } from '../../context/DataContext';
import { Sparkles, ShieldCheck, Check, Award, Hammer, Users } from 'lucide-react';

export const AboutSection: React.FC = () => {
  const { t, language } = useLanguage();
  const { siteContent, settings } = useData();

  return (
    <section id="about" className="py-24 bg-[#151515] text-[#F7F3EC] relative border-t border-neutral-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          {/* Left Column: Image Composition (5 Cols) */}
          <div className="lg:col-span-5 relative">
            <div className="relative border border-[#C9A24B]/40 p-3 bg-[#1B1B1B] shadow-2xl">
              <img
                src="https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1000&q=80"
                alt="AK Interior Showroom & Craftsmanship"
                className="w-full aspect-[4/5] object-cover brightness-95"
                loading="lazy"
              />

              {/* Founder / Craftsmen Overlay Tag */}
              <div className="absolute -bottom-6 -right-6 bg-[#181818] border border-[#C9A24B] p-5 shadow-2xl max-w-xs hidden sm:block">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full border border-[#C9A24B] flex items-center justify-center bg-black text-[#C9A24B] font-serif font-bold text-base">
                    AK
                  </div>
                  <div>
                    <h4 className="text-sm font-serif font-bold text-white">
                      {siteContent.aboutOwnerName}
                    </h4>
                    <p className="text-[10px] text-[#DFC27E] uppercase tracking-wider">
                      {siteContent.aboutOwnerRole}
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Architectural decorative border */}
            <div className="absolute -top-4 -left-4 w-24 h-24 border-t-2 border-l-2 border-[#C9A24B]/40 pointer-events-none" />
          </div>

          {/* Right Column: Story & Mission (7 Cols) */}
          <div className="lg:col-span-7 space-y-6">
            <span className="text-[#DFC27E] text-[10px] font-mono tracking-[0.3em] uppercase block">
              {t('HERITAGE & CRAFTSMANSHIP', 'हमारी कहानी व विजन')}
            </span>

            <h2 className="text-3xl sm:text-5xl font-serif font-bold text-white tracking-tight leading-tight">
              {t(
                'Redefining Modern Indian Interiors with Engineered Elegance',
                'आधुनिक इंटीरियर पैनल्स और शिल्पकला की नई परिभाषा'
              )}
            </h2>

            <p className="text-sm text-neutral-300 leading-relaxed font-light">
              {t(siteContent.aboutStory_en, siteContent.aboutStory_hi)}
            </p>

            {/* 3 Pillars */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4 border-t border-neutral-800">
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-none border border-[#C9A24B]/40 bg-[#121212] flex items-center justify-center shrink-0 text-[#C9A24B]">
                  <Hammer className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-sm font-semibold text-white">
                    {t('Precision Flute Alignment', 'सटीक फिटिंग व अलाइनमेंट')}
                  </h4>
                  <p className="text-xs text-neutral-400 font-light mt-0.5">
                    {t('Laser level calibration on every single joint.', 'लेज़र लेवल द्वारा सटीक जोड़ और फिनिशिंग।')}
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-none border border-[#C9A24B]/40 bg-[#121212] flex items-center justify-center shrink-0 text-[#C9A24B]">
                  <Users className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-sm font-semibold text-white">
                    {t('No Middlemen or Subcontractors', 'स्वयं की समर्पित टीम')}
                  </h4>
                  <p className="text-xs text-neutral-400 font-light mt-0.5">
                    {t('Direct company accountability for every nail.', 'हर काम की सीधी जवाबदेही हमारे कंधों पर।')}
                  </p>
                </div>
              </div>
            </div>

            {/* Quick Experience Stats Box */}
            <div className="pt-4 flex items-center gap-6 sm:gap-10">
              <div>
                <span className="text-3xl sm:text-4xl font-serif font-bold text-gold-gradient block">
                  {siteContent.expYears}+
                </span>
                <span className="text-xs text-neutral-400 uppercase tracking-wider">
                  {t('Years Experience', 'वर्षों का अनुभव')}
                </span>
              </div>

              <div className="w-px h-10 bg-neutral-800" />

              <div>
                <span className="text-3xl sm:text-4xl font-serif font-bold text-gold-gradient block">
                  {siteContent.projectsCompleted}+
                </span>
                <span className="text-xs text-neutral-400 uppercase tracking-wider">
                  {t('Projects Delivered', 'सफल प्रोजेक्ट्स')}
                </span>
              </div>

              <div className="w-px h-10 bg-neutral-800" />

              <div>
                <span className="text-3xl sm:text-4xl font-serif font-bold text-gold-gradient block">
                  100%
                </span>
                <span className="text-xs text-neutral-400 uppercase tracking-wider">
                  {t('Seelan Protection', 'सीलन से सुरक्षा')}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
