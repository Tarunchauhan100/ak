import React from 'react';
import { useLanguage } from '../../context/LanguageContext';
import { useData } from '../../context/DataContext';
import { ArrowUpRight } from 'lucide-react';

interface CategoriesOverviewProps {
  onSelectCategory: (categoryId: string) => void;
}

export const CategoriesOverview: React.FC<CategoriesOverviewProps> = ({ onSelectCategory }) => {
  const { t } = useLanguage();
  const { categories } = useData();

  // Curated category images with high-end luxury interiors
  const categoryImages: Record<string, string> = {
    'pvc-panels': 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=900&q=85',
    'charcoal-panels': 'https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&w=900&q=85',
    'wpc-panels': 'https://images.unsplash.com/photo-1600585152220-90363fe7e115?auto=format&fit=crop&w=900&q=85',
    'uv-marble-sheets': 'https://images.unsplash.com/photo-1600585154526-990dced4db0d?auto=format&fit=crop&w=900&q=85',
    'decorative-lights': 'https://images.unsplash.com/photo-1513519245088-0e12902e5a38?auto=format&fit=crop&w=900&q=85',
    'ceiling-work': 'https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=900&q=85',
    'turnkey-interiors': 'https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?auto=format&fit=crop&w=900&q=85',
  };

  const handleCategoryClick = (catId: string) => {
    onSelectCategory(catId);
    const prodSection = document.getElementById('products');
    if (prodSection) {
      prodSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="categories" className="py-24 bg-[#0F0F0E] text-[#F7F3EC] relative border-t border-neutral-900">
      <div className="max-w-7xl mx-auto px-6 sm:px-8 lg:px-12">
        {/* Section Header - Clean, Editorial */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div>
            <span className="text-[#DFC27E] text-[10px] font-mono tracking-[0.3em] uppercase block mb-3">
              {t('CURATED DISCIPLINES', 'प्रमुख उत्पाद व सेवाएं')}
            </span>
            <h2 className="text-3xl sm:text-5xl font-serif text-white tracking-tight">
              {t('Architectural Collections', 'आर्किटेक्चरल कलेक्शन्स')}
            </h2>
          </div>

          <p className="text-xs sm:text-sm text-neutral-400 max-w-md font-light leading-relaxed">
            {t(
              'Select any category to view live showroom pricing, finishes, and dimensions.',
              'कैटलॉग और लाइव रेट लिस्ट देखने के लिए किसी भी कैटेगरी को चुनें।'
            )}
          </p>
        </div>

        {/* Minimalist Visual Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {categories.slice(0, 6).map((cat, idx) => {
            const img = categoryImages[cat.slug] || categoryImages['pvc-panels'];

            return (
              <div
                key={cat.id}
                onClick={() => handleCategoryClick(cat.id)}
                className="group relative cursor-pointer flex flex-col transition-all duration-300"
              >
                {/* Image Frame with Minimalist Border */}
                <div className="relative aspect-[4/3] overflow-hidden bg-neutral-900 mb-4 border border-neutral-800/80 group-hover:border-[#C9A24B]/60 transition-colors">
                  <img
                    src={img}
                    alt={cat.name_en}
                    className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700 brightness-[0.75] group-hover:brightness-[0.9]"
                    loading="lazy"
                  />
                  
                  {/* Subtle index number */}
                  <span className="absolute top-3 left-4 font-mono text-[10px] tracking-widest text-[#DFC27E] bg-black/60 px-2 py-0.5">
                    0{idx + 1}
                  </span>

                  {/* Arrow Indicator */}
                  <div className="absolute top-3 right-3 w-7 h-7 bg-black/70 border border-neutral-700 flex items-center justify-center text-neutral-300 group-hover:text-[#DFC27E] group-hover:border-[#C9A24B] transition-colors">
                    <ArrowUpRight className="w-3.5 h-3.5" />
                  </div>
                </div>

                {/* Card Editorial Typography */}
                <div className="flex items-baseline justify-between pt-1">
                  <h3 className="text-xl font-serif text-white group-hover:text-[#DFC27E] transition-colors">
                    {t(cat.name_en, cat.name_hi)}
                  </h3>
                  <span className="text-[11px] text-neutral-500 font-mono tracking-wider group-hover:text-white transition-colors">
                    View →
                  </span>
                </div>

                <p className="text-xs text-neutral-400 font-light mt-1 line-clamp-1">
                  {t(cat.description_en, cat.description_hi)}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

