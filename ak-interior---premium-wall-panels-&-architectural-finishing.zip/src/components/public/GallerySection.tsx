import React, { useState, useEffect } from 'react';
import { useLanguage } from '../../context/LanguageContext';
import { useData } from '../../context/DataContext';
import { GalleryItem } from '../../types';
import { 
  Sparkles, 
  X, 
  ChevronLeft, 
  ChevronRight, 
  MapPin, 
  Layers, 
  ArrowRight,
  Maximize2,
  SplitSquareHorizontal
} from 'lucide-react';

interface GallerySectionProps {
  onOpenQuoteModal: (productName?: string) => void;
  onSelectCategory: (categoryId: string) => void;
}

export const GallerySection: React.FC<GallerySectionProps> = ({
  onOpenQuoteModal,
  onSelectCategory,
}) => {
  const { t, language } = useLanguage();
  const { gallery, products } = useData();

  const [activeFilter, setActiveFilter] = useState<string>('all');
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);
  const [beforeAfterPos, setBeforeAfterPos] = useState<number>(50); // percentage for slider
  const [lightboxMode, setLightboxMode] = useState<'after' | 'slider'>('after');

  const categories = [
    { key: 'all', label_en: 'All Projects', label_hi: 'सभी प्रोजेक्ट्स' },
    { key: 'tv_unit', label_en: 'TV Unit Walls', label_hi: 'टीवी यूनिट्स' },
    { key: 'living_room', label_en: 'Living Room', label_hi: 'लिविंग रूम' },
    { key: 'bedroom', label_en: 'Bedrooms', label_hi: 'बेडरूम्स' },
    { key: 'office', label_en: 'Office & Commercial', label_hi: 'ऑफिस व कमर्शियल' },
    { key: 'shop', label_en: 'Shops & Showrooms', label_hi: 'शोरूम्स' },
    { key: 'ceiling', label_en: 'Ceiling & Lights', label_hi: 'सीलिंग व लाइट्स' },
  ];

  const filteredGallery = gallery.filter((item) => {
    if (activeFilter === 'all') return true;
    return item.category === activeFilter;
  });

  // Keyboard navigation for lightbox
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (lightboxIndex === null) return;
      if (e.key === 'Escape') setLightboxIndex(null);
      if (e.key === 'ArrowRight') {
        setLightboxIndex((prev) => (prev !== null ? (prev + 1) % filteredGallery.length : null));
      }
      if (e.key === 'ArrowLeft') {
        setLightboxIndex((prev) => (prev !== null ? (prev - 1 + filteredGallery.length) % filteredGallery.length : null));
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [lightboxIndex, filteredGallery.length]);

  const activeItem = lightboxIndex !== null ? filteredGallery[lightboxIndex] : null;

  return (
    <section id="gallery" className="py-24 bg-[#121212] text-[#F7F3EC] relative border-t border-neutral-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <span className="text-[#DFC27E] text-[10px] font-mono tracking-[0.3em] uppercase block mb-3">
            {t('PORTFOLIO OF EXCELLENCE', 'सफल प्रोजेक्ट्स')}
          </span>
          <h2 className="text-3xl sm:text-5xl font-serif text-white tracking-tight mb-4">
            {t('Real Transformations & Installations', 'वास्तविक इंस्टॉलेशन एवं फिनिशिंग')}
          </h2>
          <p className="text-xs sm:text-sm text-neutral-400 font-light leading-relaxed">
            {t(
              'Browse completed projects across residences, showrooms, and corporate spaces in India.',
              'भारत के विभिन्न शहरों में हमारे कारीगरों द्वारा तैयार किए गए लिविंग रूम और टीवी यूनिट्स।'
            )}
          </p>
        </div>

        {/* Category Filters */}
        <div className="flex items-center justify-center gap-2 overflow-x-auto pb-4 mb-10 scrollbar-none">
          {categories.map((cat) => (
            <button
              key={cat.key}
              onClick={() => setActiveFilter(cat.key)}
              className={`px-4 py-2 text-xs font-semibold uppercase tracking-wider whitespace-nowrap transition-all border ${
                activeFilter === cat.key
                  ? 'bg-[#C9A24B] text-[#121212] border-[#C9A24B] shadow-lg shadow-[#C9A24B]/20'
                  : 'bg-[#181818] text-neutral-300 border-neutral-800 hover:border-neutral-600'
              }`}
            >
              {t(cat.label_en, cat.label_hi)}
            </button>
          ))}
        </div>

        {/* Gallery Masonry / Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredGallery.map((item, idx) => {
            const hasBefore = !!item.beforeImage;

            return (
              <div
                key={item.id}
                onClick={() => {
                  setLightboxIndex(idx);
                  setLightboxMode(hasBefore ? 'slider' : 'after');
                }}
                className="group relative bg-[#181818] border border-neutral-800 hover:border-[#C9A24B]/60 transition-all duration-300 overflow-hidden cursor-pointer"
              >
                {/* Image */}
                <div className="relative aspect-[4/3] overflow-hidden bg-neutral-900">
                  <img
                    src={item.image}
                    alt={item.title_en}
                    className="w-full h-full object-cover object-center group-hover:scale-108 transition-transform duration-700 brightness-90 group-hover:brightness-100"
                    loading="lazy"
                  />

                  {/* Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black via-black/30 to-transparent opacity-80 group-hover:opacity-90 transition-opacity" />

                  {/* Before/After Tag */}
                  {hasBefore && (
                    <div className="absolute top-3 left-3 bg-[#C9A24B] text-[#121212] text-[10px] font-bold px-2 py-0.5 uppercase tracking-wider flex items-center gap-1 shadow-md">
                      <SplitSquareHorizontal className="w-3 h-3" />
                      <span>{t('Before / After', 'पहले / बाद')}</span>
                    </div>
                  )}

                  {/* Expand icon */}
                  <div className="absolute top-3 right-3 w-8 h-8 rounded-full bg-black/60 border border-neutral-700 text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <Maximize2 className="w-4 h-4 text-[#DFC27E]" />
                  </div>

                  {/* Bottom Captions */}
                  <div className="absolute bottom-0 left-0 right-0 p-5">
                    <div className="flex items-center gap-1 text-[11px] text-[#DFC27E] font-medium mb-1">
                      <MapPin className="w-3 h-3" />
                      <span>{item.location}</span>
                    </div>

                    <h3 className="text-lg font-serif font-bold text-white mb-1.5 group-hover:text-gold-gradient transition-colors">
                      {t(item.title_en, item.title_hi)}
                    </h3>

                    <p className="text-xs text-neutral-300 line-clamp-1 font-light">
                      {item.panelType}
                    </p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Lightbox Modal */}
      {activeItem && lightboxIndex !== null && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/95 backdrop-blur-xl p-4 sm:p-6 animate-in fade-in duration-200">
          {/* Close button */}
          <button
            onClick={() => setLightboxIndex(null)}
            className="absolute top-5 right-5 z-20 w-10 h-10 rounded-full bg-neutral-900 border border-neutral-700 text-white flex items-center justify-center hover:bg-neutral-800 transition-colors"
            aria-label="Close lightbox"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Left Arrow */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              setLightboxIndex((lightboxIndex - 1 + filteredGallery.length) % filteredGallery.length);
            }}
            className="absolute left-4 top-1/2 -translate-y-1/2 z-20 w-11 h-11 rounded-full bg-neutral-900/80 border border-neutral-700 text-white hover:text-[#C9A24B] flex items-center justify-center hover:bg-neutral-800 transition-colors"
            aria-label="Previous project"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>

          {/* Right Arrow */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              setLightboxIndex((lightboxIndex + 1) % filteredGallery.length);
            }}
            className="absolute right-4 top-1/2 -translate-y-1/2 z-20 w-11 h-11 rounded-full bg-neutral-900/80 border border-neutral-700 text-white hover:text-[#C9A24B] flex items-center justify-center hover:bg-neutral-800 transition-colors"
            aria-label="Next project"
          >
            <ChevronRight className="w-6 h-6" />
          </button>

          {/* Lightbox Center Card */}
          <div className="max-w-4xl w-full max-h-[90vh] flex flex-col bg-[#161616] border border-[#C9A24B]/40 shadow-2xl overflow-hidden">
            {/* Viewport for image or Before/After slider */}
            <div className="relative aspect-[16/10] sm:aspect-[16/9] bg-black overflow-hidden flex items-center justify-center select-none">
              {activeItem.beforeImage && lightboxMode === 'slider' ? (
                /* Interactive Before/After Split Slider */
                <div className="relative w-full h-full overflow-hidden">
                  {/* After Image (Full width background) */}
                  <img
                    src={activeItem.image}
                    alt="Finished installation"
                    className="absolute inset-0 w-full h-full object-cover"
                  />
                  <div className="absolute top-4 right-4 bg-black/70 px-2.5 py-1 text-[11px] font-bold text-emerald-400 border border-emerald-500/40 uppercase">
                    After (Finished)
                  </div>

                  {/* Before Image (Clipped by slider position) */}
                  <div
                    className="absolute inset-0 overflow-hidden"
                    style={{ width: `${beforeAfterPos}%` }}
                  >
                    <img
                      src={activeItem.beforeImage}
                      alt="Before installation"
                      className="absolute inset-0 w-full h-full object-cover max-w-none"
                      style={{ width: '100%', height: '100%', minWidth: '100%' }}
                    />
                    <div className="absolute top-4 left-4 bg-black/70 px-2.5 py-1 text-[11px] font-bold text-amber-400 border border-amber-500/40 uppercase">
                      Before (Site)
                    </div>
                  </div>

                  {/* Split Handle Divider Line */}
                  <div
                    className="absolute top-0 bottom-0 w-1 bg-[#C9A24B] shadow-2xl cursor-ew-resize"
                    style={{ left: `${beforeAfterPos}%` }}
                  >
                    <div className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-8 h-8 rounded-full bg-[#C9A24B] text-[#121212] flex items-center justify-center shadow-lg font-bold text-xs">
                      ↔
                    </div>
                  </div>

                  {/* Invisible drag input range */}
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={beforeAfterPos}
                    onChange={(e) => setBeforeAfterPos(Number(e.target.value))}
                    className="absolute inset-0 opacity-0 cursor-ew-resize w-full h-full z-10"
                  />
                </div>
              ) : (
                /* Standard Full Image */
                <img
                  src={activeItem.image}
                  alt={activeItem.title_en}
                  className="w-full h-full object-contain"
                />
              )}
            </div>

            {/* Lightbox Information Bar */}
            <div className="p-6 bg-[#161616] border-t border-neutral-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-3 text-xs text-neutral-400 mb-1">
                  <span className="flex items-center gap-1 text-[#DFC27E]">
                    <MapPin className="w-3.5 h-3.5" />
                    <span>{activeItem.location}</span>
                  </span>
                  <span>•</span>
                  <span>{activeItem.panelType}</span>
                </div>

                <h3 className="text-xl font-serif font-bold text-white">
                  {t(activeItem.title_en, activeItem.title_hi)}
                </h3>
              </div>

              {/* Action buttons */}
              <div className="flex items-center gap-3 w-full sm:w-auto">
                {activeItem.beforeImage && (
                  <button
                    type="button"
                    onClick={() => setLightboxMode(lightboxMode === 'slider' ? 'after' : 'slider')}
                    className="px-3 py-2 bg-neutral-800 border border-neutral-700 hover:border-[#C9A24B] text-xs text-neutral-200 font-medium"
                  >
                    {lightboxMode === 'slider' ? 'View Finished Only' : 'Compare Before / After'}
                  </button>
                )}

                <button
                  type="button"
                  onClick={() => {
                    setLightboxIndex(null);
                    onOpenQuoteModal(`Project: ${activeItem.title_en}`);
                  }}
                  className="flex-1 sm:flex-initial px-5 py-2.5 bg-[#C9A24B] hover:bg-[#DFC27E] text-[#121212] font-bold text-xs uppercase tracking-wider whitespace-nowrap cursor-pointer"
                >
                  {t('Get Similar Design', 'ऐसा ही डिजाइन बनवाएं')}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
