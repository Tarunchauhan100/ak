import React, { useState, useEffect } from 'react';
import { useLanguage } from '../../context/LanguageContext';
import { useData } from '../../context/DataContext';
import { ArrowRight, MessageCircle } from 'lucide-react';

interface HeroProps {
  onOpenQuoteModal: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onOpenQuoteModal }) => {
  const { t, language } = useLanguage();
  const { siteContent, settings } = useData();

  const [currentSlide, setCurrentSlide] = useState(0);

  const heroImages = siteContent.heroImages?.length 
    ? siteContent.heroImages 
    : [
        'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1920&q=85',
        'https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&w=1920&q=85',
        'https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?auto=format&fit=crop&w=1920&q=85'
      ];

  // Slideshow
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % heroImages.length);
    }, 7000);
    return () => clearInterval(timer);
  }, [heroImages.length]);

  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  const whatsappUrl = `https://wa.me/${settings.whatsappNumber}?text=${encodeURIComponent('Hello AK Interior, I would like to inquire about architectural wall panels and lighting.')}`;

  return (
    <section id="home" className="relative min-h-[92vh] sm:min-h-screen flex flex-col justify-between pt-28 pb-10 overflow-hidden bg-[#0D0D0C]">
      {/* Cinematic Full-Bleed Background Slideshow */}
      <div className="absolute inset-0 z-0 overflow-hidden">
        {heroImages.map((imgUrl, index) => (
          <div
            key={imgUrl}
            className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${
              index === currentSlide ? 'opacity-100 scale-105' : 'opacity-0 scale-100'
            }`}
            style={{
              transition: 'opacity 2s ease-in-out, transform 9s ease-out',
            }}
          >
            <img
              src={imgUrl}
              alt="Luxury interior wall paneling"
              className="w-full h-full object-cover object-center brightness-[0.45] contrast-[1.08]"
              loading={index === 0 ? 'eager' : 'lazy'}
            />
          </div>
        ))}

        {/* Ambient Dark Velvet Gradients */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#0E0E0D] via-black/40 to-black/60" />
        <div className="absolute inset-0 bg-gradient-to-r from-black/70 via-black/20 to-transparent" />
      </div>

      {/* Hero Editorial Content - Airy, Impactful, Restrained */}
      <div className="relative z-10 max-w-7xl mx-auto px-6 sm:px-8 lg:px-12 my-auto w-full pt-10 pb-6">
        <div className="max-w-2xl sm:max-w-3xl">
          {/* Subtle Hairline Brand Kicker */}
          <div className="flex items-center gap-3 mb-6">
            <span className="w-6 h-px bg-[#C9A24B]" />
            <span className="text-[#DFC27E] text-[10px] sm:text-xs font-mono font-medium tracking-[0.3em] uppercase">
              {language === 'hi' ? 'आर्किटेक्चरल इंटीरियर स्टूडियो' : 'AK INTERIOR • ARCHITECTURAL SURFACES'}
            </span>
          </div>

          {/* Master Headline */}
          <h1 className="text-4xl sm:text-6xl lg:text-7xl font-serif text-white tracking-tight leading-[1.08] mb-6">
            {language === 'hi' ? 'दीवारों को बनाइए कला' : 'Transform Your Walls Into Art.'}
          </h1>

          {/* Minimal 1-Line Understated Subhead */}
          <p className="text-base sm:text-xl text-neutral-300 font-light tracking-wide font-serif-luxury italic mb-10 max-w-xl">
            {t(
              'Charcoal Louvers · UV Marble Slabs · Fluted Panels · Concealed LED Lighting',
              'चारकोल लवर्स • यूवी मार्बल शीट्स • फ्लूटेड पैनल्स • प्रोफाइल लाइट्स'
            )}
          </p>

          {/* Clean Dual CTAs - Zero Chunky Boxiness */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 sm:gap-6">
            <button
              type="button"
              onClick={() => scrollToSection('products')}
              className="px-8 py-3.5 bg-[#C9A24B] hover:bg-[#DFC27E] text-[#0E0E0D] font-medium text-xs uppercase tracking-[0.22em] transition-all duration-300 flex items-center gap-3 cursor-pointer group shadow-xl shadow-black/50"
            >
              <span>{t('Explore Collections', 'कलेक्शन व मूल्य देखें')}</span>
              <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
            </button>

            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2.5 text-xs text-neutral-300 hover:text-[#DFC27E] tracking-[0.18em] uppercase py-2 transition-colors duration-200"
            >
              <MessageCircle className="w-4 h-4 text-[#C9A24B]" />
              <span>{t('WhatsApp Inquiry', 'व्हाट्सएप पूछताछ')}</span>
              <span className="text-[#C9A24B]">→</span>
            </a>
          </div>
        </div>
      </div>

      {/* Editorial Single-Line Trust Bar - Unboxed, Quiet, Prestigious */}
      <div className="relative z-10 max-w-7xl mx-auto px-6 sm:px-8 lg:px-12 w-full pt-6 border-t border-neutral-800/80">
        <div className="flex flex-wrap items-center justify-between gap-y-4 gap-x-8 text-neutral-400 text-xs tracking-wider">
          <div className="flex items-center gap-3">
            <span className="font-serif text-lg text-white font-medium">{siteContent.expYears}+ Years</span>
            <span className="text-neutral-500 font-light uppercase text-[10px] tracking-widest">{t('Heritage Craft', 'अनुभव')}</span>
          </div>

          <div className="hidden sm:block text-neutral-700">/</div>

          <div className="flex items-center gap-3">
            <span className="font-serif text-lg text-white font-medium">{siteContent.projectsCompleted}+</span>
            <span className="text-neutral-500 font-light uppercase text-[10px] tracking-widest">{t('Residences & Showrooms', 'सफल प्रोजेक्ट्स')}</span>
          </div>

          <div className="hidden sm:block text-neutral-700">/</div>

          <div className="flex items-center gap-3">
            <span className="font-serif text-lg text-[#DFC27E] font-medium">100% Free</span>
            <span className="text-neutral-500 font-light uppercase text-[10px] tracking-widest">{t('Site Visit & Measurement', 'फ्री ऑन-साइट नाप')}</span>
          </div>

          <div className="hidden sm:block text-neutral-700">/</div>

          <div className="flex items-center gap-3">
            <span className="font-serif text-lg text-white font-medium">{siteContent.guaranteeYears}-Year</span>
            <span className="text-neutral-500 font-light uppercase text-[10px] tracking-widest">{t('Material Guarantee', 'वारंटी')}</span>
          </div>

          {/* Minimal slide dots */}
          <div className="flex items-center gap-1.5 ml-auto">
            {heroImages.map((_, i) => (
              <button
                key={i}
                onClick={() => setCurrentSlide(i)}
                aria-label={`Slide ${i + 1}`}
                className={`h-1 transition-all rounded-full ${
                  i === currentSlide ? 'w-6 bg-[#C9A24B]' : 'w-1.5 bg-neutral-700 hover:bg-neutral-500'
                }`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

